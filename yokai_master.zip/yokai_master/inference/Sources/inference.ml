open Printf

class t  (model:string) (action:string)  =
object (self)


method search = (* notimed_search *)

let command cmd =
  Sys.command cmd
in

let filemodel = "../sdata/"^model in
let filevol = "../sdata/00_delta0_base_and.txt" in
let filesetssamecolor = "../sdata/00_sets_same_color.txt" in
let filesetssamecolorhint = "../sdata/00_sets_same_colorhint.txt" in
let timepoint = ref "tx" in


Printf.printf "FILEMODEL ==> %s \n" filemodel;

let contains s1 s2 =
  let re = Str.regexp_string s2
  in
      try ignore (Str.search_forward re s1 0); true
      with Not_found -> false in


flush stdout; flush stderr;
Utils.print "Select TouIST\n";
flush stdout; flush stderr;
let returncode = (command "./main.exe --version") in
Utils.print "\n";




flush stdout; flush stderr;
if returncode == 0 then Utils.print ""
else begin Utils.eprint "[Error %d] please install TouIST with : brew install touist\n" returncode; exit returncode; end;




let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in



  let rec extract k list =
    if k <= 0 then [ [] ]
    else match list with
         | [] -> []
         | h :: tl ->
            let with_h = List.map (fun l -> h :: l) (extract (k-1) tl) in
            let without_h = extract k tl in
            with_h @ without_h in

let flatten l =
  let rec loop res = function
    | [] -> List.rev res
    | h::t -> loop (List.rev_append h res) t
  in
    loop [] l in



(** START SATPLAN-SOLVE - JFDX 20200408 **)
let mark x col = 

    Printf.printf " ACA estamos despues del : mark with x : %i  col : %s \n" !x !col;

    let action = ref "" in
    let goal = "col_"^(string_of_int !x)^"_"^(!col)^"_"^(!timepoint) in
    Printf.printf " ACA estamos despues mark : %s \n\n\n" goal;
    let touistcode2 = ref 0 in
    begin 
                        (*Printf.printf "DESPUES DEL IF %s - %i \n" !lines !m;*)
                        (* Generating the Deduction Formula for Marking action - Aca es punto es pasarle 2 files : 01_ini_state and 00_delta0_base_and.txt - *)
                        (* pero luego del Brev 00_delta0 ya esta con en nuevo CLOCK - ver esto -> pienso aca la solucion es que el PLANER graber los 2 files en un archivo temporal y que lo deje + *)  
                        (* listo para ser usado x el inference module :::  le podriamos llamar INI_STATE_FULL (vol + core) ? *)  

                        (* Olvidar lo anterior, aca debemos de concatenar el file: 00_delta0_base_and.txt con el file: 01_ini_state.txt - actualizado al tiempo actual *)
                        (* Sin embargo actualmente el 01_ini_state.txt tiene el tiempo anterior, entonces se debe de llamar el TRANSLATOR *) 
                        (* para que cree el nuevo 01_ini_state.txt con el tiempo ACTUALIZADO ++++ Tal vez esta llamada la puede hacer el GUi antes de llamar a INFERENCE module  *)
                        (* Pienso que esta ultima linea es mejor pues asi voy a tener ya listo el 01_ini_state para enviarlo como PARAMETRO al modulo INFERENCE *)
                        let string_of_command5 () =
                                let tmp_file = "planerdata/01_model.txt" in
                                (* let _ = Sys.command (Printf.sprintf "cat %s %s %s >  solvedatacp/formula_%i_%s.txt" filevol filemodel  goal !x !col)   in  *)
                                let _ = Sys.command (Printf.sprintf "cat %s %s >  solvedatacp/formula_%i_%s.txt" filevol filemodel !x !col)   in  
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command5();  


                              

                        (* End - Generating the Deduction Formula for Marking action *)  



                              let string_of_command4 () =
                                
                                let tmp_file = "planerdata/01_model.txt" in
                                (*let _ = Sys.command (Printf.sprintf "sed -i '1 i\ red(not ([m](' solvedatacp/formula_%i_%i.txt" !m !i)   in*)
                                let _ = Sys.command (Printf.sprintf "sed -i '1 i\ (not ([m](' solvedatacp/formula_%i_%s.txt" !x !col)   in
                                
                                (*sed -i '1 i\anything' file*)

                                let chan = open_in tmp_file in
                                close_in chan;

                              in
                              string_of_command4(); 


                              let string_of_command4d() =
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i -e 's/),/,/g' -e 's/(m)/[m]/g' solvedatacp/formula_%i_%s.txt" !x !col)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4d();                                  
         






let string_of_command4w () =
  let tmp_file = "planerdata/01_model.txt" in
  let _ = Sys.command (Printf.sprintf "echo ')=> ' >> solvedatacp/formula_%i_%s.txt" !x !col) in  
  let _ = Sys.command (Printf.sprintf "echo '[m](%s)' >> solvedatacp/formula_%i_%s.txt" goal !x !col) in 
  let _ = Sys.command (Printf.sprintf "echo '))' >> solvedatacp/formula_%i_%s.txt" !x !col) in 
  flush stdout; flush stderr;
  let chan = open_in tmp_file in
  close_in chan
in
string_of_command4w();   




                              (* Encapsulates the Deduction Process ===>  Only for testing the formula the previos code is for preparing the Deduction Formula *)  
                              let test_formula () =     
                                Printf.printf "Testing formula_%i_%s.txt \n" !x !col;
                                (*command (Printf.sprintf "./translator.exe --qbf solvedatacp/%s_formula_%i_%i.txt" opt !m !i);*)
                                command (Printf.sprintf "./translator.exe --sat solvedatacp/formula_%i_%s.txt" !x !col);
                                touistcode2 := (command (Printf.sprintf "./touist.exe ../sdata/proplogic/formula_%i_%s.txt --solve" !x !col));

                                Printf.printf "touistcode ==>  %i \n\n" !touistcode2;

                                (* Touist verify it this deduction is valid => save it in the set of same colors cards deduced by being marked with a Hint*)
                                if !touistcode2 = 8 then 
                                  
                                let string_of_command4w () =
                                  let tmp_file = "planerdata/01_model.txt" in
                                  let _ = Sys.command (Printf.sprintf "echo '%s' >> ../sdata/00_same_colorhint.tmp" goal) in 
                                  let _ = Sys.command (Printf.sprintf "sed -i -e '/%s/s/$/%i;/' %s" !col !x filesetssamecolorhint)   in
                                  (*let _ = Sys.command (Printf.sprintf "sed -i -e '/%s/s/$/%i;/' %s" !col !x filesetssamecolor)   in*)

                                  flush stdout; flush stderr;
                                  let chan = open_in tmp_file in
                                  close_in chan
                                in
                                string_of_command4w(); 
                                   
                                in

                              test_formula();     
                                
    end                              
                                
in


if (contains (action) "mark_") then
  begin
    Printf.printf "DESPUES DEL IF ACTION PARAMETER = %s \n" action;
    (* Get the Hint colors for col[] array and the size and store the size in var "i" *)
    let action1 = String.split_on_char ' ' action in
    let words = String.split_on_char '_' (List.nth action1 0) in
    let cardnum = (List.nth words 1) in
    timepoint := (List.nth words 3); (* Here we got the time *)
    let timepointold = "t"^string_of_int (int_of_string (String.sub  !timepoint 1 ((String.length(!timepoint)) - 1)) - 5) in
    Printf.printf "timepointold - timepointold - timepointold :: %s +++ %s \n" timepointold !timepoint;

    (* Update the clock time in the 01_ini_state.txt file *)

    let string_of_command4d() =
      let tmp_file = "planerdata/01_model.txt" in
      let _ = Sys.command (Printf.sprintf "sed -i 's/%s/%s/g' %s" timepointold !timepoint filemodel)   in
      let chan = open_in tmp_file in
      close_in chan
      in
      string_of_command4d();  

    (* End - Update the clock time in the 01_ini_state.txt file *)



    (* End get the Hint colors*)
    
    let col = ["R";"B";"G";"Y"] in



    let x2 = ref 0 in
    let xx = ref 16 in
    let c2 = ref "C" in

    (*for x = 1 to !xx do*)
    for x =  int_of_string cardnum to int_of_string cardnum do
      for i = 0 to 3 do
        (* Here we are passing THE GOAL to be tested if with the 01_INI_STATE we can reach it !!! *)
        x2 := x;
        c2 := (List.nth col i);
        mark x2 c2;
      done
    done;
    Printf.printf " Deduction process finished !!! - See the generated formulas in ../yokai/solvedatacp/mark_*.* \n";
  end;
end