open Types
open Types.Ast
open Pprint

module E = Expand
module N = Nnf
module R = Reduc
module S = Simp
module T1 = Tra1
module T2 = Tra2


(* [is_clause] checks that the given AST is a clause. This function can only
   be called on an AST containing Or, And or Not. No Equiv or Implies! *)
let rec is_clause (ast:Ast.t) : bool = match ast with
  | Top | Bottom | Prop _ | Not (Prop _) -> true
  | Or (x,y) -> is_clause x && is_clause y
  | And _ -> false
  | _ -> false

(** [push_lit] allows to translate into CNF the non-CNF disjunction [d or cnf]
    ([d] is the literal we want to add, [cnf] is the existing CNF form).
    For example:
    {[
          d  or  ((a or not b) and (not c))            <- is not in CNF
    <=>   push_lit (d) ((a or not b) and not c)
    <=>   (d or a or b) and (d or not c)               <- is in CNF
    ]}
    This function is necessary because [d or cnf] (with [cnf] an arbitrary CNF
    form) is not a CNF form and must be modified. Conversely, the form
          [d  and  ((a or not b) and (not c))]
    doesn't need to be modified because it is already in CNF.  *)

(** [fresh_dummy] generates a 'dummy' proposition named ["&i"] with [i] being a
    self-incrementing index.
    This function allows to speed up and simplify the translation of some
    forms of Or.
    NOTE: OCaml's functions can't have 0 param: we use the unit [()]. *)
let dummy_term_count = ref 0
let fresh_dummy () =
  incr dummy_term_count; Prop ("&" ^ (string_of_int !dummy_term_count))

let is_dummy (name:string) : bool = (name).[0] = '&'

let debug = ref false (* The debug flag activated by --debug-cnf *)

(** [print_debug] is just printing debug info in [to_cnf] *)
let print_debug (prefix:string) depth (formulas:Ast.t list) : unit =
  (* [indent] creates a string that contains N indentations *)
  let rec indent = function 0 -> "" | i -> (indent (i-1))^"\t"
  and string_of_asts = function
    | [] -> ""
    | cur::[] -> string_of_ast ~utf8:true cur
    | cur::next -> (string_of_ast ~utf8:true cur)^", "^(string_of_asts next)
  in print_endline ((indent depth) ^ (string_of_int depth) ^ " " ^ prefix
                    ^ (string_of_asts formulas))

(** [stop] is a type is used in [to_cnf] in order to stop it after a number of
   recursions. See (1) below *)
type stop = No | Yes of int

let rec ast_to_cnf ?debug_cnf:(d=false) (ast:Ast.t) : Ast.t =
  debug := d;
  to_cnf 0 No ast

(** Actual logic of [ast_to_cnf]
    [depth] tells what is the current level of recursion and
    helps for debugging the translation to CNF.
    [stop] tells to_cnf if it should stop or continue the recursion.

    - (1) When transforming to CNF, we want to make sure that "outer" to_cnf
        transformations are made before inner ones. For example, in
        {v
            to_cnf (Not (to_cnf ((a and b) => c)))
        v}
        we want to limit the inner [to_cnf] expansion to let the possibily for
        the outer to_cnf to "simplify" with the Not as soon as possible.
        For inner [to_cnf], we simply use [to_cnf_once] to prevent the inner
        [to_cnf] from recursing more than once.
    - (2) All bottom and top must disappear for the CNF transformation; we use
        the standard transformation to remove them (a and not a, b or not b) *)
and to_cnf depth (stop:stop) (ast:Ast.t) : Ast.t =
  if !debug then print_debug "in:  " depth [ast];
  if depth = 0 then
    (*Printf.printf "DEPTH DEPTH DEPTH DEPTH DEPTH DEPTH DEPTH :::::::::: %i \n\n\n\n\n\n\n\n\n\n" depth;*)
    (* 09/01/2021 *)
    Printf.printf "\n\n\n\n TOTAL DEL ARBOL  :::::::::: %s \n\n\n\n\n\n\n\n\n\n" (Pprint.string_of_ast ast);
    Printf.printf "\n\n\n\n FINAL FINAL TOTAL DEL ARBOL \n\n\n\n\n\n\n\n\n\n";
    (*let _ = exit(1) in - Comment on 2021/01/11 *)
    (* Fin *)


    let string_of_command () =
      let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
      (*let _ = Sys.command @@ "echo '"^ (Pprint.string_of_ast ast)^"' >" ^ tmp_file  in*)
      let _ = Sys.command @@ "echo 'artificio' >" ^ tmp_file  in
      let chan = open_in tmp_file in
      close_in chan
      in
      string_of_command();
      ;
      

      (* Save the AST output in example.dat  *)
      let file = "example.dat" in
      let () =
        let oc = open_out file in    (* create or truncate file, return channel *)
        Printf.fprintf oc "%s\n" (Pprint.string_of_ast ast);   (* write something *)   
        close_out oc in 
      (* End_Save the AST output in example.dat  *) 


      let string_of_command1 () =
          let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
          (*let _ = Sys.command @@ "sed '/<=>/q;p' ../sdata/00_cp_pre_syntax.txt > ../sdata/00_cp_pre_syntax_xx.txt" in*)
          let _ = Sys.command @@ "cat example.dat > ../sdata/00_cp_pre_syntax.txt" in
          let chan = open_in tmp_file in
          close_in chan
          in
          string_of_command1();

   



          let string_of_command2c () =
            let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
            let _ = Sys.command @@ "sed -i 's/\\(([0-9]*,[A-Z],\\)/\\1t/g' ../sdata/00_cp_pre_syntax.txt" in
            let chan = open_in tmp_file in
            close_in chan
            in
            string_of_command2c();  

            
          let string_of_command2c () =
            let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
            let _ = Sys.command @@ "sed -i 's/\\(([0-9]*,p_[0-9]*_[0-9]*,\\)/\\1t/g' ../sdata/00_cp_pre_syntax.txt" in
            let chan = open_in tmp_file in
            close_in chan
            in
            string_of_command2c();  
            
          (*let string_of_command2c () =
            let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
            let _ = Sys.command @@ "sed -i 's/\\(([0-9]*,\\)/\\1t/g' ../sdata/00_cp_pre_syntax.txt" in
            let chan = open_in tmp_file in
            close_in chan
            in
            string_of_command2c(); *)               
            
            
          let string_of_command2c () =
            let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
            let _ = Sys.command @@ "sed -i 's/\\(([0-9]*,[0-9]*,\\)/\\1t/g' ../sdata/00_cp_pre_syntax.txt" in
            let chan = open_in tmp_file in
            close_in chan
            in
            string_of_command2c();    

         
            
        
              


(* Faltan para los otros movimientos :  Mark / Act *)






          let string_of_command2c () =
            let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
            let _ = Sys.command @@ "sed -i 's/th_now_(\\([^()]*\\))/th_now_\\1/' ../sdata/00_cp_pre_syntax.txt" in
            let chan = open_in tmp_file in
            close_in chan
            in
            string_of_command2c();                                


          let string_of_command2c () =
              let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
              let _ = Sys.command @@ "sed -i 's/col(\\([^()]*\\))/col_\\1/g' ../sdata/00_cp_pre_syntax.txt" in
              let chan = open_in tmp_file in
              close_in chan
              in
              string_of_command2c();          

          let string_of_command2c () =
                  let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                  let _ = Sys.command @@ "sed -i 's/pos(\\([^()]*\\))/pos_\\1/g' ../sdata/00_cp_pre_syntax.txt" in
                  let chan = open_in tmp_file in
                  close_in chan
                  in
                  string_of_command2c();     
                  
          let string_of_command2c () =
                  let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                  let _ = Sys.command @@ "sed -i 's/act(\\([^()]*\\))/act_\\1/g' ../sdata/00_cp_pre_syntax.txt" in
                  let chan = open_in tmp_file in
                  close_in chan
                  in
                  string_of_command2c();                   


          let string_of_command2c () =
                    let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                    let _ = Sys.command @@ "sed -i 's/mark(\\([^()]*\\))/mark_\\1/g' ../sdata/00_cp_pre_syntax.txt" in
                    let chan = open_in tmp_file in
                    close_in chan
                    in
                    string_of_command2c();                         

                      
          let string_of_command2c () =
                let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                let _ = Sys.command @@ "sed -i 's/t,/t/g' ../sdata/00_cp_pre_syntax.txt" in
                let chan = open_in tmp_file in
                close_in chan
                in
                string_of_command2c();    



          let string_of_command2c () =
                  let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                  let _ = Sys.command @@ "sed -i 's/(0)/_t0/g' ../sdata/00_cp_pre_syntax.txt" in
                  let chan = open_in tmp_file in
                  close_in chan
                  in
                  string_of_command2c();        

                  

        let string_of_command2c () =
                    let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                    let _ = Sys.command @@ "sed -i 's/(1)/_t1/g' ../sdata/00_cp_pre_syntax.txt" in
                    let chan = open_in tmp_file in
                    close_in chan
                    in
                    string_of_command2c();     
                    
                    

        let string_of_command2c () =
                    let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                    let _ = Sys.command @@ "sed -i 's/(2)/_t2/g' ../sdata/00_cp_pre_syntax.txt" in
                    let chan = open_in tmp_file in
                    close_in chan
                    in
                    string_of_command2c();       
                    
                    

        let string_of_command2c () =
                    let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                    let _ = Sys.command @@ "sed -i -e 's/(3)/_t3/g' -e 's/(4)/_t4/g' -e 's/(5)/_t5/g' -e 's/(6)/_t6/g' -e 's/(7)/_t7/g' ../sdata/00_cp_pre_syntax.txt" in
                    let chan = open_in tmp_file in
                    close_in chan
                    in
                    string_of_command2c();  



        let string_of_command2c () =
                      let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                      let _ = Sys.command @@ "sed -i 's/(8)/_t8/g' ../sdata/00_cp_pre_syntax.txt" in
                      let chan = open_in tmp_file in
                      close_in chan
                      in
                      string_of_command2c();  


        let string_of_command2c () =
                        let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                        let _ = Sys.command @@ "sed -i 's/(9)/_t9/g' ../sdata/00_cp_pre_syntax.txt" in
                        let chan = open_in tmp_file in
                        close_in chan
                        in
                        string_of_command2c();                        


                        let string_of_command2c () =
                          let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                          let _ = Sys.command @@ "sed -i 's/(10)/_t10/g' ../sdata/00_cp_pre_syntax.txt" in
                          let chan = open_in tmp_file in
                          close_in chan
                          in
                          string_of_command2c();   

                          let string_of_command2c () =
                            let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                            (*let _ = Sys.command @@ "sed -i 's/(11)/_t11/g' ../sdata/00_cp_pre_syntax.txt" in*)
                            let _ = Sys.command @@ "sed -i -e 's/(11)/_t11/g' -e 's/(12)/_t12/g' -e 's/(13)/_t13/g' -e 's/(14)/_t14/g' -e 's/(15)/_t15/g' -e 's/(16)/_t16/g' -e 's/(17)/_t17/g' -e 's/(18)/_t18/g' -e 's/(19)/_t19/g' -e 's/(20)/_t20/g' -e 's/(21)/_t21/g' -e 's/(22)/_t22/g' -e 's/(23)/_t23/g' -e 's/(24)/_t24/g' -e 's/(25)/_t25/g' -e 's/(26)/_t26/g' -e 's/(27)/_t27/g' -e 's/(28)/_t28/g' -e 's/(29)/_t29/g' -e 's/(30)/_t30/g' -e 's/(31)/_t31/g' -e 's/(32)/_t32/g' -e 's/(33)/_t33/g' -e 's/(34)/_t34/g' -e 's/(35)/_t35/g' -e 's/(36)/_t36/g' -e 's/(37)/_t37/g' -e 's/(38)/_t38/g' -e 's/(39)/_t39/g' -e 's/(40)/_t40/g' -e 's/(41)/_t41/g' -e 's/(42)/_t42/g' -e 's/(43)/_t43/g' -e 's/(44)/_t44/g' ../sdata/00_cp_pre_syntax.txt" in
                            let chan = open_in tmp_file in
                            close_in chan
                            in
                            string_of_command2c();   


                          let string_of_command2c () =
                            let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                            (*let _ = Sys.command @@ "sed -i 's/(11)/_t11/g' ../sdata/00_cp_pre_syntax.txt" in*)
                            let _ = Sys.command @@ "sed -i -e 's/(45)/_t45/g' -e 's/(46)/_t46/g' -e 's/(47)/_t47/g' -e 's/(48)/_t48/g' -e 's/(49)/_t49/g' -e 's/(50)/_t50/g' -e 's/(51)/_t51/g' -e 's/(52)/_t52/g' -e 's/(53)/_t53/g' -e 's/(54)/_t54/g' -e 's/(55)/_t55/g' -e 's/(56)/_t56/g' ../sdata/00_cp_pre_syntax.txt" in
                            let chan = open_in tmp_file in
                            close_in chan
                            in
                            string_of_command2c();   





          let string_of_command2c () =
                  let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                  let _ = Sys.command @@ "sed -i 's/,/_/g' ../sdata/00_cp_pre_syntax.txt" in
                  let chan = open_in tmp_file in
                  close_in chan
                  in
                  string_of_command2c();                        



          (* Fin - 2021/05/28*) 
     

(*

1. In cp_pre_syntax, it is possible to transfer the Initial State and the Goal formulas, already extended, then we can select the last part and copy to 03_goal. 
So the Initial State will be in 01_model and then both files will be fusion with 02_actions, which will generate by the planer.ml 

2.  In addition we need to perfom the separatin AFTER we apply the next replacements in cp_pre_syntax text file 

*)

(*********************)

      let string_of_command1 () =
        let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
        (*let _ = Sys.command @@ "sed '/<=>/q;p' ../sdata/00_cp_pre_syntax.txt > ../sdata/00_cp_pre_syntax_xx.txt" in*)
        let _ = Sys.command @@ "cat ../sdata/00_cp_pre_syntax.txt > ../sdata/00_cp_pre_syntax_xx.txt" in
        let chan = open_in tmp_file in
        close_in chan
        in
        string_of_command1();
            

          let string_of_command3() =
            let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
            let _ = Sys.command @@ "sed -i 's/)\"/_/g' ../sdata/00_cp_pre_syntax_xx.txt" in
            let chan = open_in tmp_file in
            close_in chan
            in
            string_of_command3();

            let string_of_command5() =
                let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                let _ = Sys.command @@ "sed -i 's/) <=>/_ <=>/g' ../sdata/00_cp_pre_syntax_xx.txt" in
                let chan = open_in tmp_file in
                close_in chan
                in
                string_of_command5();

            let string_of_command7() =
                    let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                    let _ = Sys.command @@ "sed -i 's/_)//g' ../sdata/00_cp_pre_syntax_xx.txt" in
                    let chan = open_in tmp_file in
                    close_in chan
                    in
                    string_of_command7();


            (* YOKAI --> Generation of 01_ini_state.txt *)
            let string_of_command15() =
                        let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                        let _ = Sys.command @@ "cat ../sdata/00_cp_pre_syntax_xx.txt > ../sdata/03_goal.txt" in
                        let chan = open_in tmp_file in
                        close_in chan
                        in
                        string_of_command15();  


                         
            (* YOKAI --> Generation of 03_goal.txt *)
            (*
            let returncode = (Sys.command "grep -o 'GOAL.*' ../sdata/00_cp_pre_syntax_xx.txt > ../sdata/03_goal.txt") in
            flush stdout; flush stderr;
            if returncode == 0 then Printf.printf ""
            else Printf.printf "[Error ] not possible to generate file solvedatacp/solver_ini_state 1.txt ";

            let string_of_command14() =
                      let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                      let _ = Sys.command @@ "sed -i 's/GOAL and (//g' ../sdata/03_goal.txt" in
                      let chan = open_in tmp_file in
                      close_in chan
                      in
                      string_of_command14();

            let string_of_command14() =
                      let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                      let _ = Sys.command @@ "sed -i 's/and (FIN and GOAL)))))))))))))))))))))))//g' ../sdata/03_goal.txt" in
                      let chan = open_in tmp_file in
                      close_in chan
                      in
                      string_of_command14();

            (*Remove the last character of the text file - in this case delete the last ")" *)
            let string_of_command17() =
              let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
              let _ = Sys.command @@ "sed -i '$ s/.$//' ../sdata/03_goal.txt" in
              let chan = open_in tmp_file in
              close_in chan
              in
              string_of_command17();
              

              

              let string_of_command14() =
                let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                let _ = Sys.command @@ "sed -i 's/ )))))//g' ../sdata/03_goal.txt" in
                let chan = open_in tmp_file in
                close_in chan
                in
                string_of_command14();
*)



              (* Fin - 2021/05/28*)    
(*
              let string_of_command17() =
                let tmp_file = "../sdata/00_cp_pre_syntax.txt" in
                let _ = Sys.command @@ "sed -i '$ s/.$//' ../sdata/01_ini_state.txt" in
                let chan = open_in tmp_file in
                close_in chan
                in
                string_of_command17();
*)                

  if depth = 0 then    
    exit 0;



  if (match stop with Yes 0 -> true | _ -> false) then ast else (* See (1) above*)
    let to_cnf_once = to_cnf (depth+1) (match stop with Yes i->Yes (i-1) | No->Yes 1) in
    let to_cnf = to_cnf (depth+1) (match stop with Yes i->Yes (i-1) | No->No) in
    let cnf = begin match ast with
    | Top when depth=0 -> let t = fresh_dummy () in Or (t,Not t) (* See (2) above *)
    | Top -> Top
    | Bottom when depth=0 -> let t = fresh_dummy () in And (t,Not t) (* See (2) *)
    | Bottom -> Bottom
    | Prop x -> Prop x
    | And (x,y) -> let (x,y) = (to_cnf x, to_cnf y) in
      begin
        match x,y with
        | Top,x | x,Top     -> x
        | Bottom,_|_,Bottom -> Bottom
        | x,y               -> And (x,y)
      end

    | Or (x,y) -> let (x,y) = (to_cnf x, to_cnf y) in
      begin
        match x,y with
        | Top,x | x,Top     -> x
        | Bottom,_|_,Bottom -> Bottom
        | x,y               -> Or (x,y)
      end


    | Th x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | x          -> Th x
      end

    | Not x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | Prop x     -> Not (Prop x)
        | Not x     -> to_cnf x
        | Ba x     -> Not (Ba (to_cnf x)) 
        | Box x    -> Not (Box (to_cnf x))         
        | Bh x     -> Not (Bh (to_cnf x)) 
        | Da x     -> Not (Da (to_cnf x)) 
        | Dia x     -> Not (Dia (to_cnf x))         
	      | Dh x     -> Not (Dh (to_cnf x)) 
        | Ta x     -> Not (Ta (to_cnf x)) 
        | Th x     -> Not (to_cnf (Th x)) 
        | And (x,y) -> Or  (to_cnf (Not x), to_cnf (Not y)) (* De Morgan *)
        | Or (x,y)  -> And (to_cnf (Not x), to_cnf (Not y)) (* De Morgan *)
        | _ -> to_cnf (Not (to_cnf_once x)) (* See (1) above*)
      end

    | Plusa (x,y) -> let (x,y) = (to_cnf x, to_cnf y)  in 
      begin 
        match x, y with
            | x, y -> Ba (Implies(to_cnf x, to_cnf y))
      end  


    | Plush (x,y) -> let (x,y) = (to_cnf x, to_cnf y)  in 
      begin 
        match x, y with
        | r, And(x,y) -> to_cnf (And(Plush(r,x), Plush(r,y)))
        | r, Or(x,y) -> to_cnf (Or(Plush(r,x), Plush(r,y)))      
        | x, Ta y when x = y -> Top
        | x, Th y when x <> y -> Th y
        | x, Ba y -> Ba (Implies(to_cnf x,to_cnf y)) 
        | x, Box y -> Box (Implies(to_cnf x,to_cnf y))         
        | _, Bh y -> Bh (to_cnf y)
        | x, Da y -> Da (And(to_cnf x,to_cnf y)) 
        | x, Dia y -> Dia (And(to_cnf x,to_cnf y))         
        | _, Dh y -> Dh (to_cnf y)
        | _,x     -> to_cnf x    
      end  

    | Hh x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | x          -> Hh (to_cnf x)
      end



    | Ta x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | x          -> Ta (to_cnf x)
      end  

      
      
    | Ha x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | x          -> Ha (to_cnf x)
      end      

        
    | Ba x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | x          -> Ba (to_cnf x)
      end

    | Box x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | x          -> Box (to_cnf x)
      end      

    | Bh x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | x          -> Bh (to_cnf x)
      end  

      
    | Da x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | x          -> Da (to_cnf x)
      end

    | Dia x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | x          -> Dia (to_cnf x)
      end

    | Dh x ->
      begin
        match x with
        | Top        -> Bottom
        | Bottom     -> Top
        | x          -> Dh (to_cnf x)
      end



    (* Note on [Or] and the Tseytin transform:
           When translating [x or y] into CNF and that either x or y is a
           conjunction (= isn't a clause), we must avoid the 'natural' translation
           that should occur when translating (1) into (2): (2) would have an
           exponential number of clauses. Instead, we use arbitrary variables
           created by [genterm], denoted by &1, &2... and use the Tseytin
           transform (3) which yields a linear number of clauses.
                (x1 and y1)  or  (x2 and y2)                                (1)
                (x1 or x2) and (x1 or y2) and (y1 or x2) or (etc...)        (2)
                (&1 or &2) and (not &1 or x1) and (not &1 or y1)            (3)
                          and (not &2 or x2) and (not &2 or y2)
        *)
    | Implies (x,y) -> to_cnf (Or (Not x, y))
    | Equiv (x,y) -> to_cnf (And (Implies (x,y), Implies (y,x)))
    | Xor (x,y) -> to_cnf (And (Or (x,y), Or (Not x, Not y)))
    | _ -> failwith ("cnf + [shouldnt happen] this doesn't seem to be a formula: '"
      ^ (string_of_ast ~debug:true ast) ^ "'")
    end
    in

    (*print_debug "out : " depth [cnf];*)
    if !debug then print_debug "out: " depth [cnf];
    (* Last important thing: make sure no more Bot/Top are in the formula. *)
    if depth=0 && Eval.has_top_or_bot cnf then to_cnf cnf else cnf


let clauses_of_cnf (neg:'a->'a) (fresh:unit->'a) (ast:Ast.t)
  : 'a list list * ('a, string) Hashtbl.t * (string, 'a) Hashtbl.t =
  (* num = a number that will serve to identify a literal
      lit = a literal that has a number inside it to identify it *)
  let str_to_lit = Hashtbl.create 500 in
  let lit_to_str = Hashtbl.create 500 in (* this duplicate is for the return value *)
  let rec process_cnf ast : 'a list list = match ast with
    | And  (x,y) -> (process_cnf x) @ (process_cnf y)
    | x when is_clause x -> [process_clause x]
    | _ -> failwith ("CNF: was expecting a conjunction of clauses but got '" ^ (string_of_ast ~debug:true ast) ^ "'")
  and process_clause (ast:Ast.t) : 'a list = match ast with
    | Prop str        -> (gen_lit str)::[]
    | Not (Prop str) -> (neg (gen_lit str))::[]
    | Or (x,y) -> process_clause x @ process_clause y
    | _ -> failwith ("CNF: was expecting a clause but got '" ^ (string_of_ast ~debug:true ast) ^ "'")
  and gen_lit (s:string) : 'a =
    try Hashtbl.find str_to_lit s
    with Not_found ->
      (let lit = fresh () in
       Hashtbl.add str_to_lit s lit;
       Hashtbl.add lit_to_str lit s;
       lit)
  in let clauses = process_cnf ast in clauses, lit_to_str, str_to_lit

let print_table (int_of_lit: 'a->int) (out:out_channel) ?(prefix="") (table:('a,string) Hashtbl.t) =
  let print_lit_and_name lit name = Printf.fprintf out "%s%s %d\n" prefix name (int_of_lit lit)
  in Hashtbl.iter print_lit_and_name table

let print_clauses (out:out_channel) ?(prefix="") (str_of_lit: 'a->string) (clauses:'a list list) : unit =
  let rec string_of_clause (cl:'a list) = match cl with
    | [] -> "0"
    | cur::next -> (str_of_lit cur) ^" "^ (string_of_clause next)
  and print_listclause (cl:'a list list) = match cl with
    | [] -> ()
    | cur::next -> Printf.fprintf out "%s%s\n" prefix (string_of_clause cur); print_listclause next
  in
  print_listclause clauses