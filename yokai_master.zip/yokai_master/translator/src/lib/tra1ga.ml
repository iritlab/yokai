(*########################################################*)
(*         Ast pour les formules de logique modale        *)
(*########################################################*)

(** This module explicits the AST of modal logic formulas *)

open Types.Ast

let getTra = function
    | x ->  And(Ba( And (Prop "now_0",
                        And(
                        And(Implies(Prop "now_1", Prop "now_0"), Implies(Prop "now_2", Prop "now_1")),
                        And(And(Equiv(Prop "now_1", Prop "tm_now_1"), Equiv(Not (Prop "now_1"), Not (Prop "tm_now_1"))),
                            And(Equiv(Prop "now_2", Prop "tm_now_2"), Equiv(Not (Prop "now_2"), Not (Prop "tm_now_2"))))
                        
                        )))
            ,x)


            
(*            
            let getTra = function
            | x ->  And(Ba( And (Prop "now_0",
                                And(
                                And(Implies(Prop "now_1", Prop "now_0"), Implies(Prop "now_2", Prop "now_1")),
                                And(And(Equiv(Prop "now_1", Prop "tm_now_1"), Equiv(Not (Prop "now_1"), Not (Prop "tm_now_1"))),
                                    And(Equiv(Prop "now_2", Prop "tm_now_2"), Equiv(Not (Prop "now_2"), Not (Prop "tm_now_2"))))
                                
                                )))
                    ,x)
*)                    




(*
let getTra = function
    | x ->  And(Ba (  And (Prop "now_0",

    And(
    And(Or(Not (Prop "now_1"), Prop "now_0"),Or(Not (Prop "now_2"), Prop "now_1")), 
       
    And(
    And(And(Or(Not (Prop "now_1"), Prop "tm_now_1"), Or(Prop "now_1", Not(Prop "tm_now_1"))),
        And(Or(Prop "now_1", Not (Prop "tm_now_1")), Or(Not(Prop "now_1"), Prop "tm_now_1"))),
    
    And(And(Or(Not (Prop "now_2"), Prop "tm_now_2"), Or(Prop "now_2", Not(Prop "tm_now_2"))),
        And(Or(Prop "now_2", Not (Prop "tm_now_2")), Or(Not(Prop "now_2"), Prop "tm_now_2")))    
    )
    )

    ))  
    ,x) 
*)

(* 
let getTra = function
    | x ->  And(Ba( And ((Prop "now_0"),

                        And(And(And(And(Equiv(Prop "now_0", Prop "now_1"),Equiv(Not (Prop "now_0"), Not (Prop "now_1"))),
                        And(Equiv(Prop "now_1", Prop "now_2"),Equiv(Not (Prop "now_1"), Not (Prop "now_2")))),
                        And(Equiv(Prop "now_2", Prop "now_3"),Equiv(Not (Prop "now_2"), Not (Prop "now_3")))),
                        And(Equiv(Prop "now_3", Prop "now_4"),Equiv(Not (Prop "now_3"), Not (Prop "now_4"))))
            ))
            ,x)
*)




