
(* This file was auto-generated based on "parser.messages". *)

(* Please note that the function [message] can raise [Not_found]. *)

let message =
  fun s ->
    match s with
    | 343 | 341 ->
        "Ill-formed quantifer declaration. After variable $1, either end the list with ':' or continue it with a proposition or variable. Instead, the following statement were read:\n    $0\n"
    | 344 | 342 ->
        "Ill-formed proposition/variable list. After $1, a variable or proposition is expected. Instead, the following statement were read:\n    $0\n"
    | 351 ->
        "Ill-formed 'for' statement. At this point, a ':' is expected.\n"
    | 350 ->
        "Ill-formed 'for' statement. After 'in', a set is expected.\n"
    | 349 ->
        "Ill-formed 'for' statement. After the variable $1, 'in' is expected.\n"
    | 348 ->
        "Ill-formed 'for' statement. At this point, a variable is expected.\n"
    | 354 ->
        "Ill-formed existential quantifier. After $1, a comma-separated list of propositions or variables is expected. Instead, the following statement were read:\n    $0\n"
    | 357 ->
        "Ill-formed existential quantifier. After $1, a QBF formula is expected. Instead, the following statement were read:\n    $0\n"
    | 416 ->
        "Ill-formed existential quantifier. At this point, either continue the QBF formula or begin a new QBF formula (with a new line or a whitespace). Instead, the following statement were read:\n    $0\n"
    | 340 ->
        "Ill-formed universal quantifier. After $1, a comma-separated list of propositions or variables is expected. Instead, the following statement were read:\n    $0\n"
    | 353 ->
        "Ill-formed universal quantifier. After $1, a QBF formula is expected. Instead, the following statement were read:\n    $0\n"
    | 417 ->
        "Ill-formed universal quantifier. At this point, either continue the QBF formula or begin a new QBF formula (with a new line or a whitespace). Instead, the following statement were read:\n    $0\n"
    | 136 | 122 | 291 | 308 ->
        "Ill-formed $2. At this point, either finish the set-expression by ',' or continue it using one of the expression operators.\n"
    | 293 ->
        "Ill-formed $4. At this point, either finish the set-expression by ',' or continue it using one of the expression operators.\n"
    | 123 | 137 | 292 | 309 ->
        "Ill-formed $2. After the comma, an expression (a set) is expected.\n"
    | 310 | 138 | 124 ->
        "Ill-formed $4. At this point, either finish the expression with ')' or continue it using an operator on expressions. Instead, read $0.\n"
    | 306 ->
        "Ill-formed proposition-tuple. At this point, either continue the list of indices (= expressions) using ',' or finish the proposition-tuple using ')'. Instead, the following statement were read: $0\n"
    | 312 ->
        "Ill-formed variable-tuple. At this point, either continue the list of indices (= expressions) using ',' or finish the variable-tuple using ')'. Instead, the following statement were read:\n    $0\n"
    | 304 ->
        "Ill-formed list indices. At this point, an expression is expected (an 'index' is an expression). Instead, the following statement were read:\n    $0\n"
    | 97 | 99 | 112 | 110 ->
        "Ill-formed $1. At this point, an expression is expected. Instead, got $0.\n"
    | 100 | 98 | 84 | 104 | 102 | 108 | 94 | 113 | 80 | 96 | 92 | 106 | 90 | 88 | 86 | 76 | 82 ->
        "Ill-formed expression. At this point, a continuation of the expression is expected. Instead, got $0.\n"
    | 72 | 74 | 111 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 83 | 103 | 79 | 95 | 107 | 93 | 91 | 105 | 89 | 87 | 85 | 77 | 75 | 81 | 101 | 73 | 71 | 148 ->
        "Ill-formed list of expressions. At this point, an expression is expected. Instead, the following statement were read:\n    $0\n"
    | 288 | 70 ->
        "Ill-formed $2. At this point, a continuation of the expression is expected with an operator (<,>,!=,==,and,or...). Instead, the following statement were read:\n    $0\n"
    | 126 | 179 | 117 ->
        "Ill-formed $2. At this point, either finish the set expression with ')' or continue it using an operator (and,or,>,<,!=,==...). Instead, the following statement were read:\n    $0\n"
    | 297 | 299 | 563 | 558 | 535 | 530 | 219 | 214 | 152 | 190 | 359 | 388 | 383 ->
        "Ill-formed $2. At this point, either finish the integer expression using ',' or continue it using an operator.\n"
    | 155 ->
        "Ill-formed set declaration. At this point, either continue the list of expressions or finish it with ']'. Instead, the following statement were read:\n    $0\n"
    | 141 ->
        "Ill-formed range-based set declaration. At this point, an expression is expected (int or float). Instead, the following statement were read:\n    $0\n"
    | 142 ->
        "Ill-formed range-based set declaration. At this point, either finish the expression with ']' or continue it with an operator (<,>,!=,==,and,or...). Instead, the following statement were read:\n    $0\n"
    | 475 | 636 | 464 ->
        "After 'data', you are expected to affect global variable.\n"
    | 522 ->
        "A SMT formula is expected after '\\\\'. $0 does not seem to be a formula.\n"
    | 32 ->
        "A SAT formula is expected after '\\\\'. $0 does not seem to be a formula.\n"
    | 328 ->
        "A QBF formula is expected after '\\\\'. $0 does not seem to be a formula.\n"
    | 461 | 427 ->
        "Ill-formed QBF formula. At this point, either:\n- continue the formula with an operator (and,or,xor,=>,<=>),\n- or begin a new formula by a blank space,\n- or affect a global variable.\nInstead, the following statement were read:\n    $0\n"
    | 634 | 600 ->
        "Ill-formed SMT formula. At this point, either:\n- continue the formula with an operator (and,or,xor,=>,<=>),\n- or begin a new formula by a blank space,\n- or affect a global variable.\nInstead, the following statement were read:\n    $0\n"
    | 256 | 473 ->
        "Ill-formed propositional formula. At this point, either:\n- continue the formula with an operator (and,or,xor,=>,<=>),\n- or begin a new formula by a blank space,\n- or affect a global variable.\nInstead, the following statement were read:\n    $0\n"
    | 232 | 234 | 239 | 237 ->
        "Ill-formed $2. At this point, a continuation of the formula is expected with and,or,=>,... Instead, the following statement were read:\n    $0\n"
    | 233 | 238 | 236 | 231 | 229 | 398 | 400 | 402 | 407 | 405 ->
        "Ill-formed $2. At this point, a formula is expected. Instead, the following statement were read:\n    $0\n"
    | 403 | 401 | 408 | 406 ->
        "Ill-formed $2. At this point, a continuation of the formula is expected, using either and,or,xor,=>,<=>. Instead, the following statement were read:\n    $0\n"
    | 254 | 597 | 425 ->
        "Ill-formed formula. At this point, either finish it with ')' or continue it with and,or,xor,=>,<=>. Instead, the following statement were read:\n    $0\n"
    | 36 ->
        "Ill-formed list of variables. At this point, a variable is expected. Instead, the following statement were read:\n    $0\n"
    | 0 ->
        "Either formula is empty or this QBF formula does not start correctly.\n"
    | 466 ->
        "Either formula is empty or this SAT formula does not start correctly.\n"
    | 477 ->
        "Either formula is empty or this SMT formula does not start correctly.\n"
    | 498 | 504 | 506 | 508 | 510 | 502 ->
        "Ill-formed $1. At this point, a SMT expression is expected. Instead, the following statement were read:\n    $0\n"
    | 499 | 503 | 505 | 507 | 509 | 511 | 512 ->
        "Ill-formed SMT formula. At this point, either begin a new formula or continue the existing one with an operator (and,or,xor,=>,<=>,!=,==,>,<). Instead, the following statement were read:\n    $0\n"
    | 492 | 501 ->
        "Ill-formed SMT expression. At this point, either begin a new expression or continue the existing one with an operator (+,-,*,/). Instead, the following statement were read:\n    $0\n"
    | 483 | 493 | 495 | 500 | 491 ->
        "Ill-formed $1. At this point, an expression is expected. Instead, the following statement were read:\n    $0\n"
    | 575 | 577 | 580 | 582 ->
        "Ill-formed $2. At this point, a continuation of the formula is expected with and,or,=>,... Instead, the following statement were read:\n    $0\n"
    | 576 | 581 | 579 | 574 | 572 ->
        "Ill-formed $1. At this point, a formula is expected. Instead, the following statement were read:\n    $0\n"
    | 599 ->
        "Ill-formed formula. At this point, finish the formula with ')' or continue it with and,or,xor,=>,<=>. Instead, the following statement were read:\n    $0\n"
    | 524 | 34 | 330 ->
        "Ill-formed local variable declaration. At this point, a variable is expected. Instead, the following statement were read:\n    $0\n"
    | 525 | 38 | 331 ->
        "Ill-formed local variable declaration. At this point, '=' is expected. Instead, the following statement were read:\n    $0\n"
    | 526 | 39 | 332 ->
        "Ill-formed local variable declaration. At this point, an expression is expected. Instead, the following statement were read:\n    $0\n"
    | 527 | 182 | 333 ->
        "Ill-formed local variable declaration. At this point, either finish the expression with ':' or continue it with an operator (>,<,!=,==,and,or...). Instead, the following statement were read:\n    $0\n"
    | 528 | 183 | 334 ->
        "Ill-formed local variable declaration. After $1, a formula is expected. Instead, the following statement were read:\n    $0\n"
    | 253 | 596 | 424 ->
        "Ill-formed local variable block. At this point, either finish the formula by starting a new one or continue it with and,or,xor,=>,<=>. Instead, the following statement were read:\n    $0\n"
    | 569 ->
        "At this point, either finish the formula with a new formula or continue it with one of and,or,xor,=>,<=>. Instead, the following statement were read:\n    $0\n"
    | 130 | 185 | 336 ->
        "Ill-formed 'if' statement. At this point, either finish the expression with 'then' or continue it with an operator (<,>,!=,==,and,or...). Instead, the following statement were read:\n    $0\n"
    | 131 ->
        "Ill-formed 'if' statement. At this point, an expression is expected. Instead, the following statement were read:\n    $0\n"
    | 531 | 186 | 337 ->
        "Ill-formed 'if' statement. At this point, either finish the formula with 'else' or continue it with one of and,or,xor,=>,<=>. Instead, the following statement were read:\n    $0\n"
    | 132 ->
        "Ill-formed 'if' statement. At this point, either finish the expression with 'else' or continue it with an operator (<,>,!=,==,and,or...). Instead, the following statement were read:\n    $0\n"
    | 133 ->
        "Ill-formed 'if' statement. At this point, an expression is expected. Instead, the following statement were read:\n    $0\n"
    | 134 ->
        "Ill-formed 'if' statement. At this point, either finish the expression with 'end' or continue it with an operator (<,>,!=,==,and,or...). Instead, the following statement were read:\n    $0\n"
    | 592 | 249 | 420 ->
        "Ill-formed 'if' statement. At this point, either finish the formula with 'else' or continue it with one of and,or,xor,=>,<=>. Instead, the following statement were read:\n    $0\n"
    | 593 | 250 | 421 ->
        "Ill-formed 'if' statement. After $1, a formula is expected. Instead, the following statement were read:\n    $0\n"
    | 594 | 251 | 422 ->
        "Ill-formed 'if' statement. At this point, either finish the formula with 'end' or continue it with one of and,or,xor,=>,<=>. Instead, the following statement were read:\n    $0\n"
    | 550 | 544 | 206 | 200 | 369 | 375 ->
        "Ill-formed $2. At this point, either continue the list or variables with ',' or finish it with 'in'. Instead, the following statement were read:\n    $0\n"
    | 551 | 545 | 207 | 201 | 370 | 376 ->
        "Ill-formed $3 operator. After $1, a comma-separated list of set expressions is expected. Instead, the following statement were read:\n    $0\n"
    | 552 | 546 | 208 | 202 | 371 | 377 ->
        "Ill-formed $4. At this point, either continue the set expression list with ',' or finish it with 'when' or ':'. Instead, the following statement were read:\n    $0\n"
    | 203 | 209 | 547 | 553 | 372 | 378 ->
        "Ill-formed $5. At this point, ':' is expected. Instead, the following statement were read:\n    $0\n"
    | 554 | 548 | 210 | 204 | 373 | 379 ->
        "Ill-formed $6. After $1, a formula is expected. Instead, the following statement were read:\n    $0\n"
    | 571 | 584 | 228 | 241 | 410 | 397 ->
        "Ill-formed $7. At this point, either finish by 'end' the formula or continue the formula with one of and,or,xor,=>,<=>. Instead, the following statement were read:\n    $0\n"
    | 4 ->
        "Ill-formed term-tuple. At this point, a comma-separated list of expressions (which we call 'indices' of the variable-tuple) is expected. Instead, the following statement were read:\n    $0\n"
    | 469 | 630 | 457 ->
        "Ill-formed global variable affectation. At this point, either continue the expression with an operator (+,-,>=,!=,==,and,or...) or begin a new formula.\n"
    | 468 | 629 | 456 ->
        "Ill-formed global variable affectation. At this point, an expression is expected. Instead, the following statement were read:\n    $0\n"
    | 467 | 628 | 455 ->
        "Either the variable $1 was meant to be part of a formula, in which case the formula must end (I dont know exactly why when I wrote this error). Or you wanted to affect $1, in which case '=' is expected. Instead, the following statement were read:\n    $0\n"
    | 1 ->
        "Ill-formed variable-tuple. At this point, a comma-separated list of expressions (which we call 'indices' of the variable-tuple). Instead, the following statement were read:\n    $0\n"
    | 523 | 33 | 520 | 30 | 326 ->
        "Ill-formed $1. At this point, a formula is expected. Instead, the following statement were read:\n    $0\n"
    | 549 | 543 | 205 | 199 | 368 | 374 ->
        "Ill-formed $1. At this point is expected a comma-separated list of variables, i.e., '$i,$j'. Instead, the following statement were read:\n    $0\n"
    | 46 ->
        "Ill-formed $1. At this point is expected a boolean expression. Instead, read $0.\n"
    | 160 | 290 ->
        "Ill-formed $2. At this point, a continuation of the expression is expected. Instead, read $0.\n"
    | 58 | 51 | 12 | 3 ->
        "Ill-formed $3. A set expression is expected at this point. Instead, read $0.\n"
    | 329 ->
        "Ill-formed $1. At this point is expected a QBF expression. Instead, the following statement were read:\n    $0\n"
    | 484 ->
        "Ill-formed $1. At this point is expected an SMT expression. Instead, the following statement were read:\n    $0\n"
    | 48 ->
        "Ill-formed $1. At this point is expected an expression. Instead, the following statement were read:\n    $0\n"
    | 490 ->
        "Ill-formed $1. At this point, either finish the SMT expression with ')' or continue it with an operator (>,<,>=,<=,!=,==,+,-,/,*). Instead, the following statement were read:\n    $0\n"
    | 157 ->
        "Ill-formed $1. At this point, either finish the expression with ')' or continue it with an operator (>,<,!=,==,and,or...). Instead, the following statement were read:\n    $0\n"
    | 8 | 7 | 14 | 67 | 13 ->
        "Ill-formed $1. At this point is expected an int or float expression. Instead, the following statement were read:\n    $0\n"
    | 153 ->
        "Ill-formed set definition (list comprehension). At this point, ']' is expected.\n"
    | 150 ->
        "Ill-formed set definition (list comprehension). Either finish the list of sets with ']' or continue with a conditionnal statement 'when'.\n"
    | 146 ->
        "Ill-formed set definition. In a list comprehension, a comma-separated list of sets is expected after 'in'.\n"
    | 145 ->
        "Ill-formed set definition. In a list comprehension, 'in' is expected after the list of variables.\n"
    | 144 ->
        "Ill-formed set definition. A list comprehension expects a list of variables after 'for'.\n"
    | 49 ->
        "Ill-formed set definition. At this point is expected one of the following:\n- a comma-separated of floats, integers or proposition expressions;\n- a float or integer expression followed by '..';\n- an expression followed by 'for' (list comprehension).\nInstead, the following statement were read:\n    $0\n"
    | 284 ->
        "At this point, either finish the quoted formula with '\"' or continue the propositional formula with 'and', 'or', 'xor', '=>' or '<=>'.\n"
    | 17 ->
        "After '\"', a propositional formula is expected. Instead, read:\n    $0\n"
    | 62 | 57 | 41 ->
        "Ill-formed $3. A set expression is expected at this point. Instead, the following statement were read:\n    $0\n"
    | 529 | 184 | 53 | 335 | 151 ->
        "Ill-formed $3. At this point, a boolean expression is expected (not a formula!). Instead, the following statement were read:\n    $0\n"
    | 562 | 557 | 534 | 218 | 213 | 189 | 358 | 382 | 387 ->
        "Ill-formed $3. At this point, an integer expression is expected. Instead, the following statement were read:\n    $0\n"
    | 564 | 559 | 536 | 220 | 215 | 191 | 360 | 384 | 389 ->
        "Ill-formed $3. An expression is expected after $1. Instead, the following statement were read:\n    $0\n"
    | 565 | 560 | 537 | 221 | 216 | 192 | 361 | 390 | 385 ->
        "Ill-formed $4. Either finish it with ')' or continue the expression beginning with:\n    $1\nInstead, the following statement were read:\n    $0\n"
    | _ ->
        raise Not_found
