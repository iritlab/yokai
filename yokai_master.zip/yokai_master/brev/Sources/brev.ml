open Printf

class t  (score:string) (svol:string) (sinput:string) (encoding : int) =
object (self)

(* brev/brev -e s score.txt 00_delta0_base.txt interfacefx.txt *)
 
  method search = (* notimed_search *)

let command cmd =
  Sys.command cmd
in

let replace2 input output =
  Str.global_replace (Str.regexp_string input) output in

let filescore = "../sdata/"^score in
let filesvol = "../sdata/"^svol in
let filesinput = "../sdata/"^sinput in
let filetouist = "../sdata/main.exe" in
let filesvol_final = "../sdata/00_delta0.txt" in
let filesinput2 = "../sdata/04_input.txt" in
let filesetssamecolor = "../sdata/00_sets_same_color.txt" in
let filesetssamecolorhint = "../sdata/00_sets_same_colorhint.txt" in
let filemarkcards = "../sdata/00_sets_mark_cards.txt" in
let bordercards = "../sdata/00_border_cards.txt" in
let ilegalpositions = "../sdata/00_ilegal_positions.txt" in
let ilegalpositionsfinal = "../sdata/00_ilegal_positions.txt.final" in
let mk_cards = "../sdata/00_mk_cards.txt" in
let hk_cards = "../sdata/00_hk_cards.txt" in
let mk_cards_colors = "../sdata/00_mk_cards_colors.txt" in
let fileHintColors = "../sdata/00_hint_colors.txt" in




let filesvolfilter = "../sdata/"^svol^".filter" in
let filesvolnofilter = "../sdata/"^svol^".nofilter" in




let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in



let clock = List.nth (lines_from_files "../sdata/99_clock.txt") 0 in
let clock2 = ref 0 in
clock2 := (int_of_string clock) + 1;
Printf.printf "***** Despues del Clock : \n" ;

let numCardsGrouped = ref 0 in


(*

flush stdout; flush stderr;
Utils.print "Select TouIST @@@ xxx\n";
flush stdout; flush stderr;
(*let returncode = (command "./main.exe --version") in*)
let returncode = (command (Printf.sprintf "%s --version" filetouist)) in

flush stdout; flush stderr;
if returncode == 0 then Utils.print "returncode == 0"
else begin Utils.eprint "[Error %d] please install TouIST with : brew install touist\n" returncode; exit returncode; end;
*)


(* Opcion de llamada: s *)
(* Usada para grabar los nuevos movimientos en la Z_volatile side *)
Printf.printf "***** Despues de Opcion de llamada : \n" ;

if (encoding == 100) then


begin
Printf.printf "ENTRO 100 \n";
Printf.printf "sc : %s \n" filescore;
Printf.printf "sv : %s \n" filesvol;
Printf.printf "si : %s \n" filesinput;
Printf.printf "touist : %s \n" filetouist;







let read_line i = try Some (input_line i) with End_of_file -> None  in

let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in

    let rec extract k list =
        if k <= 0 then [ [] ]
        else match list with
            | [] -> []
              | h :: tl ->
                  let with_h = List.map (fun l -> h :: l) (extract (k-1) tl) in
                  let without_h = extract k tl in
                  with_h @ without_h in

    let flatten l =
      let rec loop res = function
        | [] -> List.rev res
        | h::t -> loop (List.rev_append h res) t
      in
        loop [] l in   

  let rec at k = function
        | [] -> None
        | h :: t -> if k = 1 then Some h else at (k - 1) t in        

  Printf.printf "touistcode ==>  ACA before plan\n";


(* Update the time point for all elements in ZVol *)
let string_of_command4 () =
    let tmp_file = filescore in
    let _ = Sys.command (Printf.sprintf "sed -i -r 's/(_t[0-9]+)/_t%i/g' ../sdata/00_delta0_base.txt" !clock2)   in
    let chan = open_in tmp_file in
            close_in chan
            in
    string_of_command4();   
    
    

(*  00_delta0_base.txt*)

let plan m = 
    let touistcode2 = ref 99 in 

    (* Verify ZInput is not in contradiction with ZCore*)      
    (*touistcode2 := (command (Printf.sprintf "(cat filescore; cat brevdata/sinput.txt) | ./touist.exe --sat --solve - > brevsets/out.emodel_01.txt 2> brevsets/out.touisterr_01.txt"));*)

    (*touistcode2 := (command (Printf.sprintf "./main.exe brevsets/x_%i_%i.txt > brevsets/xs_%i_%i.txt" !m !i !m !i));*)
    (*Printf.printf "touistcode ==>  %i \n" !touistcode2;*)

    Printf.printf "touistcode ==> ACA EXX after plan %i \n" !m;

    (* Change the flag in ./sdata/interfacefx.txt - Temporal 2020/06/08*)
    let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' %s" filesinput)   in
  
      let chan = open_in tmp_file in
              close_in chan
              in
              Printf.printf "touistcode ==> 001 \n";
      string_of_command4();  

    
      let string_of_command4 () =
        let tmp_file = filescore in
        let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' ../sdata/interface.txt")   in
    
        let chan = open_in tmp_file in
                close_in chan
                in
        string_of_command4();  
    (* Fin - Change the flag in ./sdata/interfacefx.txt - Temporal 2020/06/08*)        




    let string_of_command4 () =
      let tmp_file = filescore in
      (*let _ = Sys.command (Printf.sprintf "cat filescore brevdata/sinput.txt > brevsets/s_test.txt" )   in*)
      let _ = Sys.command (Printf.sprintf "cat '%s' '%s' > brevsets/s_test.txt" filescore filesinput2)   in
      let chan = open_in tmp_file in
      close_in chan
    in
    string_of_command4(); 


    let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/$/ and/' brevsets/s_test.txt" )   in
      let chan = open_in tmp_file in
      close_in chan
    in
    string_of_command4();


    let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i '$s/ and$//' brevsets/s_test.txt" )   in
      let chan = open_in tmp_file in
      close_in chan
    in
    string_of_command4();    


    let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i '1s/^/red (/' brevsets/s_test.txt" )   in
      let chan = open_in tmp_file in
      close_in chan
    in
    string_of_command4();      


    let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i '$s/$/)/' brevsets/s_test.txt")   in
      let chan = open_in tmp_file in
      close_in chan
    in
    string_of_command4();      



    let string_of_command4 () =
                          let tmp_file = filescore in
                          let _ = Sys.command (Printf.sprintf "sed -i 's/\&/and/g' brevsets/s_test.txt" )   in

                          let chan = open_in tmp_file in
                          close_in chan
                        in
                        string_of_command4(); 




    (*touistcode2 := (command (Printf.sprintf "./main.exe brevsets/s_test.txt > brevsets/out.emodel_01.txt"));*)
    touistcode2 := (command (Printf.sprintf "%s brevsets/s_test.txt > brevsets/out.emodel_01.txt" filetouist));

    if !touistcode2 = 0 then 
      begin
       (* Printf.printf "Sigma Input is NOT in contradiction with Sigma Core (SAT) touistcode ==> %i \n\n " !touistcode2;*)
       Printf.printf "##################### Trying with combinations of size ==> %i \n\n" !m;
       (* Aca generar el file con las combinaciones : brevsets/svc2.txt -  starting with size = m *)

        let reslst = flatten (extract !m (lines_from_files filesvol)) in
        (*let reslst = (lines_from_files filesvol) in*)

          (*List.iter(printf "VOL :: %s\n") reslst;*)

          let a = ref 1 in
              let ll = ref [] in
              ll := reslst;
              (* Generate the combinations of m elements from ZVol*)
              (*List.iter(printf "VOL-ll :: %s\n") !ll;*)

              while (!a <= List.length reslst ) do
                  a := !a + 1;
                    let string_of_command4 () =
                    let tmp_file = filescore in
                    let _ = Sys.command (Printf.sprintf "echo '%s' >> brevsets/sv_%i_x.txt" (List.hd !ll) !m)   in
                    let chan = open_in tmp_file in
                    close_in chan
                  in
                  string_of_command4();  
                  ll := List.tl !ll;
              done ;

      end  
    else
      begin
        Printf.printf "\nSigma Input is in contradiction with Sigma Core touistcode ==> %i (UNSAT)\n" !touistcode2; 
        (*
        Printf.printf "\nRev(Zbase, Zinput) : \n";  
        *)

        let tmp_file =  filescore in
        let l1 = ref [] in
              l1 := lines_from_files tmp_file; 

        let tmp_file =  filesvol in
        let l2 = ref [] in
              l2 := lines_from_files tmp_file; 

        Printf.printf "\n";    
        Printf.printf "+++++++++++++++++++++++++++++++";    
        Printf.printf "\n";    
        Printf.printf "Rev(Zbase(t), Zinput(t+1)) :\n";    
        List.iter(printf "%s\n") !l1;
        List.iter(printf "%s\n") !l2;
        (*Printf.printf "\n";*)

        Printf.printf "\n";    
        Printf.printf "+++++++++++++++++++++++++++++++";    
        Printf.printf "\nZcore (t+1) : \n";
        List.iter(printf "%s\n") !l1;

        Printf.printf "\nZvol (t+1) : \n";
        List.iter(printf "%s\n") !l2;








        (* Exit because Zinput in contradiction with Zcore*)
        exit 0;
      end;


let intersection l1 l2 = List.filter (fun x -> List.mem x l2) l1 in





let parse3ac() = 
    
    let lines = ref "" in
    let x = ref "" in
     
    let i = ref 1 in
    (* Here we pass the name of the file which contains the combinations dinamically*)
    let tmp_file = (Printf.sprintf "brevsets/sv_%i_x.txt" !m) in 
    let chan = open_in tmp_file in
    let chan2 = open_in tmp_file in


    let sc = open_in filescore in
    (*let si = open_in "brevdata/sinput.txt" in*)
    let si = open_in filesinput2 in

    

    let mcs = ref [] in
    let mcs2 = ref [] in
    let line = ref "" in

    let l1 = ref [] in
    let l2 = ref [] in






      let tmp_file =  filescore in
      let lx = ref [] in
           lx := lines_from_files tmp_file; 

      let rec difference l arg = match l with
      | [] -> []
      | x :: xs -> 
        if (x = arg) then difference xs arg
        else x :: difference xs arg in 

      let rec list_diff l1 l2 = match l2 with
      | [] -> l1
      | x :: xs -> list_diff (difference l1 x) xs in








    
    let j = ref 0 in
    let n = ref 0 in
    j := 0;
    (*Printf.printf ("Entro al : parse3ac() \n");*)
    try
      (* While there exist combinations, then evaluate if they are SAT*)
      while true do
        j := !j + 1;
        (*if (!lines != "") then lines := input_line chan ^" and "^ !lines;*)
        lines := input_line chan ^" and "^ !lines;
        line := input_line chan2;
        (*Printf.printf "LINEA ==>> %s \n" !line;*)

        let string_of_command4 () =
          let tmp_file = filescore in (*Este archivo se debe de generar mas arriba*)
          let _ = Sys.command (Printf.sprintf "echo '%s' >> brevsets/svxx_size_%i_seq_%i.txt" !line !m !i)   in
          let chan = open_in tmp_file in
          close_in chan
        in
        string_of_command4();  

        (*Printf.printf "Entro al : WHILE *** : %s \n" !lines;*)
        if !j = !m then  begin 


                        (* Is NOT necessary to merge all in one single file, because we can send a sequence of files to TouIST - But we are going to use for demostration - just to show the contain*)
                        let string_of_command5 () =
                                let tmp_file = filescore  in
                                (*let _ = Sys.command (Printf.sprintf "cat filescore brevsets/svxx_size_%i_seq_%i.txt brevdata/sinput.txt > brevsets/x_%i_%i.txt" !m !i !m !i)   in *)
                                let _ = Sys.command (Printf.sprintf "cat '%s' brevsets/svxx_size_%i_seq_%i.txt '%s' > brevsets/x_%i_%i.txt" filescore !m !i filesinput2 !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                              in
                              string_of_command5();
                          
                        Printf.printf "> Testing x_%i_%i.txt\n" !m !i;
                        (*touistcode2 := (command (Printf.sprintf "./main.exe brevsets/x_%i_%i.txt > brevsets/xs_%i_%i.txt" !m !i !m !i));*)
                        (*touistcode2 := (command (Printf.sprintf "(cat filescore; cat brevsets/svxx_size_%i_seq_%i.txt; cat brevdata/sinput.txt) | ./touist.exe --sat --solve - > brevsets/out.emodel_02.txt 2> brevsets/out.touisterr_02.txt" !m !i));*)



                        let string_of_command4 () =
                          let tmp_file = filescore in
                          (*let _ = Sys.command (Printf.sprintf "cat filescore brevsets/svxx_size_%i_seq_%i.txt brevdata/sinput.txt > brevsets/s_test2.txt" !m !i)   in*)
                          let _ = Sys.command (Printf.sprintf "cat '%s' brevsets/svxx_size_%i_seq_%i.txt '%s' > brevsets/s_test2.txt" filescore !m !i filesinput2)   in
                          let chan = open_in tmp_file in
                          close_in chan
                        in
                        string_of_command4(); 
                    
                    
                        let string_of_command4 () =
                          let tmp_file = filescore in
                          let _ = Sys.command (Printf.sprintf "sed -i 's/$/ and/' brevsets/s_test2.txt" )   in
                          let chan = open_in tmp_file in
                          close_in chan
                        in
                        string_of_command4();
                    
                    
                        let string_of_command4 () =
                          let tmp_file = filescore in
                          let _ = Sys.command (Printf.sprintf "sed -i '$s/) and/)/' brevsets/s_test2.txt" )   in

                          let chan = open_in tmp_file in
                          close_in chan
                        in
                        string_of_command4();    



                        let string_of_command4 () =
                          let tmp_file = filescore in
                          let _ = Sys.command (Printf.sprintf "sed -i 's/\&/and/g' brevsets/s_test2.txt" )   in

                          let chan = open_in tmp_file in
                          close_in chan
                        in
                        string_of_command4();    


                        let string_of_command4 () =
                          let tmp_file = filescore in
                          let _ = Sys.command (Printf.sprintf "sed -i '1s/^/red (/' brevsets/s_test2.txt" )   in
                          let chan = open_in tmp_file in
                          close_in chan
                        in
                        string_of_command4();      
                    
                    
                        let string_of_command4 () =
                          let tmp_file = filescore in
                          let _ = Sys.command (Printf.sprintf "sed -i '$s/$/)/' brevsets/s_test2.txt")   in
                          let chan = open_in tmp_file in
                          close_in chan
                        in
                        string_of_command4();     



                        
                        let string_of_command4 () =
                          let tmp_file = filescore in
                          let _ = Sys.command (Printf.sprintf "sed -i '$s/ and)/)/' brevsets/s_test2.txt")   in
                          let chan = open_in tmp_file in
                          close_in chan
                        in
                        string_of_command4();                             




                        (*touistcode2 := (command (Printf.sprintf "(cat filescore; cat brevsets/svxx_size_%i_seq_%i.txt; cat brevdata/sinput.txt) | ./main.exe > brevsets/out.emodel_02.txt" !m !i));*)
                        (*touistcode2 := (command (Printf.sprintf "./main.exe brevsets/s_test2.txt > brevsets/out.emodel_02.txt"));*)
                        touistcode2 := (command (Printf.sprintf "%s brevsets/s_test2.txt > brevsets/out.emodel_02.txt" filetouist));

                        if !touistcode2 = 0 then 
                          begin
                            n := !n + 1;
                            Printf.printf "touistcode :  %i ==> saving x_%i_%i.txt in MCS[] \n\n" !touistcode2 !m !i;
                            mcs := !mcs @ ["brevsets/x_"^string_of_int !m^"_"^string_of_int !i^".txt"];
                            mcs2 := !mcs2 @ ["brevsets/svxx_size_"^string_of_int !m^"_seq_"^string_of_int !i^".txt"];

                            (*touistcode2 := (command (Printf.sprintf "cat brevsets/x_%i_%i.txt > brevsets/xss_%i.txt" !m !i !n));*)
                            (*exit 0;*)
                          end  
                          else
                               Printf.printf "touistcode :  %i \n\n" !touistcode2;                         
                            
                          i := 1 + !i;
                          j := 0;
                          lines := ""

                        end

      done;
    with End_of_file -> close_in chan; (* End of Try - Aca se terminan de enviar al Touist las Combinaciones *)


    (* @@@ Aca crear el resulta final cuando mcs = 0 quiere decir que Zinput is in contradiction with Zvol pero como solo hay un item en Zvol => *)                        
    (* se debe de retirar este item y reemplazar por el Zinput y rearmar los final files _base_*.txt *)                        

    if List.length !mcs > 0 then 
    begin

      if List.length !mcs = 1 then
      begin 
        (*List.iter(printf " ACA ES MCS-MCS-MCS  ::::::::::: %s \n") !mcs;*)
        (*List.iter(printf " MCS : %s \n") !mcs;*)
        List.iteri(printf "MCS[%i] : %s \n") !mcs;
        Printf.printf "\n";    

        let tmp_file = List.hd !mcs in

        (*let l1 = ref [] in*)
              l1 := lines_from_files tmp_file; 
(*
        Printf.printf "\nRev(Zbase, Zinput) : \n";    
        List.iter(printf "%s\n") !l1;
        Printf.printf "\n";
*)        
        (*exit 0;*)
      end;

      if List.length !mcs > 1 then
      (* Extract from MCS[] the firts 1 element, then compare it with the rest elements of the list MCS[] until no elements in MCS[]*)
      begin
        (*List.iteri(printf "MCSx %i : %s \n") !mcs;*)
        List.iteri(printf "MCS[%i] : %s \n") !mcs;
        j := List.length !mcs;
        i := 1;

        let lines1 = ref "" in 
        let lines2 = ref "" in 
        let tmp_file =  List.hd !mcs in
        (*let l1 = ref [] in*)
              l1 := lines_from_files tmp_file; 

        (*x1 := flatten (lines_from_files tmp_file); *)
        let tmp_fileb =  List.hd !mcs2 in
        let chan =  open_in tmp_fileb in    
        let x1 = ref "" in
              try
              while true do              
                lines1 := input_line chan ^" "^ !lines1;
              done;
              with End_of_file -> close_in chan;              

        while  !i < !j do
              (*let mcsr = (List.tl !mcs) in      *)
              let tmp_file2 =  List.hd (List.tl !mcs) in
              (*let l2 = ref [] in*)
                  l2 := lines_from_files tmp_file2;

              (*x1 := flatten (lines_from_files tmp_file); *)
              let tmp_fileb =  List.hd (List.tl !mcs2) in
              let chan =  open_in tmp_fileb in    
              let x2 = ref "" in
                    try
                    while true do              
                      lines2 := input_line chan ^" "^ !lines2;
                    done;
                    with End_of_file -> close_in chan;      

              l1 := intersection !l1 !l2;

              i := 1 + !i;
        done;
(*
        Printf.printf "\nRev(Zbase(t), Zinput(t+1)) : \n";    
        List.iter(printf "%s\n") !l1;
        Printf.printf "\n";
*)        
      end;



      


      Printf.printf "+++++++++++++++++++++++++++++++";    
      Printf.printf "\n";    
      Printf.printf "Rev(Zbase(t), Zinput(t+1)) : \n";    
      List.iter(printf "%s\n") !l1;
      Printf.printf "\n";

      (*let oc = open_out "planerdata/01_model.txt" in    (* create or truncate file, return channel *)*)
      let oc = open_out "../sdata/01_model.txt" in
      List.iter(fprintf oc "%s\n") !l1;
      close_out oc; 


                        let string_of_command4 () =
                          let tmp_file = filescore in
                          (*let _ = Sys.command (Printf.sprintf "sed -i 's/$/ and/' planerdata/01_model.txt" )   in*)
                          let _ = Sys.command (Printf.sprintf "sed -i 's/$/ and/' ../sdata/01_model.txt" )   in
                          let chan = open_in tmp_file in
                          close_in chan
                        in
                        string_of_command4();
                    
                    
                        let string_of_command4 () =
                          let tmp_file = filescore in
                          (*let _ = Sys.command (Printf.sprintf "sed -i '$s/ and//' planerdata/01_model.txt" )   in*)
                          let _ = Sys.command (Printf.sprintf "sed -i '$s/ and//' ../sdata/01_model.txt" )   in
                          let chan = open_in tmp_file in
                          close_in chan
                        in
                        string_of_command4();  



      Printf.printf "+++++++++++++++++++++++++++++++";    
      Printf.printf "\n";    
      Printf.printf "Zcore (t+1) : \n";
      List.iter(printf "%s\n") !lx;

      Printf.printf "\nZvol (t+1) : \n";
      List.iter(printf "%s\n") (list_diff !l1 !lx);

      let oc = open_out filesvol in    (* create or truncate file, return channel *)
      List.iter(fprintf oc "%s\n") (list_diff !l1 !lx);
      close_out oc; 


      let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/\&/and/g' %s" filesvol)   in

      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();    


(*********@@@ ****)

let string_of_command4 () =
  let tmp_file = filescore in
  
  let _ = Sys.command (Printf.sprintf "cat '%s' > '%s'" filesvol filesvol_final)   in
  let chan = open_in tmp_file in
          close_in chan
          in
  string_of_command4(); 


  let string_of_command4 () =
    let tmp_file = filescore in
    let _ = Sys.command (Printf.sprintf "sed -i 's/x_/ass(/g' %s" filesvol_final)   in

    let chan = open_in tmp_file in
            close_in chan
            in
    string_of_command4();    

  let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/_x/)/g' %s" filesvol_final)   in
  
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();    

  let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/_/,/g' %s" filesvol_final)   in
  
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();    

     (* sed -i '1s/^/<added text> /' file *)

  let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/^/\"/' %s" filesvol_final)   in
    
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4(); 
      
  let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/$/\"/' %s" filesvol_final)   in
      
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();       


(*************)







      let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/\&/and/g' ../sdata/01_model.txt" )   in

      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();   





(*      
let reslst = flatten (extract !m (lines_from_files filesvol)) in
*)



Printf.printf "New Clock = %i  \n" !clock2;
let string_of_command4b() =
  let tmp_file = "planerdata/01_model.txt" in
  let _ = Sys.command (Printf.sprintf "echo '"^string_of_int (!clock2)^"' > ../sdata/99_clock.txt")   in
  let chan = open_in tmp_file in
  close_in chan
in
string_of_command4b();  



let string_of_command4 () =
  let tmp_file = filescore in
  let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in
  let chan = open_in tmp_file in
            close_in chan
        in
        string_of_command4(); 


let string_of_command4 () =
  let tmp_file = filescore in
  (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
  let _ = Sys.command (Printf.sprintf "sed -i 's/$/ and/' ../sdata/00_delta0_base_and.txt") in
  let chan = open_in tmp_file in
             close_in chan
        in
        string_of_command4();       






      Printf.printf "exit 0- line 761 ... \n";  
      exit 0;    
    end;
    in
    parse3ac();

in

























let string_of_command () =
  let tmp_file = "../sdata/00_tempo.txt" in
  (* Aca filtra solo el que tiene flag :1 del archivo filesinput = interfacefx.txt y lo graba en filesinput2 = "../sdata/04_input.txt" - 28/07/2021 *)
  let _ = Sys.command @@ "grep -F ':1' "^filesinput^" > "^filesinput2 in
  let chan = open_in tmp_file in
  close_in chan
  in
  Printf.printf " despues del grep ====================> [%s] \n" filesinput;
  string_of_command() ;
  

  let string_of_command4 () =
    let tmp_file = filescore in
    let _ = Sys.command (Printf.sprintf "sed -i -e 's/h://g' -e 's/m://g' -e 's/:1//g' %s" filesinput2)   in
    let chan = open_in tmp_file in
            close_in chan
            in

            (* @@@ Aca generar los filter *)
            (* @@@ Aca generar los filter *)
            (* @@@ Aca generar los filter *)
            Printf.printf " lines_from_files filesinput2 : %s \n" filesinput2;
            string_of_command4(); 


 
            let actionsset = List.nth (lines_from_files filesinput2) 0 in
            Printf.printf " lines_from_files ====================> [%s] \n" actionsset;

            let actionfx = String.split_on_char ' ' actionsset in
            (*let size = String.length(List.nth words 0) in*)
            let action_single =   (List.nth actionfx 0) in
            Printf.printf " ACTION SINGLE ====================> [%s] \n" action_single;
         
            let action_single_new = (replace2  "(" "" action_single) in
          
            Printf.printf " ACTION SINGLE NEW ====================> [%s] \n" action_single;
 









  


  let get_action_obs() =   

    let strip str = 
      let str = Str.replace_first (Str.regexp "^ +") "" str in
      Str.replace_first (Str.regexp " +$") "" str in                             

    let action = List.nth (lines_from_files filesinput2) 0 in
                                      Printf.printf "Contenido de  plan_final_show Brev = %s  \n" action;
                                let words = String.split_on_char '_' action in
                                (*let size = String.length(List.nth words 0) in*)
                                let action_single =   (List.nth words 0) in
                                	   if (action_single = "col") then 
                                      begin
                                        Printf.printf "Single Action = *%s* + %s + %s \n" action_single (List.nth words 1) (List.nth words 2);
                                        let string_of_command () =

                                          let tmp_file = "../sdata/00_tempo.txt" in
                                          (* Aca filtra solo el que tiene flag :1 del archivo filesinput = interfacefx.txt y lo graba en filesinput2 = "../sdata/04_input.txt" - 28/07/2021 *)
                                          Printf.printf "...................................... ENTRO AL GREP = %s  \n" action_single_new;
                                          let _ = Sys.command @@ "grep tm_"^action_single_new^" "^filesvol^" > "^filesvolfilter in
                                          Printf.printf "...................................... SALIO DEL GREP = %s  \n" action_single_new;
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command() ;
                                        
                                        let string_of_command () =
                                          let tmp_file = "../sdata/00_tempo.txt" in
                                          (* Aca filtra solo el que tiene flag :1 del archivo filesinput = interfacefx.txt y lo graba en filesinput2 = "../sdata/04_input.txt" - 28/07/2021 *)
                                          let _ = Sys.command @@ "grep -v tm_"^action_single_new^" "^filesvol^" > "^filesvolnofilter in
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command() ;  

                                        (* Generate Sets same color from Observation *)  
                                        let string_of_command () =
                                        let tmp_file = filescore in
                                        (*let _ = Sys.command (Printf.sprintf "sed -i -e '/%s/s/$/%s|/' %s" (List.nth words 2) (List.nth words 1) filesetssamecolor)   in*)
                                          let _ = Sys.command (Printf.sprintf "sed -i -e '/%s/s/$/%s;/' %s" (List.nth words 2) (List.nth words 1) filesetssamecolor)   in
                                          let chan = open_in tmp_file in
                                                  close_in chan
                                          in
                                          string_of_command() ;  
                                                  
                                        (* JFD : 31/03/2022 - Aca ahora leer el file anterior, si hay 4 cards del mismo color entonces iniciar el proceso para eliminar las deducciones incorrectas *)            
                                        (* 1 :  Filtrar las acciones col_ y mark_ del file 00_delta_*)  
                                        (* 2 :  Filtrar las acciones (mark_ del file 00_delta_ por cada mark_ del filter anterior *)  
                                        (* Creo que todo lo anterior se debe de hacer en la seccion : filterprocess() *)

                                        let string_of_command () =
                                          let tmp_file = filescore in
                                          (* Aca filtra solo el que tiene flag :1 del archivo filesinput = interfacefx.txt y lo graba en filesinput2 = "../sdata/04_input.txt" - 28/07/2021 *)
                                          (*let _ = Sys.command @@ "grep "^(List.nth words 2)^"|"^" "^filesvolnofilter^" > "^filesvolnofilter^"."^(List.nth words 2) in*)
                                          let _ = Sys.command @@ "grep "^(List.nth words 2)^" "^filesetssamecolor^" > ../sdata/test_01.tmp" in
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command() ;  

                                        (* let cardsSameColor = String.sub (List.nth (lines_from_files "../sdata/test_01.tmp") 0) 2 ((String.length (List.nth (lines_from_files "../sdata/test_01.tmp") 0)) - 1) in *)    
                                        let cardsSameColor = List.nth (lines_from_files "../sdata/test_01.tmp") 0 in

                                        Printf.printf "############# ANTES DEL IF-cardsSameColor = %s  \n" cardsSameColor;
                                        let cardsSameColorSub = String.sub cardsSameColor 1 (String.length cardsSameColor - 1)  in



                                        Printf.printf "############# ANTES DEL IF-cardsSameColorSub = %s  \n" cardsSameColorSub;
                                        Printf.printf "############# ANTES DEL IF-cardsSameColor = %s  \n" cardsSameColor;

                                        let numCardsSameColor = String.split_on_char ';' cardsSameColorSub in  
                                        let numCardsSameColorSize = List.length numCardsSameColor in  
                                        Printf.printf "############# ANTES DEL IF = %i  \n" numCardsSameColorSize;
                                        List.iter(printf "Elements of numCardsSameColor :::::::: %s\n") numCardsSameColor;
                                        
                                        
                                        if ((List.length numCardsSameColor -1) == 4) then
                                          begin
                                            numCardsGrouped := 4;
                                            
                                            (*
                                            Printf.printf "Dentro de : if (List.length numCardsSameColor == ) %i \n" numCardsSameColorSize;
                                            
                                            let string_of_command () =
                                              let tmp_file = filescore in
                                              let _ = Sys.command (Printf.sprintf "sed -i '/=> col.*"^(List.nth words 2)^"/d' ../sdata/00_delta0_base.txt") in
                                              let chan = open_in tmp_file in
                                              close_in chan
                                              in
                                              string_of_command();                                             

                                            
                                            Printf.printf "END - %s \n" (List.nth words 2);
                                          *)

                                          end;
                                        
                                          (* let _ = Sys.command (Printf.sprintf "sed -i '/=> col.*"^(List.nth words 2)^"/d' ../sdata/00_delta0_base_and.txt") in *)




(* @@@+++ *)






                                        (*List.iter(printf "VOL :: %s\n") reslst;*)

                                      (*  
                                      let a = ref 1 in
                                      let ll = ref [] in
                                            ll := reslst;

                                      while (!a <= List.length reslst ) do
                                        a := !a + 1;
                                          let string_of_command4 () =
                                          let tmp_file = filescore in
                                          let _ = Sys.command (Printf.sprintf "echo '%s' >> brevsets/sv_%i_x.txt" (List.hd !ll) !m)   in
                                          let chan = open_in tmp_file in
                                          close_in chan
                                        in
                                        string_of_command4();  
                                        ll := List.tl !ll;
                                      done ;
                                      *)







                                      end
                                    else 
                                      begin
                                        let string_of_command () =

                                          let tmp_file = "../sdata/00_tempo.txt" in
                                          (* Aca filtra solo el que tiene flag :1 del archivo filesinput = interfacefx.txt y lo graba en filesinput2 = "../sdata/04_input.txt" - 28/07/2021 *)
                                          Printf.printf "...................................... ENTRO AL GREP = %s  \n" action_single_new;
                                          let _ = Sys.command @@ "grep "^action_single_new^" "^filesvol^" > "^filesvolfilter in
                                          Printf.printf "...................................... SALIO DEL GREP = %s  \n" action_single_new;
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command() ;
                                        
                                        let string_of_command () =
                                          let tmp_file = "../sdata/00_tempo.txt" in
                                          (* Aca filtra solo el que tiene flag :1 del archivo filesinput = interfacefx.txt y lo graba en filesinput2 = "../sdata/04_input.txt" - 28/07/2021 *)
                                          let _ = Sys.command @@ "grep -v "^action_single_new^" "^filesvol^" > "^filesvolnofilter in
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command() ; 

                                          (* @@@+ - JFD: 2022/03/26 *)
                                          
                                          
                                          if (action_single = "mark") then     
                                          begin
                                            let string_of_command () =
                                            let tmp_file = filescore in  
                                            Printf.printf "Entro al MARK MARK MARK MARK MARK MARK ++++++ ";
                                                     (* command (Printf.sprintf "../inference/inference 01_ini_state.txt %s" action_single_new) in *)
                                                     (* let _ = Sys.command (Printf.sprintf "echo '%s;' >> %s" (List.nth words 1) filemarkcards)   in *)
                                                     let _ = Sys.command (Printf.sprintf "sed -i -e 's/$/%s,/' %s" (List.nth words 1) filemarkcards)   in
                                                     let chan = open_in tmp_file in
                                                     close_in chan 
                                                     in
                                                     string_of_command(); 

                                          end;
                                              
                                          (* *)


                                      end;

                                                                        
                                     in

                                   get_action_obs();
                                   
                                   



(* @@@ - Aca es lo ultimo !!! *)


let filterprocess() =
let linesvolfilter = List.length (lines_from_files (Printf.sprintf "%s" filesvolfilter)) in
  Printf.printf "linesvolfilter linesvolfilter linesvolfilter ::::::::::::: %i  \n" linesvolfilter;
  let action = List.nth (lines_from_files filesinput2) 0 in
  let words = String.split_on_char '_' action in
  (*let size = String.length(List.nth words 0) in*)
  let action_single =   (List.nth words 0) in
  let action_single_card =   (List.nth words 1) in
  let action_single_card_color =   (List.nth words 2) in
  
  (* Add the OBSERVED card into $MK or $HK sets @@@@ *) 

  if (action_single = "col") then
    begin
        let string_of_command4 () =
        let tmp_file = filescore in
        Printf.printf "+++++++++++ ADDING ACTION SINGLE :: %s  in file : %s \n" action_single_card mk_cards;
        let _ = Sys.command (Printf.sprintf "sed -i -e 's/]//g' -e '1s/$/, %s/' %s" action_single_card mk_cards)   in
        let chan = open_in tmp_file in
                close_in chan;
                in
                string_of_command4();                 


        let string_of_command4 () =
          let tmp_file = filescore in
          Printf.printf "+++++++++++ ADDING ACTION SINGLE :: %s  in file : %s \n" action_single_card mk_cards_colors;
          let _ = Sys.command (Printf.sprintf "echo '$MK_COLOR('%s') = ['%s']' | tee -a %s" action_single_card action_single_card_color mk_cards_colors)   in
          let chan = open_in tmp_file in
                  close_in chan;
                  in
                  string_of_command4();  


        let string_of_command4 () =
          let tmp_file = filescore in
          Printf.printf "+++++++++++ generating the set $MK :: %s  in file : %s \n" action_single_card mk_cards_colors;
          let _ = Sys.command (Printf.sprintf "sed -i -e 's/$/]/' %s" mk_cards)   in
          let chan = open_in tmp_file in
                  close_in chan;
                  in
                  string_of_command4();  


        let string_of_command4 () =
          let tmp_file = filescore in
          Printf.printf "+++++++++++ generating the set $MK :: %s  in file : %s \n" action_single_card mk_cards_colors;
          let _ = Sys.command (Printf.sprintf "sed -i -e 's/\[0, /\[/g' %s" mk_cards)   in
          let chan = open_in tmp_file in
                  close_in chan;
                  in
                  string_of_command4();                    


        (*  
-e 's/[, /[/g' 

        let string_of_command4 () =
          let tmp_file = filescore in
          (* Agregar el set $ILEGALMOV en ../sdata/01_ini_set.txt *)
          let _ = Sys.command (Printf.sprintf "cat %s >> ../sdata/01_ini_set.txt"  mk_cards) in
          let chan = open_in tmp_file in
                      close_in chan
                in
                string_of_command4();   
                  

        let string_of_command4 () =
          let tmp_file = filescore in
          (* Agregar el set $ILEGALMOV en ../sdata/01_ini_set.txt *)
          let _ = Sys.command (Printf.sprintf "cat %s >> ../sdata/01_ini_set.txt"  mk_cards_colors) in
          let _ = Sys.command (Printf.sprintf "cat %s >> ../sdata/01_ini_set.txt"  hk_cards) in
          let chan = open_in tmp_file in
                      close_in chan
                in
                string_of_command4();   
          *)                
        



    end;

  if (action_single = "(th") then          
    begin
    let string_of_command4 () =
      let tmp_file = filescore in
      Printf.printf "+++++++++++ ADDING ACTION SINGLE :: %s  in file : %s \n" (List.nth words 2) hk_cards;
      let _ = Sys.command (Printf.sprintf "sed -i -e 's/]//g' -e '1s/$/, %s/' %s" (List.nth words 2) hk_cards)   in
      let chan = open_in tmp_file in
              close_in chan;
              in
              string_of_command4();  
              
    let string_of_command4 () =
      let tmp_file = filescore in
      Printf.printf "+++++++++++ generating the set $HK :: %s  in file : %s \n" action_single_card hk_cards;
      let _ = Sys.command (Printf.sprintf "sed -i -e 's/$/]/' -e 's/\[, /\[/g' %s" hk_cards)   in
      let chan = open_in tmp_file in
              close_in chan;
              in
              string_of_command4();

    (*          
    let string_of_command4 () =
      let tmp_file = filescore in
      (* Agregar el set $ILEGALMOV en ../sdata/01_ini_set.txt *)
      let _ = Sys.command (Printf.sprintf "cat %s >> ../sdata/01_ini_set.txt"  hk_cards) in
      let chan = open_in tmp_file in
                  close_in chan
            in
            string_of_command4();                 
    *)            
              
              
    end;

  

(*Adding the set for calculate the goal for ACTIVE hints for the machine *)

let string_of_command4 () =
  let tmp_file = filescore in
  (* Agregar el set $ILEGALMOV en ../sdata/01_ini_set.txt *)
  let _ = Sys.command (Printf.sprintf "cat %s >> ../sdata/01_ini_set.txt"  mk_cards) in
  let chan = open_in tmp_file in
              close_in chan
        in
        string_of_command4();   
          

let string_of_command4 () =
  let tmp_file = filescore in
  (* Agregar el set $ILEGALMOV en ../sdata/01_ini_set.txt *)
  let _ = Sys.command (Printf.sprintf "cat %s >> ../sdata/01_ini_set.txt"  mk_cards_colors) in
  let _ = Sys.command (Printf.sprintf "cat %s >> ../sdata/01_ini_set.txt"  hk_cards) in
  let chan = open_in tmp_file in
              close_in chan
        in
        string_of_command4();   








  if (linesvolfilter = 1) then
      (* if (action_single = "col" || action_single = "act" || action_single = "mark") then  *)
      if (action_single != "pos") then
        begin

          Printf.printf "Entro al BREV express 222 -11111111111111 = %s  \n" action_single;
          
          let string_of_command4 () =
            let tmp_file = filescore in
            let _ = Sys.command (Printf.sprintf "cat %s %s > ../sdata/00_delta0_base.txt" filesvolnofilter filesinput2) in
            let chan = open_in tmp_file in
                      close_in chan
                  in
                  string_of_command4();  
  

          let string_of_command4 () =
            let tmp_file = filescore in
            let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in
            let chan = open_in tmp_file in
                      close_in chan
                  in
                  string_of_command4();      

                  
          let string_of_command4 () =
            let tmp_file = filescore in
            (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
            let _ = Sys.command (Printf.sprintf "sed -i 's/$/ and/' ../sdata/00_delta0_base_and.txt") in
            let chan = open_in tmp_file in
                        close_in chan
                  in
                  string_of_command4();                      
                  

          (* Change the flag in ./sdata/interfacefx.txt - Temporal 2020/06/08*)
          let string_of_command4 () =
            let tmp_file = filescore in
            let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' %s" filesinput)   in
        
            let chan = open_in tmp_file in
                    close_in chan
                    in
                    Printf.printf "touistcode ==> 002 \n";
            string_of_command4();  
          (* Fin - Change the flag in ./sdata/interfacefx.txt - Temporal 2020/06/08*)        
          
            let string_of_command4 () =
              let tmp_file = filescore in
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' ../sdata/interface.txt")   in
          
              let chan = open_in tmp_file in
                      close_in chan
                      in
              string_of_command4();  

              Printf.printf "Fuera de : if (List.length numCardsSameColor == ) %i \n" !numCardsGrouped;
              
              if (!numCardsGrouped == 4) then

                begin
                Printf.printf "Dentro de : if (List.length numCardsSameColor == ) %i \n" !numCardsGrouped;

                let string_of_command () =
                  let tmp_file = filescore in
                  let _ = Sys.command (Printf.sprintf "sed -i '/=> col.*"^(List.nth words 2)^"/d' ../sdata/00_delta0_base.txt") in
                  let _ = Sys.command (Printf.sprintf "sed -i '/=> col.*"^(List.nth words 2)^"/d' ../sdata/00_delta0_base_and.txt") in
                  let chan = open_in tmp_file in
                  close_in chan
                  in
                  string_of_command();                                             

                Printf.printf "END - %s \n" (List.nth words 2);
                end;



              Printf.printf "New Clock = %i  \n" !clock2;
              let string_of_command4b() =
                let tmp_file = "planerdata/01_model.txt" in
                let _ = Sys.command (Printf.sprintf "echo '"^string_of_int (!clock2)^"' > ../sdata/99_clock.txt")   in
                let chan = open_in tmp_file in
                close_in chan
              in
              string_of_command4b();  

          exit(0);
        end;


if (linesvolfilter >= 1) then
        (* if (action_single = "col" || action_single = "act" || action_single = "mark") then  *)
        if (action_single != "pos") then
          begin
  
            Printf.printf "Entro al BREV express 333 -11111111111111 = %s  \n" action_single;

            let string_of_command4 () =
              let tmp_file = filescore in
              let _ = Sys.command (Printf.sprintf "sed -i -e '1d' %s" filesvolfilter) in
              let chan = open_in tmp_file in
                        close_in chan
                    in
                    string_of_command4();




            
            let string_of_command4 () =
              let tmp_file = filescore in
              let _ = Sys.command (Printf.sprintf "cat %s %s %s > ../sdata/00_delta0_base.txt" filesvolnofilter filesvolfilter filesinput2) in
              let chan = open_in tmp_file in
                        close_in chan
                    in
                    string_of_command4();  
    
  
            let string_of_command4 () =
              let tmp_file = filescore in
              let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in
              let chan = open_in tmp_file in
                        close_in chan
                    in
                    string_of_command4();      
  
                    
            let string_of_command4 () =
              let tmp_file = filescore in
              (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
              let _ = Sys.command (Printf.sprintf "sed -i 's/$/ and/' ../sdata/00_delta0_base_and.txt") in
              let chan = open_in tmp_file in
                          close_in chan
                    in
                    string_of_command4();                      
                    
  
            (* Change the flag in ./sdata/interfacefx.txt - Temporal 2020/06/08*)
            let string_of_command4 () =
              let tmp_file = filescore in
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' %s" filesinput)   in
          
              let chan = open_in tmp_file in
                      close_in chan
                      in
                      Printf.printf "touistcode ==> 002 \n";
              string_of_command4();  
            (* Fin - Change the flag in ./sdata/interfacefx.txt - Temporal 2020/06/08*)        
            
              let string_of_command4 () =
                let tmp_file = filescore in
                let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' ../sdata/interface.txt")   in
            
                let chan = open_in tmp_file in
                        close_in chan
                        in
                string_of_command4();  
  
                Printf.printf "New Clock = %i  \n" !clock2;
                let string_of_command4b() =
                  let tmp_file = "planerdata/01_model.txt" in
                  let _ = Sys.command (Printf.sprintf "echo '"^string_of_int (!clock2)^"' > ../sdata/99_clock.txt")   in
                  let chan = open_in tmp_file in
                  close_in chan
                in
                string_of_command4b();  
  
            exit(0);
          end;

        


        
    if (linesvolfilter = 0) then 
        (*if (action_single = "col" || action_single = "act") then *)
          begin
  
            Printf.printf "Entro al BREV express 222-00000000000 = %s  \n" action_single;
            
            let string_of_command4 () =
              let tmp_file = filescore in
              let _ = Sys.command (Printf.sprintf "cat %s >> ../sdata/00_delta0_base.txt" filesinput2) in
              let chan = open_in tmp_file in
                        close_in chan
                    in
                    string_of_command4();  
    
  
            let string_of_command4 () =
              let tmp_file = filescore in
              let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in
              let chan = open_in tmp_file in
                        close_in chan
                    in
                    string_of_command4();      
  
                    
            let string_of_command4 () =
              let tmp_file = filescore in
              (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
              let _ = Sys.command (Printf.sprintf "sed -i 's/$/ and/' ../sdata/00_delta0_base_and.txt") in
              let chan = open_in tmp_file in
                          close_in chan
                    in
                    string_of_command4();                      
                    
  
            (* Change the flag in ./sdata/interfacefx.txt - Temporal 2020/06/08*)
            let string_of_command4 () =
              let tmp_file = filescore in
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' %s" filesinput)   in
          
              let chan = open_in tmp_file in
                      close_in chan
                      in
                      Printf.printf "touistcode ==> 003 \n";
              string_of_command4();  
            (* Fin - Change the flag in ./sdata/interfacefx.txt - Temporal 2020/06/08*)        
            
              let string_of_command4 () =
                let tmp_file = filescore in
                let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' ../sdata/interface.txt")   in
            
                let chan = open_in tmp_file in
                        close_in chan
                        in
                string_of_command4();  
  
                Printf.printf "New Clock = %i  \n" !clock2;
                let string_of_command4b() =
                  let tmp_file = "planerdata/01_model.txt" in
                  let _ = Sys.command (Printf.sprintf "echo '"^string_of_int (!clock2)^"' > ../sdata/99_clock.txt")   in
                  let chan = open_in tmp_file in
                  close_in chan
                in
                string_of_command4b();  
  
            exit(0);
          end;
        

        






        
        
        in 
    
    filterprocess();        





let pm = ref 0 in
pm := List.length (lines_from_files (Printf.sprintf "%s" filesvol));
let px = ref 0 in








(* Aca si 04_input.txt comienza con m:col_ entonces insertar la entrada en 00_sets_same_color, con el formato : X - 28/07/2021 
Lo mas SOUND es agarrar el string y hace un split por el caracter "_", para luego consultar si el primer valor es igual a m:col *)

(*
let read_line i = try Some (input_line i) with End_of_file -> None in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in
*)  



                                   (*let filesetssamecolor = "../sdata/00_sets_same_color.txt" in*)
                                   (*sed '/192.168.1.2/s/$/ myalias/' file                                   
                                   sed -i -e '/G:/s/$/2|/' ../sdata/00_sets_same_color.txt*)

                                   


  let string_of_command4 () =
    let tmp_file = filescore in
    let _ = Sys.command (Printf.sprintf "sed -i -e 's/h://g' -e 's/m://g' -e 's/:1//g' %s" filesinput2)   in
    let chan = open_in tmp_file in
            close_in chan
            in
            Printf.printf "string_of_command4 - filesinput2 !!!!!!!!!!! ::: \n\n";
    string_of_command4();  


if !pm = 0 then
(* When there is NO data in the Vol_Base file ==> Expansion of the Vol_Base *)
  begin
    Printf.printf "Sigma Vol ==> VACIO SIZE ::: \n\n";

    let string_of_command4 () =
    let tmp_file = filescore in
    
    let _ = Sys.command (Printf.sprintf "cat '%s' > '%s'" filesinput2  filesvol)   in
    let chan = open_in tmp_file in
            close_in chan
            in
    string_of_command4(); 



    let string_of_command4 () =
      let tmp_file = filescore in
      
      let _ = Sys.command (Printf.sprintf "cat '%s' > '%s'" filesinput2  filesvol_final)   in
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4(); 



(*********@@@ ****)

let string_of_command4 () =
  let tmp_file = filescore in
  
  let _ = Sys.command (Printf.sprintf "cat '%s' > '%s'" filesvol filesvol_final)   in
  let chan = open_in tmp_file in
          close_in chan
          in
  string_of_command4(); 


  let string_of_command4 () =
    let tmp_file = filescore in
    let _ = Sys.command (Printf.sprintf "sed -i 's/x_/ass(/g' %s" filesvol_final)   in

    let chan = open_in tmp_file in
            close_in chan
            in
    string_of_command4();    

  let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/_x/)/g' %s" filesvol_final)   in
  
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();    

  let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/_/,/g' %s" filesvol_final)   in
  
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();    

     (* sed -i '1s/^/<added text> /' file *)

  let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/^/\"/' %s" filesvol_final)   in
    
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4(); 
      
  let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i 's/$/\"/' %s" filesvol_final)   in
      
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();       


(*************)

    let string_of_command4 () =
    let tmp_file = filescore in
    let _ = Sys.command (Printf.sprintf "sed -i 's/\&/and/g' %s" filesvol)   in

    let chan = open_in tmp_file in
            close_in chan
             in
    string_of_command4();    



    let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' %s" filesinput)   in
  
      let chan = open_in tmp_file in
              close_in chan
              in
              Printf.printf "touistcode ==> 004 \n";
      string_of_command4();  


    (* Change the flag in ./sdata/interfacefx.txt - Temporal 2020/06/08*)
    let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' ../sdata/interface.txt")   in
  
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();  
  (* Fin - Change the flag in ./sdata/interfacefx.txt - Temporal 2020/06/08*)  





    clock2 := (int_of_string clock) + 1;
      Printf.printf "New Clock = %i  \n" !clock2;
      let string_of_command4b() =
        let tmp_file = "planerdata/01_model.txt" in
        let _ = Sys.command (Printf.sprintf "echo '"^string_of_int (!clock2)^"' > ../sdata/99_clock.txt")   in
        let chan = open_in tmp_file in
        close_in chan
      in
      string_of_command4b();  



      let string_of_command4 () =
        let tmp_file = filescore in
        let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in
        let chan = open_in tmp_file in
                  close_in chan
              in
              string_of_command4(); 
      
      
      let string_of_command4 () =
        let tmp_file = filescore in
        (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
        let _ = Sys.command (Printf.sprintf "sed -i 's/$/ and/' ../sdata/00_delta0_base_and.txt") in
        let chan = open_in tmp_file in
                   close_in chan
              in
              string_of_command4();     




(*               
      let ilegalmovsline = List.nth (lines_from_files ilegalpositions) 0 in        

      (* Add the line $BORDERCARDS = in 00_ini_set.txt with the content in bordercards file*)  
      let string_of_command4 () =
        let tmp_file = filescore in
        (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
        (* Printf.printf "+++++++++++ ADDING CARD :: %s  \n" bordercardsline;  *)
        let _ = Sys.command (Printf.sprintf "sed -i '/$BORDERCARDS/a $ILEGALMOV = [%s]' ../sdata/01_ini_set.txt" ilegalmovsline) in
        let chan = open_in tmp_file in
                    close_in chan
              in
              string_of_command4();
*)









 end

else
(* There is Data in the Vol Base => Generate Max Consistant sub-sets*)  
  begin
    Printf.printf "********************************* Antes del FOR... \n";
    for p = 0 to (!pm - 1) do
      px := (!pm - p);
      plan px;
    done;
  end;



Printf.printf "Process completed ... \n";
exit 0;






end;
(* Cierre del 
if (encoding == 100) then
*)





















































(* Opcion de llamada: -m *)
(* Usado para hacer Rollback de la ultima linea *)
(* Retira la ultima linea de los files: interface.txt and interfacefx.txt y reemplaza el set $BORDERCARDS en: ../sdata/01_ini_set.txt *)
if (encoding == 200) then
  begin
    Printf.printf "Process 200 completed ... \n";

    let clock = List.nth (lines_from_files "../sdata/99_clock.txt") 0 in
    let clock2 = ref 0 in
    clock2 := (int_of_string clock) + 1;


    (* get the file total lines : *)
    let filesinput2 = "../sdata/interface.txt" in
    let nrolinesinfile = List.length (lines_from_files filesinput2) in
    let actionsset = List.nth (lines_from_files filesinput2) (nrolinesinfile - 1) in
    Printf.printf " Nro lines %i lines_from_files ====================> [%s] \n" nrolinesinfile actionsset;

    let actionfx = String.split_on_char ':' actionsset in
    (*let size = String.length(List.nth words 0) in*)
    let action_single =   (List.nth actionfx 1) in
    Printf.printf "BORDER CARD ====================> [%s] \n" action_single;   


    (*if (action_single = "⟙") then exit 0;*)

(* Remove that illegal action from the set of actions *)

let string_of_command4 () =
  let tmp_file = filescore in
  (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
  let _ = Sys.command (Printf.sprintf "sed -i '%s/d/' ../sdata/02_actions_t%i.txt" action_single !clock2) in
  let chan = open_in tmp_file in
             close_in chan
        in
        string_of_command4();  
        
        

    (* Agrega la mov ilegal al ilegalpositions file*)
if (String.length action_single > 3) then     
  begin

    let tmp_file = filescore in
    let _ = Sys.command (Printf.sprintf "sed -i '1s/$/, %s/' %s" action_single ilegalpositions)   in
    let chan = open_in tmp_file in
            close_in chan;




    let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i -e 's/pos_/pos(/g' -e 's/_p/,p/g' -e 's/_t/,/g' -e 's/x, //g' -e 's/$/)/g' %s" ilegalpositions)   in
  
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();       



  let string_of_command4 () =
    let tmp_file = filescore in
    (* Agregar el set $ILEGALMOV en ../sdata/01_ini_set.txt *)
    let _ = Sys.command (Printf.sprintf "sed -i '/^$ILEGALMOV/d' ../sdata/01_ini_set.txt") in
    let chan = open_in tmp_file in
                close_in chan
          in
          string_of_command4();   
  


  let ilegalmovsline = List.nth (lines_from_files ilegalpositions) 0 in        

  (* Add the line $BORDERCARDS = in 00_ini_set.txt with the content in bordercards file*)  
  let string_of_command4 () =
    let tmp_file = filescore in
    (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
    (* Printf.printf "+++++++++++ ADDING CARD :: %s  \n" bordercardsline;  *)
    let _ = Sys.command (Printf.sprintf "sed -i '/$BORDERCARDS/a $ILEGALMOV = [%s]' ../sdata/01_ini_set.txt" ilegalmovsline) in
    let chan = open_in tmp_file in
                close_in chan
          in
          string_of_command4();

  end;





(* --- *)


if (String.length action_single == 3) then 

    begin
    Printf.printf "DENTRO del action_single => %s && size : %i\n" action_single (String.length action_single)  ;

    (*let actioncard = (List.nth (String.split_on_char '_' action_single) 1) in    *)

    (* Agrega la carta ilegal al bodercards*)
    (*
    let tmp_file = filescore in
    let _ = Sys.command (Printf.sprintf "sed -i '1s/$/%s,/' %s" actioncard bordercards)   in
    Printf.printf "+++++++++++ FINAL BORDER CARD :: %s  \n" actioncard;  
    let chan = open_in tmp_file in
            close_in chan;
    *)        
    (* --- *)

            
    (* Remove the line starting with $BORDERCARDS = in 00_ini_set.txt *)        
    let string_of_command4 () =
      let tmp_file = filescore in
      (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
      Printf.printf "+++++++++++ REMOVE $BORDERCARDS label :: %s  \n" action_single; 
      let _ = Sys.command (Printf.sprintf "sed -i '/^$BORDERCARDS/d' ../sdata/01_ini_set.txt") in
      let chan = open_in tmp_file in
                 close_in chan
            in
            string_of_command4();  

    let bordercardsline = List.nth (lines_from_files bordercards) 0 in        

    (* Add the line $BORDERCARDS = in 00_ini_set.txt with the content in bordercards file*)  
    let string_of_command4 () =
      let tmp_file = filescore in
      (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
      Printf.printf "+++++++++++ ADDING CARD :: %s  \n" bordercardsline; 
      let _ = Sys.command (Printf.sprintf "sed -i '/$MARKCARDS/a $BORDERCARDS = [%s]' ../sdata/01_ini_set.txt" bordercardsline) in
      let chan = open_in tmp_file in
                 close_in chan
            in
            string_of_command4();


    (* Add the lines con ilegal positions en  ilegalpositions file*)  
    (*let string_of_command4 () =
      let tmp_file = filescore in
      (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
      Printf.printf "+++++++++++ Adiciona Ilegal Position :: %s  \n" action_single; 
      let _ = Sys.command (Printf.sprintf "echo %s >> %s" (action_single^")") ilegalpositions) in
      let chan = open_in tmp_file in
                 close_in chan
            in
            string_of_command4();*)





      


  end;







            
    (* Remove the last line in interface.txt and interfacefx.txt *)            
    let string_of_command4 () =
      let tmp_file = filescore in
      (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
      Printf.printf "+++++++++++ REM interface :: %s  \n" action_single; 
      let _ = Sys.command (Printf.sprintf "sed -i '$ d' ../sdata/interface.txt") in
      let _ = Sys.command (Printf.sprintf "sed -i '$ d' ../sdata/interfacefx.txt") in
      let chan = open_in tmp_file in
                 close_in chan
            in
            string_of_command4();   

    let string_of_command4 () =
      let tmp_file = filescore in
      let _ = Sys.command (Printf.sprintf "sed -i -e 's/,]/]/g' ../sdata/01_ini_set.txt")   in
  
      let chan = open_in tmp_file in
              close_in chan
              in
      string_of_command4();       
    
            (* ,] *)

  end;
end




