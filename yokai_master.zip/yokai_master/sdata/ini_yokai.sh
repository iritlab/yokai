cat ../sdata/interface_bk.txt > ../sdata/interface.txt
cat ../sdata/interfacefx_bk.txt > ../sdata/interfacefx.txt
cat ../sdata/00_delta0_base_bk.txt > ../sdata/00_delta0_base.txt
cat ../sdata/00_delta0_base_and_bk.txt > ../sdata/00_delta0_base_and.txt
cat ../sdata/99_clock_bk.txt > ../sdata/99_clock.txt
java -jar yokaiGame.jar
