open Printf

class t  (model:string) (actions:string) (goal:string) (encoding : int) =
object (self)


method search = (* notimed_search *)

let command cmd =
  Sys.command cmd
in



(* 
model = 01_ini_state.txt 
*)
let filemodel = "../sdata/"^model in
let filevol = "../sdata/00_delta0_base_and.txt" in
let fileactions = "../sdata/"^actions in
let filegoal = "../sdata/"^goal in


Printf.printf "FILEMODEL ==> %s \n" filemodel;

let contains s1 s2 =
  let re = Str.regexp_string s2
  in
      try ignore (Str.search_forward re s1 0); true
      with Not_found -> false in


flush stdout; flush stderr;
Utils.print "Select TouIST\n";
flush stdout; flush stderr;
let returncode = (command "./main.exe --version") in
Utils.print "\n";




flush stdout; flush stderr;
if returncode == 0 then Utils.print ""
else begin Utils.eprint "[Error %d] please install TouIST with : brew install touist\n" returncode; exit returncode; end;


(** START SATPLAN-SOLVE - JFDX 20200408 **)
if (encoding = 1) then
begin

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in



let plan m = 

Printf.printf " ACA estamos despues del : plan m : %i  \n" !m;

let clock = List.nth (lines_from_files "../sdata/99_clock.txt") 0 in
let clock2 = ref 0 in

(*Printf.printf "Clock = %s  \n" clock;*)

let rec extract k list =
    if k <= 0 then [ [] ]
    else match list with
         | [] -> []
         | h :: tl ->
            let with_h = List.map (fun l -> h :: l) (extract (k-1) tl) in
            let without_h = extract k tl in
            with_h @ without_h in

let flatten l =
  let rec loop res = function
    | [] -> List.rev res
    | h::t -> loop (List.rev_append h res) t
  in
    loop [] l in

(*let reslst = flatten (extract !m (lines_from_files "planerdata/02_op.txt")) in*)

(*
let string_of_command4 () =
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in
  let chan = open_in tmp_file in
            close_in chan
        in
        string_of_command4(); 


let string_of_command4 () =
  let tmp_file = "planerdata/99_tmp.txt" in
  (*let _ = Sys.command (Printf.sprintf "cat ../sdata/00_delta0_base.txt > ../sdata/00_delta0_base_and.txt") in*)
  let _ = Sys.command (Printf.sprintf "sed -i 's/$/ and/' ../sdata/00_delta0_base_and.txt") in
  let chan = open_in tmp_file in
             close_in chan
        in
        string_of_command4();         
*)




let string_of_command4 () =
let tmp_file = "planerdata/99_tmp.txt" in
let _ = Sys.command (Printf.sprintf "cat %s > solvedatacp/tmp_actions.txt" fileactions) in
let chan = open_in tmp_file in
          close_in chan
      in
      string_of_command4(); 



let string_of_command4 () =
let tmp_file = "planerdata/99_tmp.txt" in
(* For ChatBot app *)
(*let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(1,2,//g' -e 's/.$//' -e 's/\[/(/g' -e 's/]/)/g' solvedatacp/tmp_actions.txt") in*)
(* For Yokai app - Dont remove the last char of the action*)
let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(1,2,//g' -e 's/\[/(/g' -e 's/]/)/g' solvedatacp/tmp_actions.txt") in
let chan = open_in tmp_file in
          close_in chan
      in
      string_of_command4(); 









(* solvedatacp/tmp_actions constains the actions which will be tested to see if with one of these it is possible to achieve the Goal *)
let reslst = flatten (extract !m (lines_from_files "solvedatacp/tmp_actions.txt")) in
  (*Printf.printf " ACa estamos 003 : \n";*)
  (*List.iter(printf "OP flat ...: %s\n") reslst;*)

      let a = ref 1 in
      let action = ref "" in

      let ll = ref [] in
      ll := reslst;
      let s = ref 0 in 
        s := List.length reslst;



      let string_of_command4 () =
        let tmp_file = "planerdata/99_tmp.txt" in
        let _ = Sys.command (Printf.sprintf "sed -i 's/ //g' ../sdata/00_hint_color.txt") in
        let chan = open_in tmp_file in
                  close_in chan
              in
              string_of_command4(); 






      let line_hint = (lines_from_files "../sdata/00_hint_color.txt") in        

        (* OJO - OJO esta es la parte que llena el file pato.txt  - VERY IMPORTANT*)
            while (!a <= List.length reslst ) do
              a := !a + 1;
                let string_of_command4 () =
                let tmp_file = "planerdata/99_tmp.txt" in
                let _ = 
                      action := (List.hd !ll);
                      if (contains (!action) "col_") then
                        (* Get the card number and the time point *)

                        let words = String.split_on_char '_' !action in
                        let cardnum = (List.nth words 1) in
                        let timepoint = (List.nth words 3) in
                        let timepointold = string_of_int (int_of_string (String.sub  timepoint 1 ((String.length(timepoint)) - 1)) - 1) in

                        let precondition = "[m]now_t"^timepointold^" and [m] (not mark_"^cardnum^"_1_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_2_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_3_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_4_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_5_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_6_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_7_t"^timepointold^")"
                                     in

                        let effect = "(th_tm_col_"^cardnum^"_G_"^timepoint^" or "^
                                     "th_tm_col_"^cardnum^"_Y_"^timepoint^" or "^
                                     "th_tm_col_"^cardnum^"_B_"^timepoint^" or "^
                                     "th_tm_col_"^cardnum^"_R_"^timepoint^")"
                                     in

                                let _ = Sys.command (Printf.sprintf "echo ')=> (%s and plusa[[%s and tm_%s and %s]' >> solvedatacp/pato_%i.txt" precondition (List.hd !ll) (List.hd !ll) effect !m) in
                                        Sys.command (Printf.sprintf "echo '%s and tm_%s and %s' >> solvedatacp/pato_%i_seq.txt" (List.hd !ll) (List.hd !ll) effect !m)

                      (*else if (contains (!action) "pos_") then

                        let words = String.split_on_char '_' !action in
                        let cardnum = (List.nth words 1) in
                        let timepoint = (List.nth words 3) in
                        let timepointold = string_of_int (int_of_string (String.sub  timepoint 1 ((String.length(timepoint)) - 1)) - 1) in

                        let precondition = "[m] (not mark_"^cardnum^"_1_t"^timepointold^" and "^
                                    "not mark_"^cardnum^"_2_t"^timepointold^" and "^
                                    "not mark_"^cardnum^"_3_t"^timepointold^" and "^
                                    "not mark_"^cardnum^"_4_t"^timepointold^" and "^
                                    "not mark_"^cardnum^"_5_t"^timepointold^" and "^
                                    "not mark_"^cardnum^"_6_t"^timepointold^" and "^
                                    "not mark_"^cardnum^"_7_t"^timepointold^")"
                                    in

                                (*let _ = Sys.command (Printf.sprintf "echo ')=> (%s and plusa[[%s and tm_%s and %s]' >> solvedatacp/pato_%i.txt" precondition (List.hd !ll) (List.hd !ll) effect !m) in
                                        Sys.command (Printf.sprintf "echo '%s and tm_%s and %s' >> solvedatacp/pato_%i_seq.txt" (List.hd !ll) (List.hd !ll) effect !m)*)

                                let _ = Sys.command (Printf.sprintf "echo ')=> (%s and plusa[[%s and tm_%s]' >> solvedatacp/pato_%i.txt" precondition (List.hd !ll) (List.hd !ll) !m) in
                                        Sys.command (Printf.sprintf "echo '%s and tm_%s' >> solvedatacp/pato_%i_seq.txt" (List.hd !ll) (List.hd !ll) !m)                                     *)



                      
                      else if (contains (!action) "mark_") then

                        (* Get the card number and the time point *)


                        let words = String.split_on_char '_' !action in
                        Printf.printf "DESPUES DEL MARK ....\n";                        
                        let cardnum = (List.nth words 1) in
                        let hintnum = (List.nth words 2) in
                        let timepoint = (List.nth words 3) in
                        let timepointold = string_of_int (int_of_string (String.sub  timepoint 1 ((String.length(timepoint)) - 1)) - 1) in
                        let hprecondition_line = ref "" in
                        let hprecondition = ref "" in

                        (*let now = "[m]now"^"_t"^timepointold in*)

                        let aprecondition = "[m]act_"^hintnum^"_t"^timepointold in

                        if (hintnum = "1") then
                          begin
                            Printf.printf "DESPUES DEL IF %s \n" hintnum;
                            hprecondition_line := (List.nth line_hint 0);
                            let hint_colors = String.split_on_char ',' !hprecondition_line in
                              hprecondition := "[m]col_"^cardnum^"_"^(List.nth hint_colors 0)^"_t"^timepointold;
                          end;

                        if (hintnum = "4") then
                          begin
                            Printf.printf "DESPUES DEL IF %s \n" hintnum;
                            hprecondition_line := (List.nth line_hint 3);
                            let hint_colors = String.split_on_char ',' !hprecondition_line in
                              hprecondition := "[m]col_"^cardnum^"_"^(List.nth hint_colors 0)^"_t"^timepointold;
                          end;                          

                        if (hintnum = "2") then
                          begin
                            Printf.printf "DESPUES DEL IF %s \n" hintnum;
                            hprecondition_line := (List.nth line_hint 1);
                            let hint_colors = String.split_on_char ',' !hprecondition_line in
                              hprecondition := "([m]col_"^cardnum^"_"^(List.nth hint_colors 0)^"_t"^timepointold^" or "^"[m]col_"^cardnum^"_"^(List.nth hint_colors 1)^"_t"^timepointold^")";
                          end;
                          
                        if (hintnum = "5") then
                          begin
                            Printf.printf "DESPUES DEL IF %s \n" hintnum;
                            hprecondition_line := (List.nth line_hint 4);
                            let hint_colors = String.split_on_char ',' !hprecondition_line in
                              hprecondition := "([m]col_"^cardnum^"_"^(List.nth hint_colors 0)^"_t"^timepointold^" or "^"[m]col_"^cardnum^"_"^(List.nth hint_colors 1)^"_t"^timepointold^")";
                          end;                          

                        if (hintnum = "7") then
                          begin
                            Printf.printf "DESPUES DEL IF %s \n" hintnum;
                            hprecondition_line := (List.nth line_hint 6);
                            let hint_colors = String.split_on_char ',' !hprecondition_line in
                              hprecondition := "([m]col_"^cardnum^"_"^(List.nth hint_colors 0)^"_t"^timepointold^" or "^"[m]col_"^cardnum^"_"^(List.nth hint_colors 1)^"_t"^timepointold^")";
                          end;   

                        if (hintnum = "3") then
                          begin
                            Printf.printf "DESPUES DEL IF %s \n" hintnum;
                            hprecondition_line := (List.nth line_hint 2);
                            let hint_colors = String.split_on_char ',' !hprecondition_line in
                              hprecondition := "([m]col_"^cardnum^"_"^(List.nth hint_colors 0)^"_t"^timepointold^" or "^"[m]col_"^cardnum^"_"^(List.nth hint_colors 1)^"_t"^timepointold^" or "^"[m]col_"^cardnum^"_"^(List.nth hint_colors 2)^"_t"^timepointold^")";
                          end;


                        if (hintnum = "6") then
                          begin
                            Printf.printf "DESPUES DEL IF %s \n" hintnum;
                            hprecondition_line := (List.nth line_hint 5);
                            let hint_colors = String.split_on_char ',' !hprecondition_line in
                              hprecondition := "([m]col_"^cardnum^"_"^(List.nth hint_colors 0)^"_t"^timepointold^" or "^"[m]col_"^cardnum^"_"^(List.nth hint_colors 1)^"_t"^timepointold^" or "^"[m]col_"^cardnum^"_"^(List.nth hint_colors 2)^"_t"^timepointold^")";
                          end;

                        let precondition = "[m]now_t"^timepointold^" and [m] (not mark_"^cardnum^"_1_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_2_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_3_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_4_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_5_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_6_t"^timepointold^" and "^
                                     "not mark_"^cardnum^"_7_t"^timepointold^")"
                                     in

                        (*let effect = "(th_tm_col_"^cardnum^"_G_"^timepoint^" or "^
                                     "th_tm_col_"^cardnum^"_Y_"^timepoint^" or "^
                                     "th_tm_col_"^cardnum^"_B_"^timepoint^" or "^
                                     "th_tm_col_"^cardnum^"_R_"^timepoint^")"
                                     in*)

                                let _ = (*Sys.command (Printf.sprintf "echo ')=> (%s and %s and %s and %s and plusa[[%s and tm_%s]' >> solvedatacp/pato_%i.txt" now aprecondition !hprecondition precondition (List.hd !ll) (List.hd !ll) !m) in*)
                                        Sys.command (Printf.sprintf "echo ')=> (%s and %s and %s and plusa[[%s and tm_%s and th_%s]' >> solvedatacp/pato_%i.txt" aprecondition !hprecondition precondition (List.hd !ll) (List.hd !ll) (List.hd !ll) !m) in
                                        Sys.command (Printf.sprintf "echo '%s and tm_%s and th_%s' >> solvedatacp/pato_%i_seq.txt" (List.hd !ll) (List.hd !ll) (List.hd !ll) !m)


                      else if (contains (!action) "pos_") then

                        let words = String.split_on_char '_' !action in
                        Printf.printf "DESPUES DEL POS ....\n";                        
                        let cardnum = (List.nth words 1) in
                        let hintnum = (List.nth words 2) in
                        let timepoint = (List.nth words 5) in
                        let timepointold = string_of_int (int_of_string (String.sub  timepoint 1 ((String.length(timepoint)) - 1)) - 1) in
                        let hprecondition_line = ref "" in
                        let hprecondition = ref "" in                      
                                        
                        let precondition = "[m]now_t"^timepointold^" and [m] (not mark_"^cardnum^"_1_t"^timepointold^" and "^
                        "not mark_"^cardnum^"_2_t"^timepointold^" and "^
                        "not mark_"^cardnum^"_3_t"^timepointold^" and "^
                        "not mark_"^cardnum^"_4_t"^timepointold^" and "^
                        "not mark_"^cardnum^"_5_t"^timepointold^" and "^
                        "not mark_"^cardnum^"_6_t"^timepointold^" and "^
                        "not mark_"^cardnum^"_7_t"^timepointold^")"in

                        let _ = (*Sys.command (Printf.sprintf "echo ')=> (%s and %s and %s and %s and plusa[[%s and tm_%s]' >> solvedatacp/pato_%i.txt" now aprecondition !hprecondition precondition (List.hd !ll) (List.hd !ll) !m) in*)
                                        Sys.command (Printf.sprintf "echo ')=> (%s and plusa[[%s and tm_%s and th_%s]' >> solvedatacp/pato_%i.txt" precondition (List.hd !ll) (List.hd !ll) (List.hd !ll) !m) in
                                        Sys.command (Printf.sprintf "echo '%s and tm_%s and th_%s' >> solvedatacp/pato_%i_seq.txt" (List.hd !ll) (List.hd !ll) (List.hd !ll) !m)                        

                      else
                                let words = String.split_on_char '_' !action in
                                let timepoint = (List.nth words 2) in
                                let timepointold = string_of_int (int_of_string (String.sub  timepoint 1 ((String.length(timepoint)) - 1)) - 1) in
                                let _ = Sys.command (Printf.sprintf "echo ')=> ([m]now_t%s and plusa[[%s and tm_%s and th_%s]' >> solvedatacp/pato_%i.txt" timepointold (List.hd !ll) (List.hd !ll) (List.hd !ll) !m) in
                                        Sys.command (Printf.sprintf "echo '%s and tm_%s and th_%s' >> solvedatacp/pato_%i_seq.txt" (List.hd !ll) (List.hd !ll) (List.hd !ll) !m) in

                
                
                let chan = open_in tmp_file in
                close_in chan
                
              in
              string_of_command4();  
              ll := List.tl !ll;
              
            done ;
           (* End-while *)            
                  (*
                let string_of_command4 () =
                let tmp_file = "planerdata/99_tmp.txt" in
                (* For ChatBox app*)
                (*let _ = Sys.command (Printf.sprintf "sed -i -e 's_.*_plusa[{2}[&_' -e 's/$/]/' solvedatacp/pato_%i.txt" !m) in*)
                (* For Yokai app - remove {2} *)
                let _ = Sys.command (Printf.sprintf "sed -i -e 's_.*_plusa[[&_' -e 's/$/]/' solvedatacp/pato_%i.txt" !m) in
                let chan = open_in tmp_file in
                close_in chan
              in
              string_of_command4();  
              *)



             (* let string_of_command4 () =
                let tmp_file = "planerdata/99_tmp.txt" in
                (* For ChatBox app*)
                (*let _ = Sys.command (Printf.sprintf "sed -i -e 's_.*_plusa[{2}[&_' -e 's/$/]/' solvedatacp/pato_%i.txt" !m) in*)
                (* For Yokai app - remove {2} *)
                let _ = Sys.command (Printf.sprintf "sed -i -e 's/^/%s' -e 's/$/]/' solvedatacp/pato_%i.txt" precondition !m) in
                let chan = open_in tmp_file in
                close_in chan
              in
              string_of_command4();  *)




let parse3ac() = 
    let lines = ref "" in
    let lines2 = ref "" in
    let action = ref "" in
    let i = ref 1 in
    let tmp_file = Printf.sprintf "solvedatacp/pato_%i.txt"!m in
    let chan = open_in tmp_file in
    let j = ref 0 in
    let touistcode2 = ref 0 in
    j := 0;
    try
      while true do
        j := !j + 1;
        action := input_line chan;
        lines := !action ^", "^ !lines;
        lines2 := !action ^"\n"^ !lines2;
        (*Printf.printf "ANTES DE ENTRAR AL IF %s - %i \n\n" !lines !m;*)
        if !j = !m then  begin 
                        (*Printf.printf "DESPUES DEL IF %s - %i \n" !lines !m;*)
                        let string_of_command4 () =
                                
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = (*Printf.printf "DESPUES DEL IF 2222 %s %i %i \n" !lines !m !i;*)
                                        Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/pato_seq_%i_%i.txt" !lines !m !i);  
                                        Sys.command (Printf.sprintf "echo '%s' > solvedatacp/plan_final2.txt" !lines2);
                                        (*Printf.printf "DESPUES DEL IF 333 %s %i %i \n" !lines !m !i;*) in
                                let chan = open_in tmp_file in
                                close_in chan
                              in
                              string_of_command4();  

                        let string_of_command4 () =
                                
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i -e 's/]/)/g' -e 's/\[/(/g' solvedatacp/pato_seq_%i_%i.txt" !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                              in
                              string_of_command4();  


                        let string_of_command4 () =
                                
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "cat %s > solvedatacp/03_goalb.txt" filegoal)   in
                                let chan = open_in tmp_file in
                                close_in chan
                              in
                              string_of_command4();  


                        let string_of_command4 () =
                                
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i '1 i\ [m]' solvedatacp/03_goalb.txt")   in
                                let chan = open_in tmp_file in
                                close_in chan
                              in
                              string_of_command4();  




                        (* Generating the Planning Formula*)  
                        let string_of_command5 () =
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "cat %s %s solvedatacp/pato_seq_%i_%i.txt solvedatacp/03_goalb.txt >  solvedatacp/formula_%i_%i.txt" filevol filemodel !m !i !m !i)   in 
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command5();  

                        (* End - Generations of the Planning Formula*)    

(*
                        let string_of_command4 () =
                                
                                let tmp_file = "planerdata/01_model.txt" in
                                (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/)plusa/))=> plusa/g' -e 's/)),/)),[a]/g' -e 's/~/not /g' solvedatacp/formula_%i_%i.txt" !m !i)   in*)
                                let _ = Sys.command (Printf.sprintf "sed -i '0,/plusa/s/plusa/)=> plusa/' solvedatacp/formula_%i_%i.txt" !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                              in
                              string_of_command4();  
*)                              


(*
                            for j = 0 to !m + 1 do


                              let string_of_command4 () =
                                      
                                      let tmp_file = "planerdata/01_model.txt" in
                                      let _ = Sys.command (Printf.sprintf "echo ')' >> solvedatacp/formula_%i_%i.txt" !m !i)   in
                                      let chan = open_in tmp_file in
                                      close_in chan
                                    in
                                    string_of_command4(); 

                            done;     
*)                            
                            



                              let string_of_command4 () =
                                
                                let tmp_file = "planerdata/01_model.txt" in
                                (*let _ = Sys.command (Printf.sprintf "sed -i '1 i\ red(not ([m](' solvedatacp/formula_%i_%i.txt" !m !i)   in*)
                                let _ = Sys.command (Printf.sprintf "sed -i '1 i\ (not ([m](' solvedatacp/formula_%i_%i.txt" !m !i)   in
                                
                                (*sed -i '1 i\anything' file*)

                                let chan = open_in tmp_file in
                                close_in chan;

                              in
                              string_of_command4(); 


                              let string_of_command4d() =
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i -e 's/),/,/g' -e 's/(m)/[m]/g' solvedatacp/formula_%i_%i.txt" !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4d();                                  

                              (* Remove the last character    
                              let string_of_command4e() =
                                let tmp_file = "cp_pre_syntax.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i '$ s/.$//' solvedatacp/formula_%i_%i.txt" !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4e();                                
                              *)                                


                              (* Add text at the end of the file *)
                              let string_of_command4e() =
                                let tmp_file = "cp_pre_syntax.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i -e '$a ))))' solvedatacp/formula_%i_%i.txt" !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4e();                                
                              (* *)                                                              



                                let string_of_command4c() =
                                  let tmp_file = "planerdata/01_model.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i 's/{2}(/{2} /g' solvedatacp/formula_%i_%i.txt" !m !i)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4c();  

                                (* For YOKAI to FIX the PLUS_A*)      
                                let string_of_command4c() =
                                  let tmp_file = "planerdata/01_model.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i 's/plusa((/plusa(/g' solvedatacp/formula_%i_%i.txt" !m !i)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4c();  

(*
                                  let string_of_command4 () =
                                      
                                    let tmp_file = "planerdata/01_model.txt" in
                                    let _ = Sys.command (Printf.sprintf "echo ')' >> solvedatacp/formula_%i_%i.txt" !m !i)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                  in
                                  string_of_command4(); 
*)                                  








                                (* End For YOKAI *)                                        




                              (* To manteint the Originial LDA formula*)    
                              let string_of_command4x () =
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "cat solvedatacp/formula_%i_%i.txt > solvedatacp/formula_lda_%i_%i.txt" !m !i !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan;

                              in
                              string_of_command4x(); 


                              (* Here we only replace the {2} by th_ to speed up the process... and that's all*)    
                              let string_of_command4b() =
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i 's/{2} /th_/g' solvedatacp/formula_%i_%i.txt" !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4b();  





                              (* Encapsulates the Process Plan procedure *)  
                              let process () =     
                                Printf.printf "Testing formula_%i_%i.txt \n" !m !i;
                                flush stdout; flush stderr;
                                let seq = ref [] in
                                (*seq := lines_from_files (Printf.sprintf "solvedatacp/pato_seq_%i_%i.txt"!m !i) ;*)
                                seq := lines_from_files (Printf.sprintf "solvedatacp/pato_seq_%i_%i.txt"!m !i) ;
                                Printf.printf "%s \n" (List.hd !seq);





                                (*command (Printf.sprintf "./translator.exe --qbf solvedatacp/%s_formula_%i_%i.txt" opt !m !i);*)
                                command (Printf.sprintf "./translator.exe --sat solvedatacp/formula_%i_%i.txt" !m !i);
                                touistcode2 := (command (Printf.sprintf "./touist.exe ../sdata/proplogic/formula_%i_%i.txt --solve" !m !i));



                                Printf.printf "touistcode ==>  %i \n\n" !touistcode2;
                                flush stdout; flush stderr;




                                if !touistcode2 = 8 then 
                                  begin
                                    Printf.printf "Plan of size %i found  : \n" !m;
                                    flush stdout; flush stderr;
                                    let string_of_command4w () =
                                                          
                                      let tmp_file = "planerdata/01_model.txt" in
                                      let _ = Sys.command (Printf.sprintf "cat 'solvedatacp/pato_seq_%i_%i.txt' > solvedatacp/plan_final.txt" !m !i)   in
                                      flush stdout; flush stderr;
                                      let chan = open_in tmp_file in
                                      close_in chan
                                    in
                                    string_of_command4w(); 



                                    let string_of_command4b() =
                                      let tmp_file = "planerdata/01_model.txt" in
                                      let _ = Sys.command (Printf.sprintf "sed -i 's/.*plusa((//' solvedatacp/plan_final.txt")   in
                                      let chan = open_in tmp_file in
                                      close_in chan
                                      in
                                      string_of_command4b(); 









                                  let string_of_command4b() =
                                    let tmp_file = "planerdata/01_model.txt" in
                                    let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final.txt > solvedatacp/plan_final_show.txt")   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                  in
                                  string_of_command4b();  


                                let string_of_command4b() =
                                  let tmp_file = "planerdata/01_model.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i 's/),/\\n/g' solvedatacp/plan_final_show.txt")   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4b(); 


(* HERE IS ONLY TO TRANSLATE THE PLAN IN A MORE HUMAN LANGUAGE - NL ****)
                              
                              let string_of_command4b() =
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i 's/ plusa({2}(val_te_ass_//g' solvedatacp/plan_final_show.txt")   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4b();  

                              let string_of_command4b() =
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i 's/plusa({2}(val_te_ass_//g' solvedatacp/plan_final_show.txt")   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4b();  

                              let string_of_command4b() =
                                let tmp_file = "planerdata/01_model.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i 's/ plusa({2}(//g' solvedatacp/plan_final_show.txt")   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4b();                                 

                                let string_of_command4b() =
                                  let tmp_file = "planerdata/01_model.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i 's/_h_/_/g' solvedatacp/plan_final_show.txt")   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4b();                                  

                                  let string_of_command4b() =
                                    let tmp_file = "planerdata/01_model.txt" in
                                    let _ = Sys.command (Printf.sprintf "sed -i '/^ *$/d' solvedatacp/plan_final_show.txt")   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4b();                                  
(*
                                let string_of_command4b() =
                                  let tmp_file = "planerdata/01_model.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i '$ s/.$//' solvedatacp/plan_final_show.txt")   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4b();     
*)                                  


                                (* Used after we replace the used of the 99_clock.txt file for the belief base*)    
                                (*
                                let string_of_command4b() =
                                  let tmp_file = "planerdata/01_model.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i -e 's/plusa((//g' -e 's/),//g' -e 's/ //g' -e '1s/^/m:/' -e 's/$/:1/' solvedatacp/plan_final.txt")   in
                                  (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/plusa((//g' -e 's/),//g' -e '1s/^/m:/' -e '$a:1' >> solvedatacp/plan_final.txt")   in*)
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4b();       
                                *)
                                

                                clock2 := (int_of_string clock) + 1;


                                Printf.printf "New Clock = %i  \n" !clock2;
                                (*

                                let string_of_command4b() =
                                  let tmp_file = "planerdata/01_model.txt" in
                                  let _ = Sys.command (Printf.sprintf "echo '"^string_of_int (!clock2)^"' > ../sdata/99_clock.txt")   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                in
                                string_of_command4b();  
                                *)


                                let string_of_command4b() =
                                    let tmp_file = "planerdata/01_model.txt" in
                                    let _ = Sys.command (Printf.sprintf "sed -i -e 's/plusa((//g' -e '1s/^/m:/' -e 's/$/:1/' solvedatacp/plan_final_show.txt")   in
                                    (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/plusa((//g' -e 's/$/%i/' -e '1s/^/m:/' -e 's/$/:1/' solvedatacp/plan_final_show.txt" !clock2)   in*)
                                    (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/plusa((//g'    -e '1s/^/m:/' -e '$a:1' >> solvedatacp/plan_final.txt")   in*)
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4b();                                         



                                let action = List.nth (lines_from_files "solvedatacp/plan_final_show.txt") 0 in
                                      Printf.printf "Contenido de  plan_final_show - Planer = %s  \n" action;
                                let words = String.split_on_char ' ' action in
                                let size = String.length(List.nth words 0) in
                                let action_single =   String.sub  (List.nth words 0) 2 (size-2) in
                                      Printf.printf "Single Action - Planer = %s  \n" action_single;
(*(String.length(List.nth words 0))*)
                                      

                                    


                                let string_of_command4w () =
                                                          
                                    let tmp_file = "planerdata/01_model.txt" in
                                    (* Used after we replace the used of the 99_clock.txt file for the belief base*)    
                                    (*let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final.txt >> ../sdata/interface.txt")   in*)
                                    (*let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final_show.txt >> ../sdata/interface.txt")   in*)
                                    let _ = Sys.command (Printf.sprintf "echo 'm:%s:1' >> ../sdata/interface.txt" action_single) in
                                    let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final_show.txt >> ../sdata/interfacefx.txt") in
                                    flush stdout; flush stderr;
                                    let chan = open_in tmp_file in
                                    close_in chan
                                  in
                                  string_of_command4w(); 

                                (* @@@ *)
                                
                                (*if (contains (action_single) "pos_") then
                                  begin
                                    Printf.printf "DENTRO DEL COL_ !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!  = %s  \n" action_single;
                                    let string_of_command4b() =
                                      let tmp_file = "planerdata/01_model.txt" in
                                      let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' ../sdata/interfacefx.txt")   in
                                      let _ = Sys.command (Printf.sprintf "sed -i -e 's/:1/:0/g' ../sdata/interface.txt")   in

                                      let chan = open_in tmp_file in
                                      close_in chan
                                      in
                                      string_of_command4b();                                         
                                    end;   *)   
                                                                   
                                  (* Increase the Clock.txt file in 1*)
                                  (*
                                  
                                let string_of_command4b() =
                                    let tmp_file = "planerdata/01_model.txt" in
                                    let _ = Sys.command (Printf.sprintf "sed -i -e '1s/^/m:/' -e 's/$/:1/' ../sdata/interface.txt")   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4b();                                     
                                    *)
 





                                    

                                  exit 0;
                                  end                                
                                else  
                                  begin
                                  let string_of_command4w () =
                                                          
                                    let tmp_file = "planerdata/01_model.txt" in
                                    let _ = Sys.command (Printf.sprintf "cat 'solvedatacp/pato_seq_%i_%i.txt' > solvedatacp/plan_final.txt" !m !i)   in
                                    flush stdout; flush stderr;
                                    let chan = open_in tmp_file in
                                    close_in chan
                                  in
                                  string_of_command4w(); 
                                  end    
                              in
                              process();     
                                

                            i := 1 + !i;
                            j := 0;
                            lines := "";
                        end

      done;

     with End_of_file -> close_in chan; 







     in
      parse3ac();
in


let pm = ref 0 in
  (*pm := List.length (lines_from_files "planerdata/02_op.txt");*)
  pm := List.length (lines_from_files fileactions);
  pm := 1;
  
let px = ref 0 in
(* Aca empieza la generacion de las sequences of actions of diferent SIZE *)
(* Para el caso del YOKAI vamos a empezar con SIZE = 4 *)
(*for p = 1 to !pm do*)
for p = 1 to !pm do
  px := p;
  plan px;
done;

Printf.printf " Plan not found \n";

let string_of_command4b() =
  let tmp_file = "planerdata/01_model.txt" in
  let _ = Sys.command (Printf.sprintf "echo 'Sorry, it was not possible to find an ideal sport for you' > solvedatacp/plan_final_show.txt")   in
  let chan = open_in tmp_file in
  close_in chan
in
string_of_command4b();  



exit 0;


end;
end