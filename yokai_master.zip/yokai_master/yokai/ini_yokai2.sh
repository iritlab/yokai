cat ../sdata/00_mark_implies.txt >> ../sdata/00_delta0_base.txt
sed -i 's/$/ and/' ../sdata/00_mark_implies.txt
cat ../sdata/00_mark_implies.txt >> ../sdata/00_delta0_base_and.txt
