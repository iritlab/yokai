package gameAndRules;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import translator.SetOfActions;
import translator.Translator;
import cards.*;

public class Computer extends Player{
	
	Translator translator = new Translator();
	
	boolean firstTime = true;
	
	ArrayList<HintCard> colors = null;
	
	
	public Computer (int num) {
		super (num);
	}
	
	public void runAI (Board b) {
		Runtime runTime = Runtime.getRuntime();
		String executablePath = "./oui.jar";
		
		try {
		Process process = runTime.exec("Java -jar "+ executablePath);
		
		process.waitFor(100000, TimeUnit.MILLISECONDS); // Waiting for the end of the program.  arg 1 : timeout 
		}
		catch (Exception e) {
			System.out.println("Error running programme");
			e.printStackTrace();
			
		}
		System.out.println("Waiting for the end of the execution ? \n");
		// maybe here, we've got the txt file, concerning the result of the computer's play
	}
	
	public Card play (Board b, ArrayList<Object> computerAction) {
		Card out = null;
		if (computerAction.get(0).equals(SetOfActions.COL)) {
			System.out.println("The computer have seen the card "+ computerAction.get(1));
			out = b.getTheCardFromNum((int)computerAction.get(1));
		}
		else if (computerAction.get(0).equals(SetOfActions.POS)) {
			System.out.println("The computer decided to put the card " + computerAction.get(1)+" on pos "+computerAction.get(2).toString());
			out = b.getTheCardFromNum((int)computerAction.get(1));
			b.move(out,(Position)computerAction.get(2));
		}
		else if (computerAction.get(0).equals(SetOfActions.MARK)) {
			System.out.println("The computer decided to put the Hint " + computerAction.get(2)+" on card "+computerAction.get(1));
			HintCard h = b.getAllHints().get((int)computerAction.get(2)-1);
			out = b.getTheCardFromNum((int)computerAction.get(1));
			b.putHintHere(h, out.getPos());
		}
		else if (computerAction.get(0).equals(SetOfActions.ACT)) {
			System.out.println("The computer shows the hint number "+computerAction.get(1));
			HintCard h = b.getAllHints().get((int)computerAction.get(1)-1);
			h.setVisible();
		}
		else {
			System.out.println("Recognition action issue");
		}
		//Translator.deleteDirectory(Translator.path);
		return out;
	}
}
