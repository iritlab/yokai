package gameAndRules;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.SortedSet;
import java.util.TreeSet;

import cards.Card;
import cards.ColorEnum;
import cards.DuoHint;
import cards.HintCard;
import cards.PriHint;
import cards.TrioHint;

public class Player {
	
	private int numPlayer = 0;

	public Player(int num) {
		numPlayer = num;
	}

	public int getNumPlayer() {
		return numPlayer;
	}

	public boolean equals(Object o) {
		return (o instanceof Player) && (((Player) o).getNumPlayer() == numPlayer);
	}
}
