package gameAndRules;
import cards.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.SortedSet;
import java.util.TreeSet;

public class Hints {
	
	private ArrayList<HintCard> listOfHints;
	
	private Random rand = new Random();
	
	public Hints () {
		
		listOfHints = new ArrayList<>();
		setUpHints();
	}
	
	
	private void setUpHints() {
		PriHint toAdd1 = null;
		DuoHint toAdd2 = null;
		TrioHint toAdd3 = null;
		ColorEnum color1, color2, color3, color4, color5;
		int num = 1;
		for (int i = 0; i < 3; i++) {
			if (i == 2) {
				do {
					color1 = ColorEnum.valueOf(rand.nextInt(4));
					color2 = ColorEnum.valueOf(rand.nextInt(4));
					ColorEnum[] tabColors = { color1, color2 };
					toAdd2 = new DuoHint(tabColors, num);
				} while (color1 == color2 || listOfHints.contains(toAdd2));
				listOfHints.add(toAdd2);
				num ++;
			} else {
				do {  //JFD : 2022_03_18 - comentado solo para generar hints de color GREEN
					ColorEnum color = ColorEnum.valueOf(rand.nextInt(4));
                                        //ColorEnum color = ColorEnum.GREEN;
					toAdd1 = new PriHint(color, num);
				} while (listOfHints.contains(toAdd1));
				listOfHints.add(toAdd1);
				num++;

				do {
					color1 = ColorEnum.valueOf(rand.nextInt(4));
					color2 = ColorEnum.valueOf(rand.nextInt(4));
					ColorEnum[] tabColors1 = { color1, color2 };
					toAdd2 = new DuoHint(tabColors1, num);
				} while (color1 == color2 || listOfHints.contains(toAdd2));
				listOfHints.add(toAdd2);
				num ++;

				do {
					color3 = ColorEnum.valueOf(rand.nextInt(4));
					color4 = ColorEnum.valueOf(rand.nextInt(4));
					color5 = ColorEnum.valueOf(rand.nextInt(4));
                                        
					ColorEnum[] tabColors2 = { color3, color4, color5 };
					toAdd3 = new TrioHint(tabColors2, num);
				} while (color3 == color4 || color4 == color5 || color3 == color5 || listOfHints.contains(toAdd3));
				listOfHints.add(toAdd3);
				num++;
			}
		}
	}
	
	public ArrayList<HintCard> getlistOfHints (){
		return listOfHints;
	}
	
	public ArrayList<HintCard> getViewedHints(boolean played) {
		ArrayList<HintCard> out = new ArrayList<>();
		
		for (HintCard h : listOfHints) {
			if (h.getVisible() && ((h.getPlayed() && played) || !h.getPlayed())) {
				out.add(h);
			}
		}
		return out;
	}


	
	public boolean haveHintToPlay() {
		return !getViewedHints(false).isEmpty();
	}
	
	public boolean noMoreHintToSee() {
		return getViewedHints(true).size() == 7;
	}
	
	public ArrayList<HintCard> getAllHints(boolean viewed){
		return (viewed)?getViewedHints(false):listOfHints;
	}
	
	public HintCard getThisViewedHint (int num) {
		HintCard h = getViewedHints(false).get(num-1);
		if (!h.getVisible()) return null;
		return h;
	}
	
	public ArrayList<HintCard> getNoViewedHints(){
		ArrayList<HintCard> out = new ArrayList<>();
		for (HintCard h : listOfHints) {
			if (!h.getVisible() && !h.getPlayed()) {
				out.add(h);
			}
		}
		return out;
	}
	
	
	public int getTheNumOfThisHint (HintCard h) {
		return h.getNumOfTheCard();
	}
	
}
