package gameAndRules;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Random;
import java.util.TreeSet;

import cards.*;

public class Board {

	public final static int LENGTH = 28;
	private Card[][] cardList;
	private Player player1 = null;
	private Player player2 = null;
	private Random rand = new Random();
	private boolean p1Turn = true;
	public boolean gameOver = false;
	//private boolean success = true;
        public boolean success = true;
	private Hints hintDeck;
	private ArrayList<Card> cardsByNum = null;

	private void setUpCardsByNum() {
		cardsByNum = new ArrayList<>();
		int num = 1;
		for (int i = 0; i < LENGTH; i++) {
			for (int j = 0; j < LENGTH; j++) {
				Card c = cardList[i][j];
				if (c != null) {
					cardsByNum.add(c);
					c.setNumCard(num);
					num ++;
				}
			}
		}
	}

	private void setUpCards() {
		int x = 0, y = 0;
		Position pos = null;
		int num = 1;
                //ColorEnum c;
                //Card toAdd;
                
                
		for (ColorEnum c : ColorEnum.values()) {
			for (int i = 0; i < 4; i++) {
				do {
					x = rand.nextInt(4);
					y = rand.nextInt(4);
				} while (cardList[x + (LENGTH - 4) / 2][y + (LENGTH - 4) / 2] != null);
				pos = new Position((LENGTH - 4) / 2 + x, (LENGTH - 4) / 2 + y);
				Card toAdd = new Card(c, pos, num);
				cardList[(LENGTH - 4) / 2 + x][(LENGTH - 4) / 2 + y] = toAdd;
				num++;
			}
		}
                
                
                /* Case [001] ---

                            c = ColorEnum.RED;
                            pos = new Position(12,12);
                            toAdd = new Card(c, pos, 1);
                            cardList[12][12] = toAdd;
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(12,13);
                            toAdd = new Card(c, pos, 2);
                            cardList[12][13] = toAdd;                            

                            c = ColorEnum.GREEN;
                            pos = new Position(12,14);
                            toAdd = new Card(c, pos, 3);
                            cardList[12][14] = toAdd;                             

                            
                            c = ColorEnum.BLUE;        //4
                            pos = new Position(12,15);
                            toAdd = new Card(c, pos, 4);
                            cardList[12][15] = toAdd;                                                         
                            
                            c = ColorEnum.GREEN;
                            pos = new Position(13,12);
                            toAdd = new Card(c, pos, 5);
                            cardList[13][12] = toAdd;
                            
                            c = ColorEnum.YELLOW;
                            pos = new Position(13,13);
                            toAdd = new Card(c, pos, 6);
                            cardList[13][13] = toAdd;                            

                            c = ColorEnum.GREEN;
                            pos = new Position(13,14);
                            toAdd = new Card(c, pos, 7);
                            cardList[13][14] = toAdd;                             

                            c = ColorEnum.RED;         //8
                            pos = new Position(13,15);
                            toAdd = new Card(c, pos, 8);
                            cardList[13][15] = toAdd;                               


                            c = ColorEnum.BLUE;
                            pos = new Position(14,12);
                            toAdd = new Card(c, pos, 9);
                            cardList[14][12] = toAdd;

                            c = ColorEnum.YELLOW;                            
                            pos = new Position(14,13);
                            toAdd = new Card(c, pos, 10);
                            cardList[14][13] = toAdd;                            

                            c = ColorEnum.YELLOW;
                            pos = new Position(14,14);
                            toAdd = new Card(c, pos, 11);
                            cardList[14][14] = toAdd;                             
                            
                            c = ColorEnum.RED;           //12
                            pos = new Position(14,15);
                            toAdd = new Card(c, pos, 12);
                            cardList[14][15] = toAdd;                                 
       
                            
                            c = ColorEnum.YELLOW;
                            pos = new Position(15,12);
                            toAdd = new Card(c, pos, 13);
                            cardList[15][12] = toAdd;
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(15,13);
                            toAdd = new Card(c, pos, 14);
                            cardList[15][13] = toAdd;                            

                            c = ColorEnum.GREEN;
                            pos = new Position(15,14);
                            toAdd = new Card(c, pos, 15);
                            cardList[15][14] = toAdd;                             

                            c = ColorEnum.RED;
                            pos = new Position(15,15);
                            toAdd = new Card(c, pos, 16);
                            cardList[15][15] = toAdd;     

                     */                                
                
                
                
                /* Case [001] ---*/
                /*
                            c = ColorEnum.YELLOW;
                            pos = new Position(12,12);
                            toAdd = new Card(c, pos, 1);
                            cardList[12][12] = toAdd;
                            
                            c = ColorEnum.GREEN;
                            pos = new Position(12,13);
                            toAdd = new Card(c, pos, 2);
                            cardList[12][13] = toAdd;                            

                            c = ColorEnum.YELLOW;
                            pos = new Position(12,14);
                            toAdd = new Card(c, pos, 3);
                            cardList[12][14] = toAdd;                             

                            
                            c = ColorEnum.BLUE;        //4
                            pos = new Position(12,15);
                            toAdd = new Card(c, pos, 4);
                            cardList[12][15] = toAdd;                                                         
                            
                            c = ColorEnum.RED;
                            pos = new Position(13,12);
                            toAdd = new Card(c, pos, 5);
                            cardList[13][12] = toAdd;
                            
                            c = ColorEnum.YELLOW;
                            pos = new Position(13,13);
                            toAdd = new Card(c, pos, 6);
                            cardList[13][13] = toAdd;                            

                            c = ColorEnum.YELLOW;
                            pos = new Position(13,14);
                            toAdd = new Card(c, pos, 7);
                            cardList[13][14] = toAdd;                             

                            c = ColorEnum.BLUE;         //8
                            pos = new Position(13,15);
                            toAdd = new Card(c, pos, 8);
                            cardList[13][15] = toAdd;                               


                            c = ColorEnum.RED;
                            pos = new Position(14,12);
                            toAdd = new Card(c, pos, 9);
                            cardList[14][12] = toAdd;

                            c = ColorEnum.RED;                            
                            pos = new Position(14,13);
                            toAdd = new Card(c, pos, 10);
                            cardList[14][13] = toAdd;                            

                            c = ColorEnum.GREEN;
                            pos = new Position(14,14);
                            toAdd = new Card(c, pos, 11);
                            cardList[14][14] = toAdd;                             
                            
                            c = ColorEnum.BLUE;           //12
                            pos = new Position(14,15);
                            toAdd = new Card(c, pos, 12);
                            cardList[14][15] = toAdd;                                 
       
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(15,12);
                            toAdd = new Card(c, pos, 13);
                            cardList[15][12] = toAdd;
                            
                            c = ColorEnum.GREEN;
                            pos = new Position(15,13);
                            toAdd = new Card(c, pos, 14);
                            cardList[15][13] = toAdd;                            

                            c = ColorEnum.GREEN;
                            pos = new Position(15,14);
                            toAdd = new Card(c, pos, 15);
                            cardList[15][14] = toAdd;                             

                            c = ColorEnum.RED;
                            pos = new Position(15,15);
                            toAdd = new Card(c, pos, 16);
                            cardList[15][15] = toAdd;     
                */
                /*  */                
                
                
                /* Case [A] ---
                            c = ColorEnum.RED;
                            pos = new Position(12,12);
                            toAdd = new Card(c, pos, 1);
                            cardList[12][12] = toAdd;
                            
                            c = ColorEnum.RED;
                            pos = new Position(12,13);
                            toAdd = new Card(c, pos, 2);
                            cardList[12][13] = toAdd;                            

                            c = ColorEnum.RED;
                            pos = new Position(12,14);
                            toAdd = new Card(c, pos, 3);
                            cardList[12][14] = toAdd;                             

                            
                            c = ColorEnum.GREEN;        //4
                            pos = new Position(12,15);
                            toAdd = new Card(c, pos, 4);
                            cardList[12][15] = toAdd;                                                         
                            
                            c = ColorEnum.RED;
                            pos = new Position(13,12);
                            toAdd = new Card(c, pos, 5);
                            cardList[13][12] = toAdd;
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(13,13);
                            toAdd = new Card(c, pos, 6);
                            cardList[13][13] = toAdd;                            

                            c = ColorEnum.GREEN;
                            pos = new Position(13,14);
                            toAdd = new Card(c, pos, 7);
                            cardList[13][14] = toAdd;                             

                            c = ColorEnum.GREEN;         //8
                            pos = new Position(13,15);
                            toAdd = new Card(c, pos, 8);
                            cardList[13][15] = toAdd;                               


                            c = ColorEnum.BLUE;
                            pos = new Position(14,12);
                            toAdd = new Card(c, pos, 9);
                            cardList[14][12] = toAdd;

                            c = ColorEnum.BLUE;                            
                            pos = new Position(14,13);
                            toAdd = new Card(c, pos, 10);
                            cardList[14][13] = toAdd;                            

                            c = ColorEnum.YELLOW;
                            pos = new Position(14,14);
                            toAdd = new Card(c, pos, 11);
                            cardList[14][14] = toAdd;                             
                            
                            c = ColorEnum.YELLOW;           //12
                            pos = new Position(14,15);
                            toAdd = new Card(c, pos, 12);
                            cardList[14][15] = toAdd;                                 
       
                            
                            c = ColorEnum.GREEN;
                            pos = new Position(15,12);
                            toAdd = new Card(c, pos, 13);
                            cardList[15][12] = toAdd;
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(15,13);
                            toAdd = new Card(c, pos, 14);
                            cardList[15][13] = toAdd;                            

                            c = ColorEnum.YELLOW;
                            pos = new Position(15,14);
                            toAdd = new Card(c, pos, 15);
                            cardList[15][14] = toAdd;                             

                            c = ColorEnum.YELLOW;
                            pos = new Position(15,15);
                            toAdd = new Card(c, pos, 16);
                            cardList[15][15] = toAdd;                                             
                 */
                
                /* Case [B] 
                            c = ColorEnum.GREEN;
                            pos = new Position(12,12);
                            toAdd = new Card(c, pos, 1);
                            cardList[12][12] = toAdd;
                            
                            c = ColorEnum.GREEN;
                            pos = new Position(12,13);
                            toAdd = new Card(c, pos, 2);
                            cardList[12][13] = toAdd;                            

                            c = ColorEnum.GREEN;
                            pos = new Position(12,14);
                            toAdd = new Card(c, pos, 3);
                            cardList[12][14] = toAdd;                             

                            c = ColorEnum.YELLOW;
                            pos = new Position(12,15);
                            toAdd = new Card(c, pos, 4);
                            cardList[12][15] = toAdd;                                                         
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(13,12);
                            toAdd = new Card(c, pos, 5);
                            cardList[13][12] = toAdd;
                            
                            c = ColorEnum.RED;
                            pos = new Position(13,13);
                            toAdd = new Card(c, pos, 6);
                            cardList[13][13] = toAdd;                            

                            c = ColorEnum.YELLOW;
                            pos = new Position(13,14);
                            toAdd = new Card(c, pos, 7);
                            cardList[13][14] = toAdd;                             

                            c = ColorEnum.BLUE;
                            pos = new Position(13,15);
                            toAdd = new Card(c, pos, 8);
                            cardList[13][15] = toAdd;                               


                            c = ColorEnum.RED;
                            pos = new Position(14,12);
                            toAdd = new Card(c, pos, 9);
                            cardList[14][12] = toAdd;

                            c = ColorEnum.BLUE;                            
                            pos = new Position(14,13);
                            toAdd = new Card(c, pos, 10);
                            cardList[14][13] = toAdd;                            

                            c = ColorEnum.GREEN;
                            pos = new Position(14,14);
                            toAdd = new Card(c, pos, 11);
                            cardList[14][14] = toAdd;                             
                            
                            c = ColorEnum.YELLOW;
                            pos = new Position(14,15);
                            toAdd = new Card(c, pos, 12);
                            cardList[14][15] = toAdd;                                 
       
                            
                            c = ColorEnum.YELLOW;
                            pos = new Position(15,12);
                            toAdd = new Card(c, pos, 13);
                            cardList[15][12] = toAdd;
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(15,13);
                            toAdd = new Card(c, pos, 14);
                            cardList[15][13] = toAdd;                            

                            c = ColorEnum.RED;
                            pos = new Position(15,14);
                            toAdd = new Card(c, pos, 15);
                            cardList[15][14] = toAdd;                             

                            c = ColorEnum.RED;
                            pos = new Position(15,15);
                            toAdd = new Card(c, pos, 16);
                            cardList[15][15] = toAdd;                                             
                 */                

                /* Case [C] 
                            c = ColorEnum.GREEN;                //1
                            pos = new Position(12,12);
                            toAdd = new Card(c, pos, 1);
                            cardList[12][12] = toAdd;
                            
                            c = ColorEnum.GREEN;
                            pos = new Position(12,13);
                            toAdd = new Card(c, pos, 2);
                            cardList[12][13] = toAdd;                            

                            c = ColorEnum.YELLOW;
                            pos = new Position(12,14);
                            toAdd = new Card(c, pos, 3);
                            cardList[12][14] = toAdd;       

                            c = ColorEnum.BLUE;
                            pos = new Position(12,15);
                            toAdd = new Card(c, pos, 4);
                            cardList[12][15] = toAdd;                                                         
                            
                            
                            
                                
                            
                            
                            c = ColorEnum.BLUE;                 //5
                            pos = new Position(13,12);
                            toAdd = new Card(c, pos, 5);
                            cardList[13][12] = toAdd;
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(13,13);
                            toAdd = new Card(c, pos, 6);
                            cardList[13][13] = toAdd;                            

                            c = ColorEnum.GREEN;
                            pos = new Position(13,14);
                            toAdd = new Card(c, pos, 7);
                            cardList[13][14] = toAdd;                             

                            c = ColorEnum.YELLOW;
                            pos = new Position(13,15);
                            toAdd = new Card(c, pos, 8);
                            cardList[13][15] = toAdd;                               
                            
                            
                            
                            
                            


                            c = ColorEnum.GREEN;                 //9
                            pos = new Position(14,12);
                            toAdd = new Card(c, pos, 9);
                            cardList[14][12] = toAdd;

                            c = ColorEnum.YELLOW;                            
                            pos = new Position(14,13);
                            toAdd = new Card(c, pos, 10);
                            cardList[14][13] = toAdd;                            

                            c = ColorEnum.RED;
                            pos = new Position(14,14);
                            toAdd = new Card(c, pos, 11);
                            cardList[14][14] = toAdd;                             
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(14,15);
                            toAdd = new Card(c, pos, 12);
                            cardList[14][15] = toAdd;                                 
                            
                            
                            
       
                            
                            c = ColorEnum.RED;               //12
                            pos = new Position(15,12);
                            toAdd = new Card(c, pos, 13);
                            cardList[15][12] = toAdd;
                            
                            c = ColorEnum.RED;
                            pos = new Position(15,13);
                            toAdd = new Card(c, pos, 14);
                            cardList[15][13] = toAdd;                            

                            c = ColorEnum.RED;
                            pos = new Position(15,14);
                            toAdd = new Card(c, pos, 15);
                            cardList[15][14] = toAdd;                             

                            c = ColorEnum.YELLOW;
                            pos = new Position(15,15);
                            toAdd = new Card(c, pos, 16);
                            cardList[15][15] = toAdd;                                             
                */                                
                
                /* Case [D] 
                            c = ColorEnum.GREEN;
                            pos = new Position(12,12);
                            toAdd = new Card(c, pos, 1);
                            cardList[12][12] = toAdd;
                            
                            c = ColorEnum.YELLOW;
                            pos = new Position(12,13);
                            toAdd = new Card(c, pos, 2);
                            cardList[12][13] = toAdd;                            

                            c = ColorEnum.BLUE;
                            pos = new Position(12,14);
                            toAdd = new Card(c, pos, 3);
                            cardList[12][14] = toAdd;                             

                            c = ColorEnum.BLUE;
                            pos = new Position(12,15);
                            toAdd = new Card(c, pos, 4);
                            cardList[12][15] = toAdd;                                                         
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(13,12);
                            toAdd = new Card(c, pos, 5);
                            cardList[13][12] = toAdd;
                            
                            c = ColorEnum.RED;
                            pos = new Position(13,13);
                            toAdd = new Card(c, pos, 6);
                            cardList[13][13] = toAdd;                            

                            c = ColorEnum.YELLOW;
                            pos = new Position(13,14);
                            toAdd = new Card(c, pos, 7);
                            cardList[13][14] = toAdd;                             

                            c = ColorEnum.GREEN;
                            pos = new Position(13,15);
                            toAdd = new Card(c, pos, 8);
                            cardList[13][15] = toAdd;                               


                            c = ColorEnum.RED;
                            pos = new Position(14,12);
                            toAdd = new Card(c, pos, 9);
                            cardList[14][12] = toAdd;

                            c = ColorEnum.GREEN;                            
                            pos = new Position(14,13);
                            toAdd = new Card(c, pos, 10);
                            cardList[14][13] = toAdd;                            

                            c = ColorEnum.YELLOW;
                            pos = new Position(14,14);
                            toAdd = new Card(c, pos, 11);
                            cardList[14][14] = toAdd;                             
                            
                            c = ColorEnum.RED;
                            pos = new Position(14,15);
                            toAdd = new Card(c, pos, 12);
                            cardList[14][15] = toAdd;                                 
       
                            
                            c = ColorEnum.YELLOW;
                            pos = new Position(15,12);
                            toAdd = new Card(c, pos, 13);
                            cardList[15][12] = toAdd;
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(15,13);
                            toAdd = new Card(c, pos, 14);
                            cardList[15][13] = toAdd;                            

                            c = ColorEnum.RED;
                            pos = new Position(15,14);
                            toAdd = new Card(c, pos, 15);
                            cardList[15][14] = toAdd;                             

                            c = ColorEnum.GREEN;
                            pos = new Position(15,15);
                            toAdd = new Card(c, pos, 16);
                            cardList[15][15] = toAdd;                                             
                 */                                                
                
                
                /* Case [E] 
                            c = ColorEnum.GREEN;
                            pos = new Position(12,12);
                            toAdd = new Card(c, pos, 1);
                            cardList[12][12] = toAdd;
                            
                            c = ColorEnum.GREEN;
                            pos = new Position(12,13);
                            toAdd = new Card(c, pos, 2);
                            cardList[12][13] = toAdd;                            

                            c = ColorEnum.GREEN;
                            pos = new Position(12,14);
                            toAdd = new Card(c, pos, 3);
                            cardList[12][14] = toAdd;                             

                            c = ColorEnum.BLUE;     //4
                            pos = new Position(12,15);
                            toAdd = new Card(c, pos, 4);
                            cardList[12][15] = toAdd;                                                         
                            
                            c = ColorEnum.GREEN;
                            pos = new Position(13,12);
                            toAdd = new Card(c, pos, 5);
                            cardList[13][12] = toAdd;
                            
                            c = ColorEnum.BLUE;
                            pos = new Position(13,13);
                            toAdd = new Card(c, pos, 6);
                            cardList[13][13] = toAdd;                            

                            c = ColorEnum.BLUE;
                            pos = new Position(13,14);
                            toAdd = new Card(c, pos, 7);
                            cardList[13][14] = toAdd;                             

                            c = ColorEnum.YELLOW;   //8
                            pos = new Position(13,15);
                            toAdd = new Card(c, pos, 8);
                            cardList[13][15] = toAdd;                               


                            c = ColorEnum.RED;
                            pos = new Position(14,12);
                            toAdd = new Card(c, pos, 9);
                            cardList[14][12] = toAdd;

                            c = ColorEnum.YELLOW;                            
                            pos = new Position(14,13);
                            toAdd = new Card(c, pos, 10);
                            cardList[14][13] = toAdd;                            

                            c = ColorEnum.YELLOW;
                            pos = new Position(14,14);
                            toAdd = new Card(c, pos, 11);
                            cardList[14][14] = toAdd;                             
                            
                            c = ColorEnum.RED;          //12
                            pos = new Position(14,15);
                            toAdd = new Card(c, pos, 12);
                            cardList[14][15] = toAdd;                                 
       
                            
                            c = ColorEnum.YELLOW;
                            pos = new Position(15,12);
                            toAdd = new Card(c, pos, 13);
                            cardList[15][12] = toAdd;
                            
                            c = ColorEnum.RED;
                            pos = new Position(15,13);
                            toAdd = new Card(c, pos, 14);
                            cardList[15][13] = toAdd;                            

                            c = ColorEnum.RED;
                            pos = new Position(15,14);
                            toAdd = new Card(c, pos, 15);
                            cardList[15][14] = toAdd;                             

                            c = ColorEnum.BLUE;
                            pos = new Position(15,15);
                            toAdd = new Card(c, pos, 16);
                            cardList[15][15] = toAdd;                                             
                 */                                                                
                
                
                
		setUpCardsByNum();
	}

	public void printCardsByNum() {
		for (Card c : cardsByNum) {
			System.out.print(c.getPos().toString() + " ");
		}
		System.out.println("");
	}

	public ArrayList<Card> getCardsByNum() {
		return cardsByNum;
	}

	public Board(Player p1, Player p2) {
		player1 = p1;
		player2 = p2;
		cardList = new Card[LENGTH][LENGTH];
		for (int i = 0; i < LENGTH; i++) {
			for (int j = 0; j < LENGTH; j++) {
				cardList[i][j] = null;
			}
		}
		setUpCards();
		hintDeck = new Hints();
	}

	public void setCardList(Card[][] c) {
		cardList = c;
	}

	public Card[][] getCardList() {
		return cardList;
	}

	public Card getCard(Position pos) {
		if (pos.getX() < 0 || pos.getX() >= LENGTH || pos.getY() < 0 || pos.getY() >= LENGTH)
			return null;
		return cardList[pos.getX()][pos.getY()];
	}

	public Player getPlayer1() {
		return player1;
	}

	public Player getPlayer2() {
		return player2;
	}
	
	public void setPlayer1(Player p1) {
		player1 = p1;
	}
	
	public void setPlayer2(Player p2) {
		player2 = p2;
	}

	// test destination position (if it'll have adjacent cards or not)
	public int adjacent(Card c, Position pos) {
		int numberAdjacent = 0;
		if (pos.getX() - 1 >= 0 && cardList[pos.getX() - 1][pos.getY()] != null
				&& !(cardList[pos.getX() - 1][pos.getY()].equals(c)))
			numberAdjacent++;
		if (pos.getX() + 1 < LENGTH && cardList[pos.getX() + 1][pos.getY()] != null
				&& !(cardList[pos.getX() + 1][pos.getY()].equals(c)))
			numberAdjacent++;
		if (pos.getY() + 1 >= 0 && cardList[pos.getX()][pos.getY() + 1] != null
				&& !(cardList[pos.getX()][pos.getY() + 1].equals(c)))
			numberAdjacent++;
		if (pos.getY() - 1 < LENGTH && cardList[pos.getX()][pos.getY() - 1] != null
				&& !(cardList[pos.getX()][pos.getY() - 1].equals(c)))
			numberAdjacent++;
		return numberAdjacent;
	}

	// test if adjacents cards will be alone or not
	public boolean breakAdjacent(Card c, Position pos) {
		Card cardAdjacent = null;
		Position cardPosition = c.getPos();
		Position left = new Position(cardPosition.getX() - 1, cardPosition.getY());
		Card l = getCard(left);
		Position right = new Position(cardPosition.getX() + 1, cardPosition.getY());
		Card r = getCard(right);
		Position up = new Position(cardPosition.getX(), cardPosition.getY() - 1);
		Card u = getCard(up);
		Position down = new Position(cardPosition.getX(), cardPosition.getY() + 1);
		Card d = getCard(down);

		if (l != null && cardPosition.getX() - 1 >= 0 && adjacent(l, left) == 1)
			return true;
		if (r != null && cardPosition.getX() + 1 < LENGTH && adjacent(r, right) == 1)
			return true;
		if (u != null && cardPosition.getY() - 1 >= 0 && adjacent(u, up) == 1)
			return true;
		if (d != null && cardPosition.getY() + 1 < LENGTH && adjacent(d, down) == 1)
			return true;
		return false;
	}

	public Card show(Position pos) {
		Card c = getCard(pos);
		if (c == null) {
			System.out.println("No Card here.");
		}
		return c;
	}

	private boolean checkAllEtiquettes(LinkedHashMap<Integer, TreeSet<Integer>> equivalentList, int etiquettes) {
		if (etiquettes == 1)
			return true;
		for (Iterator<Integer> ite = equivalentList.keySet().iterator(); ite.hasNext();) {
			TreeSet<Integer> equivalent = new TreeSet<>();
			Integer current = ite.next();
			equivalent.addAll(equivalentList.get(current));
			for (Iterator<Integer> ite2 = equivalentList.keySet().iterator(); ite2.hasNext();) {
				Integer key = ite2.next();
				if (equivalent.contains(key)) {
					equivalent.addAll(equivalentList.get(key));
				} else {
					for (Iterator<Integer> ite3 = equivalentList.get(key).iterator(); ite3.hasNext();) {
						Integer value = ite3.next();
						if (equivalent.contains(value)) {
							equivalent.addAll(equivalentList.get(key));
						}
					}
				}
			}
			if (equivalent.size() == etiquettes)
				return true;

		}
		return false;
	}

	// go through the board by row firstly, and secondly by column, to see if exists
	// 2 big parts without adjacent
	public boolean checkAround(Card c, Position pos) {
		int etiquette = 0;
		int[][] check = new int[LENGTH][LENGTH];
		for (int i = 0; i < LENGTH; i++)
			for (int j = 0; j < LENGTH; j++)
				check[i][j] = 0;
		LinkedHashMap<Integer, TreeSet<Integer>> equivalentList = new LinkedHashMap<>();
		for (int i = 0; i < LENGTH; i++) {
			for (int j = 0; j < LENGTH; j++) {
				if ((cardList[i][j] != null || (i == pos.getX() && j == pos.getY())) // pos to go
						&& !(cardList[i][j] != null && cardList[i][j].equals(c))) { // we don't want the last Position
																					// of the Card
					int temp1 = 0;
					int temp2 = 0;
					int temp3 = 0;
					int temp4 = 0;
					int numDifEtiq = 0;
					// Counting the amount of colored neighbor
					if (i - 1 >= 0 && check[i - 1][j] != 0) {
						temp1 = check[i - 1][j];
						numDifEtiq++;
					}
					if (i + 1 < LENGTH && check[i + 1][j] != 0) {
						temp2 = check[i + 1][j];
						numDifEtiq++;
					}
					if (j - 1 >= 0 && check[i][j - 1] != 0) {
						temp3 = check[i][j - 1];
						numDifEtiq++;
					}
					if (j + 1 < LENGTH && check[i][j + 1] != 0) {
						temp4 = check[i][j + 1];
						numDifEtiq++;
					}
					// if Many colored
					if (numDifEtiq > 1) {
						int t = Math.max(temp1, Math.max(temp2, Math.max(temp3, temp4))); // Get the max
																							// neighbor
																							// etiquette
						check[i][j] = t;
						if (!equivalentList.containsKey(t)) {
							TreeSet<Integer> toAdd = new TreeSet<Integer>();
							toAdd.add(t);
							equivalentList.put(t, toAdd);
						}
						if (temp1 != 0)
							equivalentList.get(t).add(temp1);
						if (temp2 != 0)
							equivalentList.get(t).add(temp2);
						if (temp3 != 0)
							equivalentList.get(t).add(temp3);
						if (temp4 != 0)
							equivalentList.get(t).add(temp4);
					} else if (numDifEtiq == 1) { // if only one
						check[i][j] = (temp1 != 0) ? temp1 : ((temp2 != 0) ? temp2 : ((temp3 != 0) ? temp3 : temp4));
					} else { // If nothing colored
						etiquette++;
						check[i][j] = etiquette;
					}
				}
			}
		}
		return checkAllEtiquettes(equivalentList, etiquette);
	}

	public boolean move(Card c, Position pos) {
		if (c == null) {
			System.out.println("Impossible Movement");
			return false;
		}
		int numAdjacents = adjacent(c, pos);
		if ((cardList[pos.getX()][pos.getY()] != null) || (numAdjacents == 0)
				|| (breakAdjacent(c, pos) && numAdjacents <= 1)) {
			System.out.println("Impossible Movement");
			return false;
		} else {
			if (c.getHint() != null) {
				System.out.println("This card is hinted so it can't be moved.");
				return false;
			}
			if (!checkAround(c, pos)) {
				System.out.println("Impossible Movement");
				return false;
			}
			cardList[pos.getX()][pos.getY()] = c;
			Position before = c.getPos();
			cardList[before.getX()][before.getY()] = null;
			c.setPos(pos);
		}
		return true;
	}

	public void havePlayed() {
		p1Turn = !p1Turn;
	}

	public boolean isP1Turn() {
		return p1Turn;
	}

	public static boolean isValidPos(Position pos) {
		if (pos == null)
			return false;
		return pos.getX() >= 0 && pos.getX() < LENGTH && pos.getY() >= 0 && pos.getY() < LENGTH;
	}

	public void setGameOver(boolean b) {
		gameOver = b;
	}

	public int is4SameColorAdjacent(Card current, ArrayList<Card> toCheck) {
		int res = 1;
		Card left = getCard(new Position(current.getPos().getX() - 1, current.getPos().getY()));
		Card right = getCard(new Position(current.getPos().getX() + 1, current.getPos().getY()));
		Card up = getCard(new Position(current.getPos().getX(), current.getPos().getY() - 1));
		Card down = getCard(new Position(current.getPos().getX(), current.getPos().getY() + 1));

		if (left != null && current.getColor().equals(left.getColor()) && !toCheck.contains(left)) {
			toCheck.add(left);
			res += is4SameColorAdjacent(left, toCheck);
		}
		if (right != null && current.getColor().equals(right.getColor()) && !toCheck.contains(right)) {
			toCheck.add(right);
			res += is4SameColorAdjacent(right, toCheck);
		}
		if (up != null && current.getColor().equals(up.getColor()) && !toCheck.contains(up)) {
			toCheck.add(up);
			res += is4SameColorAdjacent(up, toCheck);
		}
		if (down != null && current.getColor().equals(down.getColor()) && !toCheck.contains(down)) {
			toCheck.add(down);
			res += is4SameColorAdjacent(down, toCheck);
		}
		return res;
	}

	public void endTheGame() {
		gameOver = true;
		boolean check = true;
		for (int i = 0; i < LENGTH; i++) {
			for (int j = 0; j < LENGTH; j++) {
				Card current = getCard(new Position(i, j));
				if (current != null) {
					ArrayList<Card> toCheck = new ArrayList<>();
					toCheck.add(current);
					boolean is4Adjacent = (is4SameColorAdjacent(current, toCheck) == 4);
					check = check && is4Adjacent;
				}
			}
		}
		success = check;
	}
        
        
        
	public void endTheGame2() {
		//gameOver = true;
		boolean check = true;
		for (int i = 0; i < LENGTH; i++) {
			for (int j = 0; j < LENGTH; j++) {
				Card current = getCard(new Position(i, j));
				if (current != null) {
					ArrayList<Card> toCheck = new ArrayList<>();
					toCheck.add(current);
					boolean is4Adjacent = (is4SameColorAdjacent(current, toCheck) == 4);
					check = check && is4Adjacent;
				}
			}
		}
		success = check;
	}


        

	public boolean isGameOver() {
		return gameOver;
	}

	public boolean isSuccess() {
		return success;
	}

	public ArrayList<HintCard> getAllHintViewed() {
		return hintDeck.getAllHints(true);
	}

	public ArrayList<HintCard> getAllHints() {
		return hintDeck.getAllHints(false);
	}

	public boolean haveHintToPlay() {
		return hintDeck.haveHintToPlay();
	}

	public Player getCurrentPlayer() {
		return isP1Turn() ? player1 : player2;
	}

	public boolean noMoreHintToSee() {
		return hintDeck.noMoreHintToSee();
	}

	public HintCard getHintViewed(int num) {
		return hintDeck.getThisViewedHint(num);
	}

	public boolean putHintHere(HintCard h, Position c) {
		boolean res = getCard(c).setHintCard(h);
		if (res)
			h.setPlayed();
		return res;
	}

	public HintCard showHint() {
		int random;
		ArrayList<HintCard> list = null;
		HintCard c = null;
		if (hintDeck.noMoreHintToSee())
			return null;
		list = hintDeck.getNoViewedHints();
		random = rand.nextInt(list.size());
		c = list.get(random);
		if (c != null) {
			c.setVisible();
		}
		return c;
	}
	
	public Card getTheCardFromNum (int num) {
		Card c = cardsByNum.get(num-1);
		return c;
	}

}
