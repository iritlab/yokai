package gameAndRules;

public class Human extends Player {

	public Human (int num) {
		super(num);
	}
}
