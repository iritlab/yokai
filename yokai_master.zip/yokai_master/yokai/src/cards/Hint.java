package cards;

public enum Hint {
	PRI, DUO, TRI; 
}
