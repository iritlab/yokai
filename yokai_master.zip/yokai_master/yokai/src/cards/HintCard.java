package cards;

import gameAndRules.Player;

public abstract class HintCard implements Comparable {
	public final Hint type;
	protected boolean visible = false;
	protected boolean played = false;
	protected int numOfTheCard = 0;

	protected HintCard(Hint h, int numOfTheCard) {
		type = h;
		this.numOfTheCard = numOfTheCard;
	}

	public Hint getType() {
		return type;
	}
	
	public int getNumOfTheCard () {
		return numOfTheCard;
	}
	
	public void setVisible () {
		visible = true;
	}
	
	public void setPlayed () {
		played = true;
	}
	public boolean getVisible () {
		return visible;
	}
	
	public boolean getPlayed () {
		return played;
	}
	
	public int compareTo (Object o) {
		if (!(o instanceof HintCard))
			return -1;
		
		if (visible == ((HintCard)o).getVisible()) {
			if (played && !((HintCard)o).getPlayed()){
				return 1;
			}
			else if (!played && ((HintCard)o).getPlayed()){
				return -1;
			}
			else {
				return 0;
			}
		}
		if (!visible && ((HintCard)o).getVisible()) {
			return -1;
		}
		return 1;
	}

	public boolean equals(Object o) {
		if (!(o instanceof HintCard))
			return false;
		HintCard h = (HintCard) o;
		return type.equals(h.getType());
	}
	
	public String toString () {
		return type.toString()+"Hint ";
	}
}
