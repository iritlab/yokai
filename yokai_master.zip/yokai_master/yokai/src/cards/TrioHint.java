package cards;

import gameAndRules.Player;

public class TrioHint extends HintCard {

	private ColorEnum[] colors = new ColorEnum[3];

	public TrioHint(ColorEnum[] c, int numOfTheCard) {
		super(Hint.TRI, numOfTheCard);
		colors = c;
	}

	public ColorEnum[] getColors() {
		return colors;
	}

	public boolean equals(Object o) {
		if (!super.equals(o) || !(o instanceof TrioHint))
			return false;
		TrioHint h = (TrioHint) o;
		return colors.equals(h.getColors());
	}
	
	public String toString () {
		String res = super.toString();
		res += " couleurs : " + colors[0].toString()+ ", "+colors[1].toString()+ ", "+colors[2].toString();
		return res;
	}
	public int compareTo(Object o) {
		int res = super.compareTo(o);
		if (res != 0) return res;
		ColorEnum[] objectColors = ((TrioHint)o).getColors();
		boolean sameColors = true;
		for (ColorEnum c : objectColors) {
			boolean currentColor = false;
			for (ColorEnum c2 : colors) {
				if (c == c2) currentColor = true;
			}
			sameColors = sameColors && currentColor;
		}
		return (sameColors)?0:-1;
	}
}