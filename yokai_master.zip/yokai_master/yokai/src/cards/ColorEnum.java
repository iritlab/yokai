package cards;

public enum ColorEnum {
	RED, GREEN, YELLOW, BLUE;
	
	public static ColorEnum valueOf (int i) {
		switch (i) {
                        // JFD: comentado solo para generar GREEN Hints
			//case 0 : return RED;
                        case 0 : return RED;
			case 1 : return GREEN;
			case 2 : return YELLOW;
			default : return BLUE;
		}
	}
	
	
	public String toString (boolean minus) {
		switch (this) {
			case RED : return (minus)?"r":"R";
			case GREEN : return (minus)?"b":"G";
			case YELLOW : return (minus)?"y":"Y";
			default : return (minus)?"b":"B";
		}
	}
}
