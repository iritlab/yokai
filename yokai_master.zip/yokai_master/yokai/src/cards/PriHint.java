package cards;

import gameAndRules.Player;

public class PriHint extends HintCard {
	
	private ColorEnum c = null;
	
	public PriHint(ColorEnum c,int numOfTheCard) {
		super(Hint.PRI,numOfTheCard);
		this.c = c;
	}

	public ColorEnum getColor () {
		return c;
	}
	
	public boolean equals (Object o) {
		if (!super.equals(o) || ! (o instanceof PriHint)) return false;
		PriHint h = (PriHint) o;
		return c.equals(h.getColor());
	}
	
	public String toString () {
		return super.toString()+" couleur : " + c.toString();
	}

	public int compareTo(Object o) {
		int res = super.compareTo(o);
		if (res != 0) return res;
		return (c.equals(((PriHint)o).getColor()))?0:-1;
	}
}
