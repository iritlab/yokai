package cards;

import java.util.SortedSet;

import gameAndRules.Player;

public class DuoHint extends HintCard {

	private ColorEnum[] colors = new ColorEnum[2];

	public DuoHint(ColorEnum[] c, int numOfTheCard) {
		super(Hint.DUO, numOfTheCard);
		colors = c;
	}

	public ColorEnum[] getColors() {
		return colors;
	}

	public boolean equals(Object o) {
		if (!super.equals(o) || !(o instanceof DuoHint))
			return false;
		DuoHint h = (DuoHint) o;
		return colors.equals(h.getColors());
	}
	
	public String toString () {
		String res = super.toString();
		res += " couleurs : " + colors[0].toString()+ ", "+colors[1].toString();
		return res;
	}
	
	public int compareTo(Object o) {
		int res = super.compareTo(o);
		if (res != 0) return res;
		ColorEnum[] objectColors = ((DuoHint)o).getColors();
		boolean sameColors = true;
		for (ColorEnum c : objectColors) {
			boolean currentColor = false;
			for (ColorEnum c2 : colors) {
				if (c == c2) currentColor = true;
			}
			sameColors = sameColors && currentColor;
		}
		return (sameColors)?0:-1;
	}
	
}
