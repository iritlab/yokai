package cards;

import gameAndRules.Board;
import gameAndRules.Position;

public class Card implements Comparable {

	private HintCard hintCard = null; // Indice position sur cette case
	private ColorEnum color = null; // couleur de la carte
	private Position pos = null; // position carte
	private int numCard = 0;

	public Card(ColorEnum c, Position pos, int num) {
		color = c;
		this.pos = pos;
		numCard = num;
	}

	public ColorEnum getColor() {
		return color;
	}
	
	public void setNumCard (int num) {
		numCard = num;
	}
	public int getNumCard () {
		return numCard;
	}
	
	public void setPos (Position pos) {
		this.pos = pos;
	}
	
	public Position getPos() {
		return pos;
	}

	public HintCard getHint() {
		return hintCard;
	}
	
	public boolean isHinted () {
		return (hintCard != null);
	}

	public boolean setHintCard(HintCard c) {
		if (hintCard != null) {
			System.out.println("Already Hinted");
			return false;
		}
		if (c == null) {
			System.out.println("HintCard is null");
			return false;
		}
		hintCard = c;
		return true;
	}

	@Override
	public int compareTo(Object o) {
		if (!(o instanceof Card)) return -1;
		int x1 = pos.getX();
		int y1 = pos.getY();
		int x2 = ((Card) o).getPos().getX();
		int y2 = ((Card) o).getPos().getY();
		return ((Board.LENGTH-1)*x1+y1) - ((Board.LENGTH-1)*x2+y2);
	}
	
	public boolean equals (Object o) {
		if (!(o instanceof Card)) return false;
		int x1 = pos.getX();
		int y1 = pos.getY();
		int x2 = ((Card) o).getPos().getX();
		int y2 = ((Card) o).getPos().getY();
		return x1 == x2 && y1 == y2;
	}
	
	public String toString() {
		return ""+color.toString();
	}
}
