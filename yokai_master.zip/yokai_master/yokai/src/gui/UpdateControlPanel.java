package gui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import javax.swing.JTextArea;

import cards.*;
import gameAndRules.*;
import translator.*;

public class UpdateControlPanel implements Runnable{
	
	private GameBoard gBoard = null;
	private JTextArea areaToWrite = null;
	private ArrayList<ArrayList<Object>> waitingMachineActions = null;
	
	public UpdateControlPanel(GameBoard b, JTextArea toWrite) {
		gBoard = b;
		areaToWrite = toWrite;
		waitingMachineActions = new ArrayList<>();
	}
	
	public ArrayList<Object> getNextAction (int turn, int action) {
		ArrayList<Object> toPop = null;
		int act = (action > 4)?4:action;
		act = 4*turn+act;
		for (Iterator<ArrayList<Object>> ite = waitingMachineActions.iterator(); ite.hasNext();) {
			ArrayList<Object> current = ite.next();
			if ((int)current.get(current.size()-1) == act+1) {
				toPop = current;
				ite.remove();
				//Translator.makeThisChecked(act+1);
				//Translator.callThisModule(Translator.berv, Translator.argBerv);
				return toPop;
			}
		}
		return toPop;
	}
	
	public boolean haveAnAction (int turn, int action) {
		for (ArrayList<Object> list : waitingMachineActions) {
			if ((int)list.get(list.size()-1) == (turn *4 + action+1)) {
				return true;
			}
		}
		return false;
	}
	
	private boolean machineActionsContains (ArrayList<Object> thisAction) {
		
		for (ArrayList<Object> current : waitingMachineActions) {
			if (current.toString().equals(thisAction.toString()))
				return true;
		}
		return false;
	}
	
	private void translateAndAdd(String currentAction) {
		if (currentAction.length() < 5)
			return;
		String[] split = currentAction.split(":");
		String action;
		if (split[0].equals("h")) {
			return;
		}
		String[] importantPart = split[1].split("_");
		ArrayList<Object> toAdd = new ArrayList<>();
		SetOfActions kindOfAction = SetOfActions.valueOf(importantPart[0], true);
		toAdd.add(kindOfAction);
		toAdd.add(Integer.valueOf(importantPart[1]));
		if (kindOfAction == SetOfActions.POS) {
			Position pos = new Position(Integer.valueOf(importantPart[3]), Integer.valueOf(importantPart[4]));
			toAdd.add(pos);
			action = importantPart[5].split("t")[1];
		} else if (kindOfAction == SetOfActions.MARK) {
			toAdd.add(Integer.valueOf(importantPart[2]));
			action = importantPart[3].split("t")[1];
		}
		else if (kindOfAction == SetOfActions.COL){
			action = importantPart[3].split("t")[1];
		}
		else {
			action = importantPart[2].split("t")[1];
		}
		toAdd.add(Integer.parseInt(action));
		if (!machineActionsContains(toAdd)) {
			waitingMachineActions.add(toAdd);
		}
	}
	
	private void actualise(){
		ArrayList<String> toPrint = Translator.readMachineActions();
		Board b = gBoard.getGame();
		StringBuilder res = new StringBuilder();
		for (String action : toPrint) {
			res.append(action+"\n");
			translateAndAdd(action);
		}
		
		areaToWrite.setText(res.toString());
		
		try {
			Thread.sleep(1000);
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("Sleep error.");
		}
		run();
	}
	
	@Override
	public void run() {
		actualise();
	}
	
	
	
}
