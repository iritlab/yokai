package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

import gameAndRules.*;
import translator.Translator;
public class GameWindow extends JFrame  {
	
	/** The default width for the checkers window. */
	public static final int DEFAULT_WIDTH = 600;
	
	/** The default height for the checkers window. */
	public static final int DEFAULT_HEIGHT = 600;
	
	/** The default title for the checkers window. */
	public static final String DEFAULT_TITLE = "Yokai Game";
	
	public static boolean HIDE_COLOR = true;
	
	/** The checker board component playing the updatable game. */
	private GameBoard board;
	
	private Board game;
	
	private OptionPanel opts;
	
	
	
	public GameWindow(Board b) {
		// Setup the window
		super(DEFAULT_TITLE);
		super.setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
		super.setLocationByPlatform(true);
		
		game = b;
		// Setup the components
		JPanel layout = new JPanel(new BorderLayout());
		board = new GameBoard(this, game);
		opts = new OptionPanel(this);
		
		layout.add(board, BorderLayout.CENTER);
		layout.add(opts, BorderLayout.SOUTH);
		this.add(layout);
	}
	
	public GameBoard getBoard() {
		return board;
	}
	
	public OptionPanel getOpts() {
		return opts;
	}
	
	public void restart() {
		//Translator.deleteDirectory(Translator.path);
		board.setNewGame();
		if (!GameWindow.HIDE_COLOR) hideColor();
	}
	
	public boolean isGameOver() {
		return game.isGameOver();
	}
	public void endTheGame() {
		game.endTheGame();
		board.update();
	}

       
	public void endTheGameLive() {
		game.endTheGame2();
                if (game.success == true) {
                    game.gameOver = true;
                    board.update();
                    
                    //System.exit(1);
                    /*
				hideColorBtn.setVisible(false);
				endBtn.setVisible(false);
				if (GameWindow.HIDE_COLOR)
					window.hideColor();
				window.endTheGame();
                    */                    
                } else {
                    System.out.println("Still we dont win the Game !!! ");
                }
                    
		//board.update();
	}        

        
    /* JFD */
	public void hideColor() {
	            if (GameWindow.HIDE_COLOR) {;
	            	GameWindow.HIDE_COLOR = false;
	                opts.hideColorBtn.setText("Hide Color");
	            } else {
	            	GameWindow.HIDE_COLOR = true;
	                opts.hideColorBtn.setText("Show Color");
	            }
	            repaint();
	}

	public void actHint() {
		//board.actHint();
		board.repaint();
	}
	
	public void setGameState(String state) {
		//board.getGame().setGameState(state);
	}
	
	public void setPlayer1(Player p1) {
		board.setPlayer1(p1);
//		board.update();
	}
	
	public void setPlayer2(Player p2) {
		board.setPlayer2(p2);
	}
}
