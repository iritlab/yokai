package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.WindowConstants;

import gameAndRules.Board;
import translator.Translator;

public class ControlPannel extends javax.swing.JFrame {
	
	
	
    // Variables declaration - do not modify                     
    private JButton exportButton;
    private JButton cleanButton;
    private JLabel text;
    private JScrollPane jScrollPanel;
    private JTextArea computerActions;
    private JTextField fileToExport;
    // End of variables declaration         
    
    private GameWindow window;
    
    private UpdateControlPanel ucp = null;
    
    private Thread updater = null;
    
    /**
     * Creates new form PrincipaleFrame
     */
    public ControlPannel(GameWindow win) {
        initComponents();
        window = win;
        ucp = new UpdateControlPanel(window.getBoard(), computerActions);
        updater = new Thread (ucp);
        updater.start();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        computerActions = new JTextArea(5, 20);
        jScrollPanel = new JScrollPane(computerActions);
        exportButton = new JButton();
        fileToExport = new JTextField();
        text = new JLabel();
        cleanButton = new JButton();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setTitle("ControlPanel");
        setAutoRequestFocus(false);
        setBackground(new Color(255, 255, 255));
        setBounds(new Rectangle(0, 0, 300, 400));
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        setMaximumSize(new Dimension(300, 400));
        setMinimumSize(new Dimension(300, 400));
        setResizable(false);

        jScrollPanel.setViewportView(computerActions);
        jScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
        computerActions.setEditable(false);
        computerActions.setColumns(19);
        computerActions.setRows(5);

        exportButton.setText("Export the Current State");
        exportButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
            	exportButtonActionPerformed(evt);
            }
        });
        
        cleanButton.setText("clean logs");
        cleanButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                cleanLogsActionPerformed(evt);
            }
        });
        
        fileToExport.setText("name of the file.txt");
        fileToExport.setAutoscrolls(false);
        fileToExport.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
            	fileToExportActionPerformed(evt);
            }
        });

        text.setText("Actions of the Computer");

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(text, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jScrollPanel, GroupLayout.PREFERRED_SIZE, 225, GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(fileToExport, GroupLayout.Alignment.TRAILING)
                            .addComponent(exportButton, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cleanButton)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPanel, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115)
                .addComponent(text)
                .addGap(5, 5, 5)
                .addComponent(cleanButton)
                .addGap(18, 18, 18)
                .addComponent(fileToExport)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(exportButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>            
    
    public UpdateControlPanel getUCP () {
    	return ucp;
    }

    private void exportButtonActionPerformed(ActionEvent evt) {                                         
        String name = fileToExport.getText();
        String [] splitted = name.split("\\.");
        boolean existTxt = false;
        for (String token : splitted) {
        	if (token.equals("txt")) {
        		existTxt = true;
        	}
        }
        Board board = window.getBoard().getGame();
        int turn = window.getBoard().getTurn();
        int action = window.getBoard().getNumAction();
        Translator.createCurrentGameState(board, turn, action, name + ((existTxt)?"":".txt"), true, true);
    }                                        

    private void fileToExportActionPerformed(ActionEvent evt) {                                            
        String text = fileToExport.getText();
        String [] splitted = text.split("\\.");
        boolean existTxt = false;
        for (String token : splitted) {
        	if (token.equals("txt")) {
        		existTxt = true;
        	}
        }
        fileToExport.setText(text+((existTxt)?"":".txt"));
    }      
    
    private void cleanLogsActionPerformed(ActionEvent evt) {                                         
        Translator.deleteDirectory(Translator.debugPath);
    }       
    
    
}

