package gui;

import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.Thread.State;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.Timer;

import gameAndRules.*;
import translator.*;
import cards.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GameBoard extends JButton {

	private static final int LENGTH = 28;

	private static final int POS_HINT = LENGTH + 2;

	private static final int NUM_HINT = 7;

	private static final long serialVersionUID = -6014690893709316364L;

	/** The amount of milliseconds before a computer player takes a move. */
	private static final int TIMER_DELAY = 1000;

	/**
	 * The number of pixels of padding between this component's border and the
	 * actual checker board that is drawn.
	 */
	private static final int PADDING = 16;

	/** The game of checkers that is being played on this component. */
	private Board game;

	/** The window containing this checker board UI component. */
	private GameWindow window;

	/** The player in control of the black checkers. */
	private Player player1;

	/** The player in control of the white checkers. */
	private Player player2;

	/** The last point that the current player selected on the checker board. */
	private Point selected;

	/**
	 * The flag to determine the colour of the selected tile. If the selection is
	 * valid, a green colour is used to highlight the tile. Otherwise, a red colour
	 * is used.
	 */
	private boolean selectionValid;
        private boolean ActionPos = false;

	/** The colour of the light tiles (by default, this is white). */
	private Color lightTile;

	/** The colour of the dark tiles (by default, this is black). */
	private Color darkTile;

	private Color hintTile;

	/** The timer to control how fast a computer player makes a move. */
	private Timer timer;

	/**
	 * action between 0 and 5 include, corresponds with what kind of action the
	 * player need to do
	 */
	private int action = 0;
	private int turn = 0;
	private int turnCheck = 0;

	/** Cards to see for actions 0 and 1 */
	private Card card1 = null;
	private Card card2 = null;

	private Card card1SeenByTheComputer = null;
	private Card card2SeenByTheComputer = null;

	private JButton viewHint;
	private JButton putHint;
	private JButton endTurn;
//	private JButton nextAction;
	private JLabel viewAction;

	private Point hintSelected;

	private Calculations calculations;

	private UpdateControlPanel ucp = null;

	private ComputerPlay executeComputer = null;
	

//	private Thread executeComputer = null;

	public GameBoard(GameWindow window, Board b) {

		// Setup the component
		super.setBorderPainted(false);
		super.setFocusPainted(false);
		super.setContentAreaFilled(false);
		super.setBackground(Color.LIGHT_GRAY);
		this.addActionListener(new ClickListener());

//		nextAction = new JButton("Next Action");
//		nextAction.setFont(new Font("Arial", Font.PLAIN, 8));
		viewHint = new JButton("Activate Hint");
		viewHint.setFont(new Font("Arial", Font.PLAIN, 8));
		endTurn = new JButton("End Turn");
		endTurn.setFont(new Font("Arial", Font.PLAIN, 8));
		putHint = new JButton("Use  Hint");
		putHint.setFont(new Font("Arial", Font.PLAIN, 8));
		viewAction = new JLabel();
		HintButtonsListener bL = new HintButtonsListener();
//		nextAction.addActionListener(bL);
		viewHint.addActionListener(bL);
		endTurn.addActionListener(bL);
		putHint.addActionListener(bL);
		this.add(viewHint);
		this.add(endTurn);
		this.add(putHint);
//		this.add(nextAction);*
		this.add(viewAction);

		this.lightTile = Color.WHITE;
		this.darkTile = Color.LIGHT_GRAY;

		this.window = window;
		game = b;
		player1 = game.getPlayer1();
		player2 = game.getPlayer2();
		Translator.createCurrentGameState(game, 0,0, Translator.iniSetFile, false, true);
	}

	public void update() {
		repaint();
		if (turn >= 14 && !game.isGameOver()) {
			window.getOpts().endTheGame();
			game.endTheGame();
		}
		runPlayer();
	}

	public void hideCards() {
		repaint();
	}

	public void setUCP(UpdateControlPanel ucp) {
		this.ucp = ucp;
	}
	
	public UpdateControlPanel getUCP () {
		return this.ucp;
	}

	public int getTurn() {
		return turn;
	}

	public int getNumAction() {
		int act = action;
		if (action > 4)
			act = 4;
		return act;
	}
	
	private void runPlayer() {
		// Nothing to do
		Player player = getCurrentPlayer();
		if (player == null || !(player instanceof Computer)) {
			return;
		}
		turnCheck = turn;
		System.out.println("C'est au tour de quel player ? "+player.toString());
		System.out.println("De plus, nous sommes a l'action : " + action);
		executeComputer = new ComputerPlay();
	}

	public boolean isGameOver() {
		return game.isGameOver();
	}

	/**
	 * Draws the current checkers game state.
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g);

		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		// Perform calculations

		calculations = new Calculations();
		// Draw checker board shape
		drawShape(g);
		// Draw the Board without cards
		drawBoard(g);
		// Draw well selected;
		drawSelected(g);
		// Draw buttons
		drawButtons(g);
		// Draw all cards
		drawCards(g);
		// Draw all Hints
		drawHintCards(g);
		// Draw the player turn sign
		drawText(g);
		// Draw a game over sign
		drawGameOver(g);
		
		if (turn < turnCheck) {
			turn = turnCheck;
			update();
		}
	}

	private void drawThisHint(Graphics g, HintCard hint, int x, int y, boolean hintBoard) {
		int xPos = 0, yPos = 0;
		int width = 0, height = 0;
		if (hintBoard) {
			xPos = calculations.OFFSET_X + POS_HINT * calculations.BOX_SIZE + 3;
			yPos = calculations.OFFSET_Y + y * calculations.HINT_BOX + 3;
			width = calculations.HINT_BOX - 6;
			height = calculations.HINT_BOX - 6;
		} else {
			xPos = calculations.OFFSET_X + x * calculations.BOX_SIZE + 2;
			yPos = calculations.OFFSET_Y + y * calculations.BOX_SIZE + 2;
			width = calculations.BOX_SIZE - 4;
			height = calculations.BOX_SIZE - 4;
		}
		if (hint instanceof PriHint) {
			ColorEnum c = ((PriHint) hint).getColor();
			g.setColor((c == ColorEnum.RED) ? Color.RED
					: ((c == ColorEnum.GREEN) ? Color.GREEN : ((c == ColorEnum.YELLOW) ? Color.YELLOW : Color.BLUE)));
                                        //: ((c == ColorEnum.RED) ? Color.RED : ((c == ColorEnum.RED) ? Color.RED : Color.RED)));
			g.fillRect(xPos, yPos, width, height);
		} else {
			ColorEnum[] tab = (hint instanceof DuoHint) ? ((DuoHint) hint).getColors() : ((TrioHint) hint).getColors();
			int step = width;
			step /= (hint instanceof DuoHint) ? 2 : 3;
			int i = 0;
			for (ColorEnum c : tab) {
				g.setColor((c == ColorEnum.RED) ? Color.RED
						: ((c == ColorEnum.GREEN) ? Color.GREEN
								: ((c == ColorEnum.YELLOW) ? Color.YELLOW : Color.BLUE)));
				g.fillRect(xPos + i * step, yPos, step + 1, height);
				i++;
			}
		}
	}

	private void drawHintCards(Graphics g) {
		ArrayList<HintCard> listeHintViewed = game.getAllHintViewed();
		// draw HintBoard
		int y = 0;
		if (listeHintViewed.isEmpty())
			return;
		for (HintCard hint : listeHintViewed) {
			drawThisHint(g, hint, 0, y, true);
			y++;
		}
	}

	public void drawThisCard(Graphics g, Card c, int cx, int cy) {
		ColorEnum color = c.getColor();
		Color toPut = (color == ColorEnum.BLUE) ? Color.BLUE
				: (color == ColorEnum.GREEN) ? Color.GREEN : (color == ColorEnum.RED) ? Color.RED : Color.YELLOW;

                if (Main.hm == 1) {
                
                    if (c.equals(card1SeenByTheComputer) || c.equals(card2SeenByTheComputer)) {
                            g.setColor(Color.ORANGE);
                            g.fillOval(cx - 3, cy - 3, calculations.CHECKER_SIZE + 6, calculations.CHECKER_SIZE + 6);
                    }

                    if ((GameWindow.HIDE_COLOR) && !((c.equals(card1) || c.equals(card2)) && action <= 3)) {
                            g.setColor(Color.DARK_GRAY);
                    } else {
                            g.setColor(toPut);
                    }
                    g.fillOval(cx, cy, calculations.CHECKER_SIZE, calculations.CHECKER_SIZE);
                    g.setColor(Color.DARK_GRAY);
                    g.drawOval(cx, cy, calculations.CHECKER_SIZE, calculations.CHECKER_SIZE);
                    
                } else {
                    
                    if (c.equals(card1) || c.equals(card2))  {
                        g.setColor(Color.ORANGE);
                        g.fillOval(cx - 3, cy - 3, calculations.CHECKER_SIZE + 6, calculations.CHECKER_SIZE + 6);  
                        g.setColor(Color.DARK_GRAY);
                    } 
                    
                    
                    
                    if ((GameWindow.HIDE_COLOR) && !((c.equals(card1) || c.equals(card2)) && action <= 3)) {
                            g.setColor(Color.DARK_GRAY);
                    } else {
                            //g.setColor(toPut);
                    }
                    
                    
                    if ((GameWindow.HIDE_COLOR)==false) {
                        g.setColor(toPut);
                    }
                        
                    
                    
                    g.fillOval(cx, cy, calculations.CHECKER_SIZE, calculations.CHECKER_SIZE);
                    g.setColor(Color.DARK_GRAY);
                    g.drawOval(cx, cy, calculations.CHECKER_SIZE, calculations.CHECKER_SIZE);                    
                    
                }
                
                
                
	}

	public void drawBoard(Graphics g) {
		// Draw The Board design
		g.setColor(darkTile);
		for (int x = 0; x < LENGTH; x++) {
			for (int y = (x + 1) % 2; y < LENGTH; y += 2) {
				g.setColor(darkTile);
				g.fillRect(calculations.OFFSET_X + x * calculations.BOX_SIZE,
						calculations.OFFSET_Y + y * calculations.BOX_SIZE, calculations.BOX_SIZE,
						calculations.BOX_SIZE);
			}
		}
		// Draw the Hint Board design
		g.setColor(darkTile);
		for (int y = 0; y < NUM_HINT; y += 2) {
			g.setColor(darkTile);
			g.fillRect(calculations.OFFSET_X + POS_HINT * calculations.BOX_SIZE,
					calculations.OFFSET_Y + y * calculations.HINT_BOX, calculations.HINT_BOX, calculations.HINT_BOX);
		}
	}

	private void drawCards(Graphics g) {

		for (int x = 0; x < LENGTH; x++) {
			int cx = calculations.OFFSET_X + x * calculations.BOX_SIZE + calculations.BOX_PADDING;
			for (int y = 0; y < LENGTH; y++) {
				int cy = calculations.OFFSET_Y + y * calculations.BOX_SIZE + calculations.BOX_PADDING;
				Card c = game.getCard(new Position(y, x));
				if (c == null) {
					continue;
				}
				drawThisCard(g, c, cx, cy);
				if (c.isHinted() && GameWindow.HIDE_COLOR) {
					drawThisHint(g, c.getHint(), x, y, false);
				}
			}
		}
	}

	private void drawSelected(Graphics g) {
		Point p = selected;
		Position pos = (p == null) ? null : new Position(p.x, p.y);
		if (this.game.isValidPos(pos)) {
			g.setColor(Color.CYAN);
			g.fillRect(calculations.OFFSET_X + selected.x * calculations.BOX_SIZE,
					calculations.OFFSET_Y + selected.y * calculations.BOX_SIZE, calculations.BOX_SIZE,
					calculations.BOX_SIZE);
		}
		if (hintSelected != null) {
			g.setColor(Color.CYAN);
			g.fillRect(calculations.OFFSET_X + POS_HINT * calculations.BOX_SIZE,
					calculations.OFFSET_Y + (hintSelected.y - 1) * calculations.HINT_BOX, calculations.HINT_BOX,
					calculations.HINT_BOX);
		}
	}

	private void drawShape(Graphics g) {
		// Draw the board shape
		g.setColor(Color.LIGHT_GRAY);
		g.drawRect(calculations.OFFSET_X - 1, calculations.OFFSET_Y - 1, calculations.BOX_SIZE * LENGTH + 1,
				calculations.BOX_SIZE * LENGTH + 1);
		g.setColor(lightTile);
		g.fillRect(calculations.OFFSET_X, calculations.OFFSET_Y, calculations.BOX_SIZE * LENGTH,
				calculations.BOX_SIZE * LENGTH);
		// Draw the Hint board shape
		g.setColor(Color.LIGHT_GRAY);
		g.drawRect(calculations.OFFSET_X + POS_HINT * calculations.BOX_SIZE - 1, calculations.OFFSET_Y - 1,
				calculations.HINT_BOX + 1, calculations.HINT_BOX * NUM_HINT + 1);
		g.setColor(lightTile);
		g.fillRect(calculations.OFFSET_X + POS_HINT * calculations.BOX_SIZE, calculations.OFFSET_Y,
				calculations.HINT_BOX, calculations.HINT_BOX * NUM_HINT);
	}

	private void drawButtons(Graphics g) {
		int posXHintButton = (((calculations.W - calculations.BOX_SIZE * LENGTH) / 2)
				+ POS_HINT * calculations.BOX_SIZE) - calculations.HINT_BOX + calculations.HINT_BOX / 4;
		int posYHintButton = ((calculations.H - calculations.BOX_SIZE * LENGTH) / 2)
				+ (NUM_HINT + 1) * calculations.HINT_BOX;
		int widthHintHButton = calculations.HINT_BOX * 2 + 1 + calculations.HINT_BOX * 3 / 4;
		int heightHintButton = calculations.HINT_BOX;
//		nextAction.setBounds(posXHintButton, posYHintButton, widthHintHButton, heightHintButton);
		viewHint.setBounds(posXHintButton, posYHintButton, widthHintHButton, heightHintButton);
		putHint.setBounds(posXHintButton, posYHintButton + heightHintButton + 5, widthHintHButton, heightHintButton);
		endTurn.setBounds(posXHintButton, posYHintButton, widthHintHButton, heightHintButton);
		if (getCurrentPlayer() instanceof Computer) {
//			if (action >= 4) {
//				nextAction.setText("End Turn");
//			}
//			else {
//				nextAction.setText("Next Action");
//			}
//			nextAction.setVisible(true);
                        //String[] argTrans = new String[3];  
                        //Translator.callThisModule(4, action, Translator.inference, argTrans);
			endTurn.setVisible(false);
			putHint.setVisible(false);
			viewHint.setVisible(false);
                        //String[] argTrans = new String[3];  
                        //Translator.callThisModule(4, action, Translator.inference, argTrans);                        
		} else {
//			nextAction.setVisible(false);

                        
			endTurn.setVisible((action == 5) ? true : false);
			if (game.haveHintToPlay()) {
				putHint.setVisible((action == 3) ? true : false);
			} else {
				putHint.setVisible(false);
			}
			if (game.noMoreHintToSee()) {
				viewHint.setVisible(false);
			} else {
				viewHint.setVisible((action == 3) ? true : false);
			}
                        
                        //String[] argTrans = new String[3];  
                        //Translator.callThisModule(4, action, Translator.inference, argTrans);                        
                        
                        
		}
	}

	private int calculateScore() {
		int score = 0;
		for (Card c : game.getCardsByNum()) {
			if (c.isHinted()) {
				ColorEnum color = c.getColor();
				if (c.getHint() instanceof PriHint) {
					score += ((PriHint) c.getHint()).getColor().equals(color) ? 1 : -1;
				} else {
					ColorEnum[] tab = (c.getHint() instanceof DuoHint) ? ((DuoHint) c.getHint()).getColors()
							: ((TrioHint) c.getHint()).getColors();
					boolean contains = false;
					for (ColorEnum hintColor : tab) {
						if (hintColor.equals(color))
							contains = true;
					}
					score += contains ? 1 : -1;
				}
			}
		}
		for (HintCard h : game.getAllHints()) {
			if (h.getVisible() && !h.getPlayed())
				score += 2;
			else if (!h.getVisible())
				score += 5;
		}
		return score;
	}

	private void drawText(Graphics g) {
		// Draw the player turn sign
		if (!game.isGameOver()) {
			String msg = game.isP1Turn() ? "Player 1's turn" : "Player 2's turn";
                        
                        int turn = game.isP1Turn() ? 1 : 2;
			int width = g.getFontMetrics().stringWidth(msg);
			Color back = game.isP1Turn() ? Color.BLACK : Color.WHITE;
			Color front = game.isP1Turn() ? Color.WHITE : Color.BLACK;
			g.setColor(back);
			g.fillRect(calculations.W / 2 - width / 2 - 5, calculations.OFFSET_Y + LENGTH * calculations.BOX_SIZE + 2,
					width + 10, 15);
			g.setColor(front);
			g.drawString(msg, calculations.W / 2 - width / 2,
					calculations.OFFSET_Y + LENGTH * calculations.BOX_SIZE + 2 + 11);
                        
                        if(turn == 1) {
                            Main.player = 1;
                        } else {
                            Main.player = 2;
                        }                        
                        
		}

		viewAction.setBounds(calculations.OFFSET_X - 75, 2 * PADDING, 75, 10);
		viewAction.setText("Action nro " + (((action >= 4) ? 4 : action) + 4 * turn));
	}

	private void drawGameOver(Graphics g) {
		if (game.isGameOver()) {
			g.setFont(new Font("Arial", Font.BOLD, 20));
			String msg = game.isSuccess() ? "Well done !" : "Failure, game Over";
			int width = g.getFontMetrics().stringWidth(msg);
			g.setColor(new Color(240, 240, 255));
			g.fillRoundRect(calculations.W / 2 - width / 2 - 5, calculations.OFFSET_Y + calculations.BOX_SIZE * 4 - 16,
					width + 10, 30, 10, 10);
			g.setColor((game.isSuccess() ? Color.GREEN : Color.RED));
			g.drawString(msg, calculations.W / 2 - width / 2, calculations.OFFSET_Y + calculations.BOX_SIZE * 4 + 7);
			if (game.isSuccess()) {
				g.setColor(new Color(240, 240, 255));
				g.fillRoundRect(calculations.W / 2 - width / 2 - 5,
						calculations.OFFSET_Y + calculations.BOX_SIZE * 6 - 16, width + 10, 30, 10, 10);
				String score = "Score : " + calculateScore();
				g.setColor(Color.GREEN);
				g.drawString(score, calculations.W / 2 - width / 2,
						calculations.OFFSET_Y + calculations.BOX_SIZE * 6 + 7);
			}
		}
	}

	public Board getGame() {
		return game;
	}

	public void setNewGame() {
		Player p1 = (player1 instanceof Computer) ? new Computer(1) : new Human(1);
		Player p2 = (player2 instanceof Computer) ? new Computer(2) : new Human(2);
		if (executeComputer != null)
			executeComputer.stop();
		executeComputer = null;
		this.game = new Board(p1, p2);
		action = 0;
		hintSelected = null;
		selected = null;
		card1 = null;
		card2 = null;
		turn = 0;
		turnCheck = 0;
		setPlayer1(p1);
		setPlayer2(p2);
		Translator.createCurrentGameState(game, 0,0, Translator.iniSetFile, false, true);
		update();
	}

	public GameWindow getWindow() {
		return window;
	}

	public void setWindow(GameWindow window) {
		this.window = window;
	}

	public Player getPlayer1() {
		return player1;
	}

	public void setPlayer1(Player player1) {
		this.player1 = (player1 == null) ? new Human(1) : player1;
		game.setPlayer1(player1);
		if (game.isP1Turn() && (player1 instanceof Computer)) {
			this.selected = null;
			hintSelected = null;
			update();
		}
	}

	public Player getPlayer2() {
		return player2;
	}

	public void setPlayer2(Player player2) {
		this.player2 = (player2 == null) ? new Human(2) : player2;
		game.setPlayer2(player2);
		if (!game.isP1Turn() && (player2 instanceof Computer)) {
			this.selected = null;
			hintSelected = null;
			update();
		}
	}

	public Player getCurrentPlayer() {
		return game.isP1Turn() ? player1 : player2;
	}

	public Color getLightTile() {
		return lightTile;
	}

	public void setLightTile(Color lightTile) {
		this.lightTile = (lightTile == null) ? Color.WHITE : lightTile;
	}

	public Color getDarkTile() {
		return darkTile;
	}

	public void setDarkTile(Color darkTile) {
		this.darkTile = (darkTile == null) ? Color.BLACK : darkTile;
	}

	private boolean moveAction(int x, int y) {
		// Determine what square (if any) was selected
		x = (x - calculations.OFFSET_X) / calculations.BOX_SIZE;
		y = (y - calculations.OFFSET_Y) / calculations.BOX_SIZE;
		Position sel = new Position(y, x);
		Point p = selected;
		Position pos = (p == null) ? null : new Position(p.y, p.x);
		if (pos != null) {
			System.out.println("Position selected : (" + pos.getX() + "," + pos.getY() + ")");
			System.out.println("Position toPut : (" + sel.getX() + "," + sel.getY() + ")");
		}
		// Determine if a move should be attempted
		if (Board.isValidPos(sel) && Board.isValidPos(pos)) {
			Card toMove = game.getCard(pos);
			boolean move = game.move(toMove, sel);
			if (move) {
				ArrayList<Object> toWrite = new ArrayList<>();
				toWrite.add(SetOfActions.POS);
				toWrite.add(toMove.getNumCard());
				toWrite.add(sel);
				action++;
				Translator.writeActionPerformed(game, turn, (action >= 4) ? 4 : action, toWrite);
				Translator.createCurrentGameState(game, turn, (action >= 4) ? 4 : action,Translator.iniSetFile, false, false);
			}
			selected = null;
			return true;
		} else {
			selected = new Point(x, y);
		}
		return false;
	}

	private boolean showAction(int x, int y) {
		// Determine what square (if any) was selected
                int actionNum = action;
                System.out.println("+++++++++++++++++++++++++++ Action Number:"+actionNum);
                
                
                
		x = (x - calculations.OFFSET_X) / calculations.BOX_SIZE;
		y = (y - calculations.OFFSET_Y) / calculations.BOX_SIZE;
		Position sel = new Position(y, x);
		if (sel != null) {
			System.out.println("Position toShow : (" + sel.getX() + "," + sel.getY() + ")");
		}
		// Determine if a move should be attempted
		if (Board.isValidPos(sel)) {
			Card show = game.show(sel);
			if (show != null && !show.isHinted()) {
				ArrayList<Object> toWrite = new ArrayList<>();
				toWrite.add(SetOfActions.COL);
				toWrite.add(show.getNumCard());
				toWrite.add(show.getColor().toString(false));
                                
                                
                                if (Main.hm == 0) {
                                    
                                    if (Main.player == 1) {
                                        //window.getOpts().player2.setBackground(Color.GRAY);
                                        window.getOpts().player2c1.setBackground(Color.GRAY);
                                        window.getOpts().player2c2.setBackground(Color.GRAY);
                                        
                                        //window.getOpts().player1.setOpaque(true);
                                        window.getOpts().player1c1.setOpaque(true);
                                        window.getOpts().player1c2.setOpaque(true);
                                        

                                        String color = show.getColor().toString(false);
                                        
                                        switch (color) {
                                            case "B":   if (action == 0) window.getOpts().player1c1.setBackground(Color.BLUE);
                                                        if (action == 1) window.getOpts().player1c2.setBackground(Color.BLUE);
                                                        break;
                                            case "G":   if (action == 0) window.getOpts().player1c1.setBackground(Color.GREEN);
                                                        if (action == 1) window.getOpts().player1c2.setBackground(Color.GREEN);
                                                        break;
                                            case "Y":   if (action == 0) window.getOpts().player1c1.setBackground(Color.YELLOW);
                                                        if (action == 1) window.getOpts().player1c2.setBackground(Color.YELLOW);
                                                        break;
                                            case "R":   if (action == 0) window.getOpts().player1c1.setBackground(Color.RED);
                                                        if (action == 1) window.getOpts().player1c2.setBackground(Color.RED);
                                                        break;
                                        }


                                    }

                                    if (Main.player == 2) {
                                        //window.getOpts().player1.setBackground(Color.GRAY);
                                        window.getOpts().player1c1.setBackground(Color.GRAY);
                                        window.getOpts().player1c2.setBackground(Color.GRAY);

                                        
                                        //window.getOpts().player2.setOpaque(true);
                                        window.getOpts().player2c1.setOpaque(true);
                                        window.getOpts().player2c2.setOpaque(true);                                        

                                        String color = show.getColor().toString(false);
                                        switch (color) {
                                            case "B":   if (action == 0) window.getOpts().player2c1.setBackground(Color.BLUE);
                                                        if (action == 1) window.getOpts().player2c2.setBackground(Color.BLUE);
                                                        break;
                                            case "G":   if (action == 0) window.getOpts().player2c1.setBackground(Color.GREEN);
                                                        if (action == 1) window.getOpts().player2c2.setBackground(Color.GREEN);
                                                        break;
                                            case "Y":   if (action == 0) window.getOpts().player2c1.setBackground(Color.YELLOW);
                                                        if (action == 1) window.getOpts().player2c2.setBackground(Color.YELLOW);
                                                        break;
                                            case "R":   if (action == 0) window.getOpts().player2c1.setBackground(Color.RED);
                                                        if (action == 1) window.getOpts().player2c2.setBackground(Color.RED);
                                                        break;
                                        }                                    
                                        //window.getOpts().player2.setText(show.getColor().toString(false));
                                    }                                
                                }
                                
                                
                                
				if (action == 0) {
					card1 = show;
					action++;
					Translator.writeActionPerformed(game, turn, (action >= 4) ? 4 : action, toWrite);
					Translator.createCurrentGameState(game, turn, (action >= 4) ? 4 : action,Translator.iniSetFile, false, false);
					return true;

				} else if (!card1.equals(show)) { // action == 1 && the card to show is different to the first one
					card2 = show;
					action++;
					Translator.writeActionPerformed(game, turn, (action >= 4) ? 4 : action, toWrite);
					Translator.createCurrentGameState(game, turn, (action >= 4) ? 4 : action,Translator.iniSetFile, false, false);
					return true;
				}
			} else {
				System.out.println("Bad card toShow");
			}
		} else {
			System.out.println("Bad card toShow");
		}
		return false;
	}

	private boolean isValidHintPos(int x, int y) {
		System.out.println("Hint position selected : (" + x + "," + y + ")");
		return (x == 0 && y >= 0 && y < NUM_HINT);
	}

	private boolean putHint(int x, int y) {
		// Determine what square (if any) was selected
		if (hintSelected == null) {
			x = (x - (calculations.OFFSET_X + calculations.BOX_SIZE * POS_HINT)) / calculations.HINT_BOX;
			y = (y - calculations.OFFSET_Y) / calculations.HINT_BOX;
		} else {
			x = (x - calculations.OFFSET_X) / calculations.BOX_SIZE;
			y = (y - calculations.OFFSET_Y) / calculations.BOX_SIZE;
		}

		if (hintSelected == null && !isValidHintPos(x, y)) {
			System.out.println("Bad hint Position");
			return false;
		} else if (hintSelected == null) {
			System.out.println("GOOD hint position");
			hintSelected = new Point(x, y + 1);
			return false;
		}

		Position pos = new Position(y, x);

		if (pos != null) {
			System.out.println("Hint selected : (" + hintSelected.getX() + "," + hintSelected.getY() + ")");
			System.out.println("Position toPut : (" + pos.getX() + "," + pos.getY() + ")");
		}
		// Determine if a move should be attempted
		if (Board.isValidPos(pos)) {
			HintCard hintToPut = game.getHintViewed(hintSelected.y);
			boolean put = game.putHintHere(hintToPut, pos);
                        String[] argTrans = new String[3];                        
			if (put) {
				ArrayList<Object> toWrite = new ArrayList<>();
				toWrite.add(SetOfActions.MARK);
				toWrite.add(game.getCard(pos).getNumCard());
				toWrite.add(hintToPut.getNumOfTheCard());
				action++;
				Translator.writeActionPerformed(game, turn, (action >= 4) ? 4 : action, toWrite);
                                
				Translator.createCurrentGameState(game, turn, (action >= 4) ? 4 : action,Translator.iniSetFile, false, false);
                                
                                
                                Runnable r = new Runnable() {
                                         public void run() {
                                             
                                             Translator.callThisModule(4, action, Translator.inference, argTrans);
                                         }
                                     };
                                
                            try {
                                TimeUnit.MILLISECONDS.sleep(100);
                                new Thread(r).start();
                            } catch (InterruptedException ex) {
                                Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                            }
                                
                                
                                
                                //Translator.callThisModule(4, action, Translator.inference, argTrans);

                                
			}
			hintSelected = null;
			return true;
		}
		return false;
	}
	
	private class ComputerPlay implements Runnable{
		
		private boolean exit = false;
		private Thread t = null;
		
		public State getState () {
			return t.getState();
		}
		
		public ComputerPlay() {
			t = new Thread (this, "Computer");
			System.out.println("New Thread Computer");
			t.start();
		}
		
		public void stop () {
			System.out.println("Stop method called");
			exit = true;
		}
		
		public void run() {
			int actualTurn = turn;
                        int i = 1;
			boolean callTheModule = true;
                        String[] argTrans = new String[3];
                        
                        
                        
			while (actualTurn == turn && !exit) {
				if (action >= 4) {
					actualTurn++;
					break;
				}
				ArrayList<Object> computerAction = ucp.getNextAction(actualTurn, action);
				if (computerAction != null && !exit) {
					Card cardSeen = ((Computer) getCurrentPlayer()).play(game, computerAction);
					if (card1SeenByTheComputer == null)
						card1SeenByTheComputer = cardSeen;
					else if (card2SeenByTheComputer == null)
						card2SeenByTheComputer = cardSeen;
					action++;
					callTheModule = true;
                                        
                                        // Aca llamar a ma prox linea tantas veces sea hasta que exista una entrada :1 en el archivo de ../sdata/interface.txt
                                        // Si la accion = Movement, then no call BRev because the new position will be recalculated each time by the GUI and save in 00_sets_ini.txt
                                        /*if (action != 3) {*/
                                        argTrans[0] =  "-e";
                                        argTrans[1] =  "s";  
                                        //argTrans[2] =  "interfacefx.txt";
                                        // Esta es la llama principal al Brev, la otra llamada - mas abajo - es solo para remover la ultima linea de la base Z_vol y actializar el set $BORDERCARDS en 00_ini_state
                                        //Translator.callThisModule(actualTurn, action, Translator.revision, argTrans);
                                        if (ActionPos) {
                                            Translator.callThisModule(4, action, Translator.revision, argTrans);
                                            ActionPos = false;
                                        } else {
                                            Translator.callThisModule(actualTurn, action, Translator.berv, argTrans);
                                        }
                                        //Call the inference if the action = 4 (mark_x_c_t) ONLY when is MACHINE turn (When is HUMAN turn, then not belief revision is performed, so we need to call INFERENCE in other function
                                        /*if (action == 4) {
                                            Translator.callThisModule(actualTurn, action, Translator.inference, argTrans);
                                        }*/
                                        
                                        /*}*/
                                        //Reset the Goal sequence (priority)
                                            i = 1;
                                        // sino existe una entrada :1, luego de la execution de la linea anterior, quiere decir que no se pudo generar un plan con esa GOAL
                                        // Entonces, cambiar de GOAL y volver a executar la linea, hasta encontrar una entrada :1
                                        
					Translator.createCurrentGameState(game, actualTurn, (action >= 4) ? 4 : action,Translator.iniSetFile, false, false);
            
                                        /*File combinedFile;
                                        ProcessBuilder builder;
                                        combinedFile = new File("../sdata/01_ini_set.txt");


                                        // Concatenando el archivo de los : generated sets + el ini_set (current state) + el file de la Pre_Cond 
                                        builder = new ProcessBuilder("cat", "../sdata/00_mk_cards_colors.txt");
                                        builder.redirectOutput(combinedFile);
                                        builder.redirectError(combinedFile);*/
                        
                                        
                                        
                                        
                                        
					repaint();
				}
				else if (!exit && callTheModule){
                                        int lineNum = 0;
                                        int actionNum = 0;
                                        boolean plan_found = false;
                                        File file = new File("../sdata/interface.txt");
                                        //actionNum = (turn * 4 + action + 1);
                                        actionNum = (action + 1);
                                        
                                        if (actionNum != 3) {
                                            
                                            
                                        int numlineas = 0, ii = 1;
                                        numlineas = countLineBufferedReader("../sdata/00_sets_same_color_grouped.order");       // File que contiene las cartas agrupadas ordenados de Mayor a menor cantidad (Nota 1.1)
                                        /*
                                            Y|8;10;12;
                                            G|1;2;9;
                                            B|5;4;12;
                                        */
                                        
                                            
                                        while (plan_found == false) {
                                            
                                        // Leer el * 00_sets_same_color_grouped.order * file linea x linea, empezando x el grupo mas grande y generar acciones de Observacion (col_x_y)
                                        // SINO hay lineas (file vacio) quiere decir que NO HAY GRUPOS entonces debe de mover ramdom -> pero luego del T=1 ya deberia hacer al menos grupos de 1 color?
                                        /*
                                        R|4;5;6;
                                        G|1;2;
                                        B|10;20;
                                        */
                                        
                                        
                                        if ((actionNum == 1) || (actionNum == 2)) {
                                        // Generar acciones de COL_alrededor del grupo R|4;5;6;
                                        // 2.4 F2 YOKAI: Llamar al GENSETS with option -o 
                                        // Leer file 00_sets_same_color_grouped.order y enviar nro de linea a gensets :  ../gensets/gensets -e o <linea>
                                        // numlineas
                                        // Aca intenta primero OBSERVAR alrededor de grupos de cartas YA formados, empezado por el grupo que tiene mas cartas (ir a ver Nota 1.1)
                                            if (ii == 0 || ii > numlineas) {
                                                argTrans[0] =  "-e";
                                                argTrans[1] =  "o";                                         // Con la opcion -o , ya se encarga de ver si genera las acciones alrededor de un grupo o si no hay grupo genera rando
                                                argTrans[2] =  Integer.toString(0);  //Atention! : queda pendiente como grabar 2 grupos del mismo color (i.e. G|1;2; and G|7;11;)
                                                
                                                // 2.2. - F2 YOKAI
                                                Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans); 
                                            } 
                                            
                                            else if (ii <= numlineas) {
                                                argTrans[0] =  "-e";
                                                argTrans[1] =  "o";                                         // Con la opcion -o , ya se encarga de ver si genera las acciones alrededor de un grupo o si no hay grupo genera rando
                                                argTrans[2] =  Integer.toString(ii);  //Atention! : queda pendiente como grabar 2 grupos del mismo color (i.e. G|1;2; and G|7;11;)
                                                // 2.2. - F2 YOKAI
                                                Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);                                                 
                                                ii ++;
                                            }    
                                        
                                        
                                        }
                                                                                
                                            
                                            
                                            
                                        // Aca llamar a un modulo de verificacion de la pre-condicion de la Goal
                                        // Si ese modulo es SAT => recien llamar a la accion correspondiente
                                        // Basicamente aca lo que se quiere es ver que Goal enviar (-- states parameter)
                                        // Entonces la PRIORIDAD de la GOAL depende de si esta cumple la PRE-CONDICION !!!
                                        // Aca llamar a STRATEGY.ML con parametro PHASE_# (limit) y retornar el GOAL_#. Colocar este valor en el (i) de la sig linea : 
                                        // Para la primera parte del testing de STRATEGY.ML vamos a hacer que evalue que GOAL_# escoger para el limit = 3 (Move a card) 
                                        String[] argTransx = { "--solve", "../sdata/00_axioms_0.txt", "--limit","1","--states",String.valueOf(i)};
                                        int j = 1, touistPC = 8;
                                        
                                        if (actionNum == 4) {
                                            

                                            
                                            
                                            while (touistPC != 0) { 
                                               // Analise Pre-condition for marking a card
                                               String[] argTransxm = { "--solve", "../sdata/00_axioms_0.txt", "--limit","1","--states",String.valueOf(j)};
                                               Translator.callThisModule(actualTurn, action, Translator.translator, argTransxm);
                                               // Ver el codigo que retorno el GOAL 4.1 , si es diff de 0 entonces probar con GOAL 4.2 ...hasta GOAL 4.3, sino no existe solucion => Generar goal 4.4
                                               
                                               String clock=null;
                                               int clock_num = 0;
                                               
                                                try {
                                                    clock = Files.readAllLines(Paths.get("../sdata/99_clock.txt")).get(0);                                               
                                                } catch (IOException ex) {
                                                    Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                }
                                                
                                                clock_num = Integer.valueOf(clock) + 1;
                                                
                                               
                                               File combinedFile;
                                               combinedFile = new File("../sdata/goals/Goal_4"+Integer.toString(j)+"."+Integer.toString(clock_num));
                                               //Call touist.exe for checking if the Pre-condition is SAT     
                                               argTrans[0] =  combinedFile.getAbsolutePath();
                                               touistPC = Translator.callThisModule(actualTurn, action, Translator.touist, argTrans);                                           
                                               j++;
                                            }   
                                            Translator.callThisModule(actualTurn, action, Translator.planner, Translator.argPlan);
                                            
                                            
                                            
                                        } else {
                                        
                                            Translator.callThisModule(actualTurn, action, Translator.translator, argTransx);
                                            Translator.callThisModule(actualTurn, action, Translator.planner, Translator.argPlan);
                                        }
                                        // Call inference siempre -> Si no hay accion = 5 (Marked ?) then it does nothing
                                        //Translator.callThisModule(actualTurn, action, Translator.inference, Translator.argInference);
                                        
                                        

                                        try {
                                            Scanner scanner = new Scanner(file);
                                            //now read the file line by line...
                                            while (scanner.hasNextLine()) {
                                                String line = scanner.nextLine();
                                                lineNum++;
                                                //if(<some condition is met for the line>) { 
                                                if(line.contains(":1")) { 
                                                    System.out.println("Good !, I found a new action in Inteface.txt in line : " +lineNum);
                                                    plan_found = true;
                                                }
                                            }
                                        }   catch (FileNotFoundException ex) {                                      
                                                Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                            }
                                        //i ++; Lo comento temporalmente para que no cambien de goal hacia goal_22.txt, pues esta usando una goal muy antigua que tiene todos los axioms - 07/03/2022
                                        
                                        }} 
                                        
                                        
                                        
                                        
                                        
                                        else {   //Action = movement
                                        int touistPC = 0;
                                        int goalSelected = 0;
                                        int ssfx, ssf, ss, g4, g3;
                                        //String cards_set[] = null;
                                        String[][] cards_set = new String[100][]; 
                                        String[][] cards_4g = new String[100][]; 
                                        String[][] cards_3g = new String[100][]; 
                                        String[][] cards_2g = new String[10][]; 
                                        String[] cards_color = new String[100]; 
                                        String[] set_line = new String[100]; 
                                        String lineFile = "";
                                        
                                        
                                        window.endTheGameLive();
                                        
                                        
                                        
                                        // Here the Java GUI should read both files and load it in an matrix size 4 (for each color) then :
                                        /* 1. Read the matrix with a for loop 
                                         2. For each element generates the sub-groups of size 4 at most, 
                                         3. save 00_sets_same_color_mix.txt file for each element 
                                         4. call gensets with 00_sets_same_color_mix.txt*/
                                        
                                        // 2021/12/02
                                        /*Here We should mix the two files: 00_sets_same_color.txt ^ 00_sets_same_colorhint.txt and build the new file ./sdata/00_sets_same_color_mix.txt to call Translator.gensets instead of ./sdata/00_sets_same_color.txt: 
                                            But this file (the mix) should already have the valid 4 combinations at most::
                                            La llamada al gensets deberia ser : 
                                            $ gensets 1,2,7,11,12       2 => genera lo siguiente: 1/2/7/11 or 1/2/7/12 or 1/2/11/12 y luego los sub-grupos de 3 elementos de c/u de estos 3 grandes-grupos de 4.
                                            $ gensets 1,2,7,11,12       3 => genera lo siguiente: 1/2/7/11 or 1/2/7/12 y luego los sub-grupos de 3 elementos de c/u de estos 2 grandes-grupos de 4.
                                            $ gensets 1,2,7,11,12,13    2 => genera lo siguiente: 1/2/7/11 or 1/2/7/12 or 1/2/7/13 or 1/2/11/12 or 1/2/11/13 or or 1/2/12/13 y luego los sub-grupos de 3 elementos de c/u de estos 6 grandes-grupos de 4.

                                            $ gensets 1,2,7,11,12,13    1 => genera lo siguiente: 1/2/7/11 or 1/2/7/12 or 1/2/7/13 or 1/2/11/12 or 1/2/11/13 or 1/2/12/13 or 1/7/11/13 y luego los sub-grupos de 3 elementos de c/u de estos 6 grandes-grupos de 4.                                        
                                        
                                            $ gensets 1,2,7,9           0 => genera lo siguiente: 1/2/7/9 y luego los sub-grupos de 3 elementos de c/u de este 1 grand-grupos de 4.                                        
                                        
                                            $ gensets 1,2,7             0 => genera lo siguiente: 1/2/7 y luego los sub-grupos de 2 elementos de c/u de este 1 grand-grupos de 3.    
                                        
                                            $ gensets 1,2,7             1 => genera lo siguiente: 1/2/7 y luego los sub-grupos de 2 elementos de c/u de este 1 grand-grupos de 3.                                            
                                                                             En los cuales de nuevo tengo que priorizar agrupar los que son  Triangles Alpha, osea se formarian 2 grupos de 2 con los siguiente sets: 1/2 or 1/7, pero NO 2/7
                                        
                                            $ gensets 1,2,7,9           3 => genera lo siguiente: 1/2/7/9 y luego los sub-grupos de 3 elementos de c/u de este 1 grand-grupos de 4. Los grupos de 3 serian: 1/2/7 or 1/2/9 or 2/7/9. Pero so no puede agrupar 3 entonces:
                                                                                Entonces los sub-grupos de 2 serian: 1,2 / .....donde siempre habra uno de los 3 que son Triangles.
                                        
                                            $ gensets 1,2,7,11          4 => genera lo siguiente: 1/2/7/11 y luego se detiene y genera los sub-sets de 3 elementos.
                                        */
                                        
                                        
                                        /* Ok It is clear now, lets move on to mix the 2 files :::*/
                                        
                                        
                                        // 2021/09/18 ...
                                        /* gensets with "m" option : builts all the subsets X' of set X. For example if its not possible to group G|1;2;7;11;
                                            then "gensets" generates the file 00_sets_same_color.txt.out with 
                                            G|2;7;11;
                                            G|1;7;11;
                                            G|1;2;7;
                                            G|1;2;11;
                                        */
                                        
                                        
                                        // Llamar al gensets con la opcion -x , para generar el file .mix (donde estan las cartas observadas y las deducidas)
                                        argTrans[0] =  "-e";
                                        argTrans[1] =  "x";
                                        argTrans[2] =  "../sdata/00_sets_same_color.txt";  
                                        Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);                                        
                                        
                                        
                                        argTrans[0] =  "-e";
                                        argTrans[1] =  "m";
                                        // Aca cambiar este archivo x el .mix para que ahora intente agrupar basado en este file
                                        //argTrans[2] =  "../sdata/00_sets_same_color.txt";  
                                        argTrans[2] =  "../sdata/00_sets_same_color.mix";

                                        // 2.1. - F2 YOKAI                                       (*
                                        Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);
                                        //Pero aca es solo para el action = 3 (Mover) => debo antes ver que nro de action se esta executando
                                        // Get el numero de filas del archivo 
                                        ssfx = countLineBufferedReader("../sdata/00_sets_same_color.txt.out");  //This file contains all the sub-sets X' <= X
                                        for (ssf = 0; ssf < ssfx; ssf++) {
                                            try {
                                                lineFile = Files.lines(Paths.get("../sdata/00_sets_same_color.txt.out")).skip(ssf).findFirst().get();
                                            } catch (IOException ex) {
                                                Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                            }
                                            // Leer y hacer un split a partir del 3 caracter
                                            cards_set[ssf] = lineFile.substring(2).split(";"); //Filtrar solo los que sets que tienen 2 cards o mas
                                            cards_color[ssf] = lineFile.substring(0,1); //Filtrar solo los que sets que tienen 2 cards o mas
                                            set_line[ssf] = lineFile;
                                            System.out.println("Original String: " + Arrays.toString(cards_set[ssf]));  
                                        }
                                        
                                        ssf = 0;
                                        while (plan_found == false) {
                                            
                                            if (ssf == ssfx) {
                                                ss = 0;
                                            } else {
                                                ss = (cards_set[ssf].length);
                                            }
                                            File combinedFile, pc_grouped;
                                            File combinedFile2; //, combinedFile3, combinedFile4;
                                            ProcessBuilder builder;
                                            combinedFile2 = new File("../sdata/00_border_cards.txt");
                                            //combinedFile3 = new File("../gensets/genactions/gen_act_3.txt.out");
                                            //combinedFile4 = new File("../gensets/genactions/00_sets_same_color.txt.uno.set");

                                            
                                            switch (ss) {
                                                // Goal = group 4 cards  
                                                case 4:
                                                    combinedFile = new File("../sdata/g4Cards_PC_final.tmp");
                                                    pc_grouped = new File("../sdata/g4Cards_PC_final_grouped.tmp");
                                                    
                                                    goalSelected = 4;
                                                    lineNum = 0;
                                                    
                                                    try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/00_sets_same_color.txt.uno"))) {
                                                                out.print(set_line[ssf]);
                                                            } catch (FileNotFoundException ex) {
                                                        Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                    }

                                                    argTrans[0] =  "-e";
                                                    argTrans[1] =  "s";     //Generate the sets (possible combinations)  for each of the rows (../sdata/00_sets_same_color.txt.uno) of the file ../sdata/00_sets_same_color.txt.out
                                                    argTrans[2] =  "../sdata/00_sets_same_color.txt.uno";  
                                                    
                                                    // 2.2. - F2 YOKAI
                                                    Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);
                                                    
                                                    


                                                    //// 24/03/2022
                                                    // Ver si hay g3 de color cards_color[ssf]
                                                    try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/g4cardsok.tmp"))) { out.print("$G4CARDSOK = [[0]]"); } 
                                                    catch (FileNotFoundException ex) { 
                                                        Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                    }                                                    

                                                    //builder = new ProcessBuilder("cat", "../sdata/g4cardsok.tmp", "../sdata/g3cardsok.tmp", "../sdata/g3_addvars.tmp", "../sdata/g3Cards_Sets.sets."+cards_color[ssf], "../sdata/01_ini_set.txt", "../sdata/goals_pc/g3Cards_PC_grouped.touist");
                                                    builder = new ProcessBuilder("cat", "../sdata/g4cardsok.tmp", "../sdata/g4Cards_Sets.sets."+cards_color[ssf], "../sdata/01_ini_set.txt", "../sdata/goals_pc/g4Cards_PC_grouped.touist");                                                    
                                                    builder.redirectOutput(pc_grouped);
                                                    builder.redirectError(pc_grouped);
                                                    {                                                    
                                                       try {
                                                           Process p = builder.start();
                                                       } catch (IOException ex) {
                                                           Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                       }
                                                    }
                                                    //Call touist.exe for checking if the Pre-condition is SAT     
                                                    argTrans[0] =  pc_grouped.getAbsolutePath();
                                                    touistPC = Translator.callThisModule(actualTurn, action, Translator.touist, argTrans);
                                                    // Llamar a gensets para grabar en 00_card_grouped.txt
                                                    // Parameters to generate default actions for movements - ramdom
                                                    if (touistPC != 0) {    //Quiere decir que estas 3 cartas en .uno  YA ESTAN agrupadas => actualiza esto en el file: 00_sets_same_color_grouped.order
                                                        // Aca tambien se deberia actualizar el file ../sdata/00_sets_same_color_3g.txt con el siguiente formato:
                                                        /*
                                                            R|51;52;53;
                                                            G|51;52;53;
                                                            Y|51;52;53;
                                                            B|51;52;53;                                                        
                                                        
                                                        */
                                                      argTrans[0] =  "-e";
                                                      argTrans[1] =  "g";
                                                      argTrans[2] =  "../sdata/00_sets_same_color.txt.uno";
                                                      //argTrans[2] =  "00_sets_same_color.txt.uno";
                                                      Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);
                                                    }

                                                    /////                                                       
                                                    







                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    // Concatenando el archivo de los : generated sets + el ini_set (current state) + el file de la Pre_Cond 
                                                    builder = new ProcessBuilder("cat", "../sdata/g4Cards_Sets.sets."+cards_color[ssf], "../sdata/01_ini_set.txt", "../sdata/goals_pc/g4Cards_PC.touist");
                                                           builder.redirectOutput(combinedFile);
                                                           builder.redirectError(combinedFile);
                                                            {                                                    
                                                                try {
                                                                    Process p = builder.start();
                                                                    TimeUnit.MILLISECONDS.sleep(200);
                                                                   
                                                                } catch (IOException ex) {
                                                                    Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                                } catch (InterruptedException ex) {
                                                    Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                }
                                                            }
                                                    //Call touist.exe for checking if the Pre-condition is SAT
                                                    argTrans[0] =  combinedFile.getAbsolutePath();
                                                    touistPC = Translator.callThisModule(actualTurn, action, Translator.touist, argTrans);
                                                    break;

                                                // Goal = group 3 cards    
                                                case 3:
                                                    combinedFile = new File("../sdata/g3Cards_PC_final.tmp");
                                                    pc_grouped = new File("../sdata/g3Cards_PC_final_grouped.tmp");
                                                    
                                                    goalSelected = 3;
                                                    lineNum = 0;
                                                    
                                                    try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/00_sets_same_color.txt.uno"))) {
                                                                out.print(set_line[ssf]);
                                                            } catch (FileNotFoundException ex) {
                                                        Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                    }                                                    
                                                    argTrans[0] =  "-e";
                                                    argTrans[1] =  "s";     //Genera todas las posibles combinaciones para ese grupo de 3 cards
                                                    argTrans[2] =  "../sdata/00_sets_same_color.txt.uno";
                                                    
                                                    //00_sets_same_color_4grouped.txt
                                                    g4 = countLineBufferedReader("../sdata/00_sets_same_color_4g.txt");  //This file contains all the sub-sets X' <= X
                                                    try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/g4cardsok.tmp"))) { out.print("$G4CARDSOK = [[0]]"); } 
                                                    catch (FileNotFoundException ex) { 
                                                        Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                    }
                                                    
                                                    for (i = 0; i < g4; i++) {
                                                        try {
                                                            lineFile = Files.lines(Paths.get("../sdata/00_sets_same_color_4g.txt")).skip(i).findFirst().get();
                                                        } catch (IOException ex) {
                                                            Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                        }
                                                        // Leer y hacer un split a partir del 3 caracter
                                                        cards_4g[i] = lineFile.substring(2).split(";"); //Filtrar solo los que sets que tienen 2 cards o mas
                                                        //cards_color[i] = lineFile.substring(0,1); //Filtrar solo los que sets que tienen 2 cards o mas
                                                        //set_line[i] = lineFile;
                                                        String color, color2;
                                                        color = lineFile.substring(0,1).trim();
                                                        color2 = cards_color[ssf].trim();
                                                        //if (color == color2) {
                                                        if (color.equals(color2)) {
                                                            System.out.println("### Color Objetivo BIEN !! : " + lineFile.substring(0,1)  + " en la linea: "+ cards_color[ssf]); 
                                                            System.out.println("[" + Arrays.toString(cards_4g[i]) + "]");  
                                                            try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/g4cardsok.tmp"))) { out.print("$G4CARDSOK = ["+Arrays.toString(cards_4g[i])+"] "); } 
                                                            catch (FileNotFoundException ex) {
                                                                Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                            }
                                                            try {
                                                                BufferedWriter output = new BufferedWriter(new FileWriter("../sdata/g4cardsok.tmp", true));
                                                            } catch (IOException ex) {
                                                                Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                            }
                                                        } //Filtrar solo los que sets que tienen 2 cards o mas
                                                        System.out.println("### Color Objetivo AFTER : " + lineFile.substring(0,1)  + " en la linea: "+ cards_color[ssf]); 
                                                        
                                                    }
                                                    


                                                    Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);
                                                    
                                                    
                                                    //// 04/03/2022
                                                    // Ver si hay g3 de color cards_color[ssf]
                                                    try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/g3cardsok.tmp"))) { out.print("$G3CARDSOK = [[0]]"); } 
                                                    catch (FileNotFoundException ex) { 
                                                        Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                    }                                                    

                                                    //builder = new ProcessBuilder("cat", "../sdata/g4cardsok.tmp", "../sdata/g3cardsok.tmp", "../sdata/g3_addvars.tmp", "../sdata/g3Cards_Sets.sets."+cards_color[ssf], "../sdata/01_ini_set.txt", "../sdata/goals_pc/g3Cards_PC_grouped.touist");
                                                    builder = new ProcessBuilder("cat", "../sdata/g4cardsok.tmp", "../sdata/g3cardsok.tmp", "../sdata/g3Cards_Sets.sets."+cards_color[ssf], "../sdata/01_ini_set.txt", "../sdata/goals_pc/g3Cards_PC_grouped.touist");                                                    
                                                    builder.redirectOutput(pc_grouped);
                                                    builder.redirectError(pc_grouped);
                                                    {                                                    
                                                       try {
                                                           Process p = builder.start();
                                                       } catch (IOException ex) {
                                                           Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                       }
                                                    }
                                                    //Call touist.exe for checking if the Pre-condition is SAT     
                                                    argTrans[0] =  pc_grouped.getAbsolutePath();
                                                    touistPC = Translator.callThisModule(actualTurn, action, Translator.touist, argTrans);
                                                    // Llamar a gensets para grabar en 00_card_grouped.txt
                                                    // Parameters to generate default actions for movements - ramdom
                                                    if (touistPC != 0) {    //Quiere decir que estas 3 cartas en .uno  YA ESTAN agrupadas => actualiza esto en el file: 00_sets_same_color_grouped.order
                                                        // Aca tambien se deberia actualizar el file ../sdata/00_sets_same_color_3g.txt con el siguiente formato:
                                                        /*
                                                            R|51;52;53;
                                                            G|51;52;53;
                                                            Y|51;52;53;
                                                            B|51;52;53;                                                        
                                                        
                                                        */
                                                      argTrans[0] =  "-e";
                                                      argTrans[1] =  "g";
                                                      argTrans[2] =  "../sdata/00_sets_same_color.txt.uno";
                                                      //argTrans[2] =  "00_sets_same_color.txt.uno";
                                                      Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);
                                                    }

                                                    /////                                                      
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    builder = new ProcessBuilder("cat", "../sdata/g4cardsok.tmp","../sdata/g3Cards_Sets.sets."+cards_color[ssf], "../sdata/01_ini_set.txt", "../sdata/goals_pc/g3Cards_PC.touist");
                                                    builder.redirectOutput(combinedFile);
                                                    builder.redirectError(combinedFile);
                                                     {                                                    
                                                         try {
                                                             Process p = builder.start();
                                                         } catch (IOException ex) {
                                                             Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                         }
                                                     }
                                                    //Call touist.exe for checking if the Pre-condition is SAT     
                                                    argTrans[0] =  combinedFile.getAbsolutePath();
                                                    touistPC = Translator.callThisModule(actualTurn, action, Translator.touist, argTrans);
                                                    break; 
                                                    
                                                    
////////////////////////////////////////////////////////////////////////


                                                // Goal = group 2 cards   
                                                   
                                                case 2:
                                                    combinedFile = new File("../sdata/g2Cards_PC_final.tmp");
                                                    pc_grouped = new File("../sdata/g2Cards_PC_final_grouped.tmp");
                                                    
                                                    //goalSelected = 3;
                                                    goalSelected = 2;
                                                    lineNum = 0;
                                                    
                                                    try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/00_sets_same_color.txt.uno"))) {
                                                                out.print(set_line[ssf]);
                                                            } catch (FileNotFoundException ex) {
                                                        Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                    }                                                    
                                                    argTrans[0] =  "-e";
                                                    argTrans[1] =  "s";  //Genera todas las posibles combinaciones para ese grupo de 2 cards in ../sdata/g2Cards_Sets.sets.COLOR
                                                        argTrans[2] =  "../sdata/00_sets_same_color.txt.uno";
                                                    
                                                    
                                                    
                                                    {
                                                        try {
                                                            lineFile = Files.lines(Paths.get("../sdata/00_sets_same_color.txt.uno")).skip(0).findFirst().get();
                                                        } catch (IOException ex) {
                                                            Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                        }
                                                    }
                                                    cards_2g[0] = lineFile.substring(2).split(";"); 
                                                    System.out.println("$X(Y,2,1) = [" + Arrays.toString(cards_2g[0]) + "]");
                                                    try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/g2Cards_Sets.sets."+cards_color[ssf]))) { out.print("$X("+cards_color[ssf]+",2,1) = [" + Arrays.toString(cards_2g[0]) + "]"); } 
                                                    catch (FileNotFoundException ex) { 
                                                        Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                    }                                                    
                                                    
                                                    
                                                    //00_sets_same_color_4grouped.txt
                                                    // Ver si ya hay un grupo de 4 cartas de ese color agrupadas para meter esa variable en la PC_G2
                                                    // Si se OBSERVA una quinta carta de ese color => borrar este registro, para que se puedan volver a dispersar las cartas
                                                    // puesto que este grupo se agrupo en base a malas deducciones
                                                    g4 = countLineBufferedReader("../sdata/00_sets_same_color_4g.txt");  
                                                    g3 = countLineBufferedReader("../sdata/00_sets_same_color_3g.txt");  // Ver si ya hay un grupo de 3 cartas de ese color agrupadas para meter esa variable en la PC_G2
                                                    
                                                    // Ver si hay g4 de color cards_color[ssf]
                                                    try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/g4cardsok.tmp"))) { out.print("$G4CARDSOK = [[0]]"); } 
                                                    catch (FileNotFoundException ex) { 
                                                        Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                    }
                                                    for (i = 0; i < g4; i++) { 
                                                        try {
                                                            lineFile = Files.lines(Paths.get("../sdata/00_sets_same_color_4g.txt")).skip(i).findFirst().get();
                                                        } catch (IOException ex) {
                                                            Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                        }
                                                        // Leer y hacer un split a partir del 3 caracter
                                                        cards_4g[i] = lineFile.substring(2).split(";"); //Filtrar solo los que sets que tienen 2 cards o mas
                                                        //cards_color[i] = lineFile.substring(0,1); //Filtrar solo los que sets que tienen 2 cards o mas
                                                        //set_line[i] = lineFile;
                                                        String color, color2;
                                                        color = lineFile.substring(0,1).trim();
                                                        color2 = cards_color[ssf].trim();
                                                        //if (color == color2) {
                                                        if (color.equals(color2)) {
                                                            System.out.println("### Color Objetivo BIEN !! : " + lineFile.substring(0,1)  + " en la linea: "+ cards_color[ssf]); 
                                                            System.out.println("[" + Arrays.toString(cards_4g[i]) + "]");  
                                                            try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/g4cardsok.tmp"))) { out.print("$G4CARDSOK = ["+Arrays.toString(cards_4g[i])+"] "); } 
                                                            catch (FileNotFoundException ex) {
                                                                Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                            }
                                                            try {
                                                                BufferedWriter output = new BufferedWriter(new FileWriter("../sdata/g4cardsok.tmp", true));
                                                            } catch (IOException ex) {
                                                                Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                            }
                                                        } //Filtrar solo los que sets que tienen 2 cards o mas
                                                        System.out.println("### Color Objetivo AFTER : " + lineFile.substring(0,1)  + " en la linea: "+ cards_color[ssf]); 
                                                        
                                                    }
                                                    
                                                    // Ver si hay g3 de color cards_color[ssf]
                                                    try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/g3cardsok.tmp"))) { out.print("$G3CARDSOK = [[0]]"); } 
                                                    catch (FileNotFoundException ex) { 
                                                        Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                    }
                                                    for (i = 0; i < g3; i++) { 
                                                        try {
                                                            lineFile = Files.lines(Paths.get("../sdata/00_sets_same_color_3g.txt")).skip(i).findFirst().get();
                                                        } catch (IOException ex) {
                                                            Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                        }
                                                        // Leer y hacer un split a partir del 3 caracter
                                                        //cards_4g[i] = lineFile.substring(2).split(";"); //Filtrar solo los que sets que tienen 2 cards o mas
                                                        cards_3g[i] = lineFile.substring(2).split(";"); //Filtrar solo los que sets que tienen 2 cards o mas
                                                        //cards_color[i] = lineFile.substring(0,1); //Filtrar solo los que sets que tienen 2 cards o mas
                                                        //set_line[i] = lineFile;
                                                        String color, color2;
                                                        color = lineFile.substring(0,1).trim();
                                                        color2 = cards_color[ssf].trim();
                                                        //if (color == color2) {
                                                        if (color.equals(color2)) {
                                                            System.out.println("### Color Objetivo BIEN !! : " + lineFile.substring(0,1)  + " en la linea: "+ cards_color[ssf]); 
                                                            System.out.println("[" + Arrays.toString(cards_3g[i]) + "]");  
                                                            try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/g3cardsok.tmp"))) { out.print("$G3CARDSOK = ["+Arrays.toString(cards_3g[i])+"] "); } 
                                                            catch (FileNotFoundException ex) {
                                                                Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                            }
                                                            try {
                                                                BufferedWriter output = new BufferedWriter(new FileWriter("../sdata/g3cardsok.tmp", true));
                                                            } catch (IOException ex) {
                                                                Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                            }
                                                        } //Filtrar solo los que sets que tienen 2 cards o mas
                                                        System.out.println("### Color Objetivo AFTER : " + lineFile.substring(0,1)  + " en la linea: "+ cards_color[ssf]); 
                                                        
                                                    }                                                    
/*
$G2CARDS = [1,2] $G2COLOR = G                                                    
*/
                                                    
                                                    // Add : $G2CARDS = [1,2] $G2COLOR = G                                                    
                                                    try (PrintStream out = new PrintStream(new FileOutputStream("../sdata/g2_addvars.tmp"))) { out.print("$G2CARDS = "+Arrays.toString(cards_2g[0])+" "+"$G2COLOR = "+cards_color[ssf]); } 
                                                    catch (FileNotFoundException ex) { 
                                                        Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                    }                                                    
                                                    


                                                        Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);
                                                    
//// 04/03/2022

                                                    builder = new ProcessBuilder("cat", "../sdata/g4cardsok.tmp", "../sdata/g3cardsok.tmp", "../sdata/g2_addvars.tmp", "../sdata/g2Cards_Sets.sets."+cards_color[ssf], "../sdata/01_ini_set.txt", "../sdata/goals_pc/g2Cards_PC_grouped.touist");
                                                    builder.redirectOutput(pc_grouped);
                                                    builder.redirectError(pc_grouped);
                                                     {                                                    
                                                         try {
                                                             Process p = builder.start();
                                                         } catch (IOException ex) {
                                                             Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                         }
                                                     }
                                                    //Call touist.exe for checking if the Pre-condition is SAT     
                                                    argTrans[0] =  pc_grouped.getAbsolutePath();
                                                    touistPC = Translator.callThisModule(actualTurn, action, Translator.touist, argTrans);
                                                    // Llamar a gensets para grabar en 00_card_grouped.txt
                                                    // Parameters to generate default actions for movements - ramdom
                                                            if (touistPC != 0) {    //Quiere decir que estas cartas en .uno  YA ESTAN agrupadas => actualiza esto en el file: 00_sets_same_color_grouped.order
                                                        argTrans[0] =  "-e";
                                                        argTrans[1] =  "g";
                                                        argTrans[2] =  "../sdata/00_sets_same_color.txt.uno";
                                                        Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);
                                                    }

/////                                                    
                                                    
                                                    //builder = new ProcessBuilder("cat", "../sdata/g4cardsok.tmp","../sdata/g3Cards_Sets.sets."+cards_color[ssf], "../sdata/01_ini_set.txt", "../sdata/goals_pc/g3Cards_PC.touist");
                                                    builder = new ProcessBuilder("cat", "../sdata/g4cardsok.tmp", "../sdata/g3cardsok.tmp", "../sdata/g2_addvars.tmp", "../sdata/g2Cards_Sets.sets."+cards_color[ssf], "../sdata/01_ini_set.txt", "../sdata/goals_pc/g2Cards_PC.touist");
                                                    builder.redirectOutput(combinedFile);
                                                    builder.redirectError(combinedFile);
                                                     {                                                    
                                                         try {
                                                             Process p = builder.start();
                                                         } catch (IOException ex) {
                                                             Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                         }
                                                     }
                                                    //Call touist.exe for checking if the Pre-condition is SAT     
                                                    argTrans[0] =  combinedFile.getAbsolutePath();
                                                    touistPC = Translator.callThisModule(actualTurn, action, Translator.touist, argTrans);                                                    
                                                    
                                                    
                                                    
                                                    
                                                    // Sabado 2022_02_26
                                                    if (touistPC != 0) { //Son 2 cartas del mismo color y ya estan agrupadas x eso NO CUMPLE la condicion, sin embargo YA ESTAN AGRUPADAS y deben de grabarse en [00_cards_grouped.tmp] - ACA ESTA MAL DEBE DE CONTINUAR LEYENDO LA OTRA LINEA DE 2 cars en .out
                                                    //touistPC = 0;
                                                    //goalSelected = 1; // goal 1 = imposible movement
                                                    goalSelected = 0;   // goal 0 = move to a neigbour position of the group (perimeter)
                                                    // Parameters to generate default actions for movements - ramdom
                                                    argTrans[0] =  "-e";
                                                    argTrans[1] =  "d";  
                                                    argTrans[2] =  "../sdata/00_sets_same_color.txt";               
                                                    
                                                    Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);                                                    
                                                    }
                                                    // ---
                                                    
                                                    break;                                                     
                                                    
////////////////////////////////////////////////////////////////////////                                                                                                         
                                                    
////////////////////////////////////////////////////////////////////////                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                // Goal = default (Move randomly)
                                                //default:
                                                case 0:
                                                    touistPC = 0;
                                                    //goalSelected = 1; // goal 1 = imposible movement
                                                    //goalSelected = 2;   // goal 2 = move to a neigbour position of the group (perimeter)
                                                    goalSelected = 0;   // goal 0 = move to a neigbour position of the group (perimeter)
                                                    // Parameters to generate default actions for movements - ramdom
                                                    argTrans[0] =  "-e";
                                                    argTrans[1] =  "d";  
                                                    argTrans[2] =  "../sdata/00_sets_same_color.txt";               
                                                    Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);                                                                                                        
                                                    break;
                                                                                                }
                                                


                                        // If Pre-Condition OK
                                        if (touistPC == 0) {
                                        //    combinedFile3 = new File("../gensets/genactions/gen_act_3.txt.out");
                                        // Si ya INGRESO aca, el planner debe de encontrar un <PLAN> SI o SI !!! ==> NO importa modificar el 01_ini_state, 
                                        // pues para la siguiente accion sera regenerado...
                                        //        argTrans[0] =  "-e";
                                        //        argTrans[1] =  "a";
                                        //        argTrans[2] =  Integer.toString(actionNum); //Typo de Accion = 3 (Moviento) en la hora = 11: Machine planea sobre acciones para agrupar 4 cartas Green en 00_sets_same_color.txt.uno 
                                                                    //Que el sistema vea aca generar acciones de typo = 3 (mov) en el tiempo actual del file: 99_clock.txt
                                                                    // Grabar esta acciones en el file 02_actions_t4.txt    -- //argTrans[2] =  "../sdata/00_sets_same_color.txt";  
                                                                    
                                        
                                        // Aca generar las acciones para el set de cartas conocidas
                                        /*if (goalSelected != 0) {          //El primer caso es en el tiempo 11: Cuando la machine ya conoce las 4 cartas Green en el 00_sets_same_color.txt.uno 
                                                // 2.3. - F2 YOKAI                                       (*
                                                //Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);                                            
                                                //gen_act_3.txt

                                                 
                                                // New
                                                builder = new ProcessBuilder("cat", "../sdata/01_ini_set.txt", "$cardsone","../gensets/genactions/gen_act_3.txt"); //Create the file 00_border_cards again
                                                builder.redirectOutput(combinedFile3);
                                                builder.redirectError(combinedFile3);
                                                 {
                                                     try {
                                                         Process p = builder.start();
                                                     } catch (IOException ex) {
                                                         Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                     }
                                                 }
                                                
                                        }*/
                                        /*else {
                                           Llamar a getset con parametro para que genere ramdom actions de movimiento
                                        }*/
                                        
                                        
                                       
                                        
                                        String[] argTransx = { "--solve", "../sdata/00_axioms_0.txt", "--limit","1","--states",String.valueOf(goalSelected)}; //String.valueOf(i) = i
                                        Translator.callThisModule(actualTurn, action, Translator.translator, argTransx);
					Translator.callThisModule(actualTurn, action, Translator.planner, Translator.argPlan);
                                        //nro_actions1 = read the interface.txt file

                                        try {
                                            Scanner scanner = new Scanner(file);
                                            //now read the file line by line...
                                            while (scanner.hasNextLine()) {
                                                String line = scanner.nextLine();
                                                lineNum++;
                                                Card out = null;
                                                Board b;
                                                boolean legalmove=true, moreActions = true;
                                                String[][] card_elements = new String[10][];
                                                
                                                if (line.contains("⟙")) {
                                                                moreActions = false;
                                                            } 
                                                
                                                if (line.contains(":1")) { //Aca en Brev deberia AGREGAR el nuevo ILEGAL mov al border file
                                                                            // Veo que el Brev lo hace, agrega al border File.
                                                    //   Aca ver si la linea contiene ⟙
                                                    
                                                    if (line.contains("pos_")) ActionPos = true;
                                                           
                                                    if (moreActions == true) {      //No encontro simbolo : T en la ultima linea => continua
                                                    Thread.sleep(1000);
                                                    ArrayList<Object> computerActionx = ucp.getNextAction(actualTurn, action);
                                                    out = game.getTheCardFromNum((int)computerActionx.get(1));
                                                    legalmove = game.move(out,(Position)computerActionx.get(2));
                                                    
                                                    if (legalmove) {
                                                        System.out.println("Good !, I found a LEGAL MOVE new action in Inteface.txt in line : " +lineNum);
                                                        plan_found = true;
                                                        
                                                        
                                                        // Grabar las cartas en el file de cartas agrupadas
                                                        // para usarlo luego para guiar las observaciones
                                                        //Aca tambien debo de grabar en 00_sets_same_color_4g.txt or 00_sets_same_color_3g.txt 
                                                        argTrans[0] =  "-e";
                                                        argTrans[1] =  "g";
                                                        argTrans[2] =  "../sdata/00_sets_same_color.txt.uno";
                                                        Translator.callThisModule(actualTurn, action, Translator.gensets, argTrans);                                                        
                                                        
                                                        
                                                        
                                                        
                                                        // New
                                                        builder = new ProcessBuilder("cat", "../sdata/00_border_cards_bk.txt"); //Create the file 00_border_cards again initializing it: 99,
                                                        builder.redirectOutput(combinedFile2);
                                                        builder.redirectError(combinedFile2);
                                                         {                                                    
                                                             try {
                                                                 Process p = builder.start();
                                                             } catch (IOException ex) {
                                                                 Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                             }
                                                         }
                                                         // Aca lee las 2 lineas previas a la ultima linea y verifica si estas son vecinas y del mismo color ==> si TOIST = 0, then grabar en 00_cards_grouped.tmp en a linea de ese color.
                                                         
                                                         // Para verificar si se acabo el game (La maquina tambien puede detener el juego)
                                                        // @@@++     
                                                        //window.endTheGame();
                                                        /*if (!game.isGameOver()) {
                                                            System.out.println("Good !, After - window.endTheGameLive() ");
                                                        } else {
                                                            System.out.println("Game- Over: Se termino !!! ");
                                                        }*/
                                                        
                                                        //window.endTheGameLive();
                                                        /*if (board.sucess == true) {
                                                            System.out.println("Good !, After - window.endTheGameLive() ");
                                                        } else {
                                                            System.out.println("Game- Over: Se termino !!! ");
                                                        }*/
                                                        
                                                    
                                                    }
                                                    
                                                    else {
                                                        
                                                        // Remove last line of <file>
                                                        // Add filed action into the $failedaction set and join it with the 01_ini_set.txt file
                                                        argTrans[0] =  "-e";
                                                        argTrans[1] =  "m";  
                                                        //argTrans[2] =  "interface.txt";
                                                        // Aca tambien debe de borrar esa accion del set de acciones, para que no vuelva a ser tomada en cuenta la next time
                                                        Translator.callThisModule(actualTurn, action, Translator.berv, argTrans);
                                                        
                                                            String text = null;
                                                        BufferedReader brTest = new BufferedReader(new FileReader("../sdata/00_border_cards.txt"));
                                                        try {                                                            
                                                            text = brTest .readLine();
                                                        } catch (IOException ex) {
                                                            Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                        }
                                                        /*if (text.contains("11") == true) { ssf--; }*/
                                                        // Si hay mas datos que 99,
                                                        //if (text.length() > 3) {  ssf--; } 
                                                        ssf--;
                                                       
                                                    }} else {   //moreActions == false
                                                        // Remove last line of <file>
                                                        // Add filed action into the $failedaction set and join it with the 01_ini_set.txt file
                                                        argTrans[0] =  "-e";
                                                        argTrans[1] =  "m";  
                                                        //argTrans[2] =  "interface.txt";
                                                        // Aca tambien debe de borrar esa accion del set de acciones, para que no vuelva a ser tomada en cuenta la next time
                                                        Translator.callThisModule(actualTurn, action, Translator.berv, argTrans);
                                                        
                                                            String text = null;
                                                        BufferedReader brTest = new BufferedReader(new FileReader("../sdata/00_border_cards.txt"));
                                                        try {                                                            
                                                            text = brTest .readLine();
                                                        } catch (IOException ex) {
                                                            Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                        }                                                        
                                                        
                                                        
                                                    }
                                                } 
                                                
                                                
                                                
                                                
                                                
                                                
                                                /*else {    //NO valid plan for G4 cards, then enter here and delete the border_cards.txt
                                                        builder = new ProcessBuilder("cat", "../sdata/00_border_cards_bk.txt"); //Create the file 00_border_cards again
                                                        builder.redirectOutput(combinedFile2);
                                                        builder.redirectError(combinedFile2);
                                                         { try {
                                                                 Process p = builder.start();
                                                             } catch (IOException ex) {
                                                                 Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                             } }
                                                        //ssf++;  }*/
                                            }   //***
                                        }   catch (FileNotFoundException ex) {                                      
                                                Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                            }   catch (InterruptedException ex) {
                                                    Logger.getLogger(GameBoard.class.getName()).log(Level.SEVERE, null, ex);
                                                }
                                        }
                                        // No se pueden agrupar las X cards => probar con agrupar X-1 cards 
                                        // Probar con el siguiente item en cards_set (que son las files del file:00_sets_same_color.txt.out  - 2022.02.24
                                        //ssfx = countLineBufferedReader("../sdata/00_sets_same_color.txt.out");
                                        ssf++;
                                        }   //}
                                            
                                        }
                                        callTheModule = false;   
				}
				try {Thread.sleep(1000);}
				catch(Exception e) {System.out.println("Sleep Issue.");}
			}
			if (!exit) {
				turnCheck = actualTurn;
				game.havePlayed();
				action = 0;
				hintSelected = null;
				selected = null;
				card1SeenByTheComputer = null;
				card2SeenByTheComputer = null;
				repaint();
			}
		}

        private int countLineBufferedReader(String fileName) {
            int lines = 0;
            
            try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                while (reader.readLine() != null) lines++;
            } catch (IOException e) {
            }
            return lines;
        }
        
        
	}

	private void handleClick(int x, int y) {

		// The game is over or the current player isn't human
		if (game.isGameOver() || getCurrentPlayer() instanceof Computer) {
			return;
		}
		ArrayList<Object> actionPerformed = new ArrayList<>();
		if (action <= 1) {
			showAction(x, y);
		}

		else if (action == 2) {
			moveAction(x, y);
		} else if (action == 4) {
			putHint(x, y);
		}
		update();
	}

	private void handleButton(Object src) {
		// The game is over or the current player isn't human
		if (game.isGameOver()) {
			return;
		}
//		if ((getCurrentPlayer() instanceof Computer)) {
//			computerPlay();
//		}
		else if (src == viewHint && action == 3) {
			HintCard toShow = game.showHint();
			ArrayList<Object> toWrite = new ArrayList<>();
			toWrite.add(SetOfActions.ACT);
			toWrite.add(toShow.getNumOfTheCard());
			action += 2;
			Translator.writeActionPerformed(game, turn, (action >= 4) ? 4 : action, toWrite);
			Translator.createCurrentGameState(game, turn, (action >= 4) ? 4 : action,Translator.iniSetFile, false, false);
		} else if (src == putHint && action == 3 && (game.haveHintToPlay())) {
			action++;
		} else if (action == 5) {
			game.havePlayed();
			turn++;
			action = 0;
			hintSelected = null;
			selected = null;
			card1 = null;
			card2 = null;
			update();
		}
	}

	private class Calculations {
		public final int BOX_PADDING = 4;
		public final int W = getWidth(), H = getHeight();
		public final int DIM = W < H ? W : H;
		public final int BOX_SIZE = ((DIM - 2 * PADDING) / LENGTH);
		public final int HINT_BOX = BOX_SIZE + 10;
		public final int OFFSET_X = (W - BOX_SIZE * LENGTH) / 2;
		public final int OFFSET_Y = (H - BOX_SIZE * LENGTH) / 2;
		public final int CHECKER_SIZE = Math.max(0, BOX_SIZE - 2 * BOX_PADDING);

		public void Calculations() {
		}
	}

	/**
	 * The {@code ClickListener} class is responsible for responding to click events
	 * on the checker board component. It uses the coordinates of the mouse relative
	 * to the location of the checker board component.
	 */
	private class ClickListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			// Get the new mouse coordinates and handle the click
			Point m = GameBoard.this.getMousePosition();
			if (m != null) {
				handleClick(m.x, m.y);
			}
                       
		}
	}

	/**
	 * The {@code OptionListener} class responds to the components within the option
	 * panel when they are clicked/updated.
	 */
	private class HintButtonsListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			// No window to update or not a good turn
			if (window == null || (action < 3 && !(getCurrentPlayer() instanceof Computer))) {
				return;
			}
			// Handle the user action
			handleButton(e.getSource());
		}
	}
}
