package gui;



import javax.swing.UIManager;
import gameAndRules.*;
import java.io.IOException;
import translator.Translator;

public class Main {
        
        public static int player = 0;
        public static int hm = 1;   //Flag for setting HM or HH game - then make it automacally
        
	public static void main(String[] args) throws IOException {
		//Translator.readTheLogFile(0);
		//Translator.deleteDirectory (Translator.path);
		
		//Set the look and feel to the OS look and feel
		try {
			UIManager.setLookAndFeel(
					UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Player p1 = new Human(1);
		Player p2 = new Human(2);
		Board game = new Board (p1, p2);
		
                // Clean the db files 
                Runtime.getRuntime().exec("./ini_yokai.sh");
                
		// Create a window to display the checkers game
		GameWindow window = new GameWindow(game);
		window.setDefaultCloseOperation(GameWindow.EXIT_ON_CLOSE);
		window.setVisible(true);
		
		ControlPannel controlPan = new ControlPannel(window);
		controlPan.setVisible(true);
		window.getBoard().setUCP(controlPan.getUCP());
			
	}
}
