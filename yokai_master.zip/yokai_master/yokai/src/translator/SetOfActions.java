package translator;

public enum SetOfActions {
	COL, POS, MARK, ACT; 
	
	@Override
	public String toString() {
		switch (this) {
			case COL : return "col";
			case POS : return "pos";
			case MARK : return "mark";
			default : return "act";
		}
	}
	
	public static SetOfActions valueOf (String a, boolean caps) {
		if (!caps) return valueOf(a);
		switch (a) {
			case "col" : return COL;
			case "pos" : return POS;
			case "mark" : return MARK;
			default : return ACT;
		}
	}
}
