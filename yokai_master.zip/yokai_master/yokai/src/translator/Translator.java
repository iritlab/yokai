package translator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import cards.*;
import gameAndRules.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Translator {

	// Only change these 2 lines for the good call.
	public static final String pathForModule = "../sdata";
//	public static final String pathForModule =  "./src/log";

	public static final String path = pathForModule + "/";

	public static final String debugPath = "./src/log/";
	public static final String realColorFile = "real_colors.txt";
	public static final String iniSetFile = "01_ini_set.txt";

	public static final String logFile = "interface.txt";
        public static final String logFilefx = "interfacefx.txt";
        
        
	public static final String gensets = "../gensets/gensets";
	public static final String[] argGensets = {"../sdata/00_sets_same_color.txt"};         
        

	public static final String cat = "cat";
	public static final String[] argCat = {"../sdata/g4Cards_Sets.sets", "../sdata/goals_pc/g4Cards_PC.touist", ">", "../sdata/g4Cards_PC_final.tmp"};         
        
        //public static final String touist = "(cat ../sdata/g4Cards_Sets.sets; cat ../sdata/goals_pc/g4Cards_PC.touist) |";
	//public static final String[] argTouist = {"../precond_goals/touist.exe", "--sat", "--solve -"};       
        
        
	//public static final String touist = "../precond_goals/touist.exe";
        public static final String touist = "./touist.exe";
	public static final String[] argTouist = {"--solve"};         
        
        
        
                

	public static final String planner = "../planer/planer";
	public static final String[] argPlan = { "01_ini_state.txt", "02_actions.txt", "03_goal.txt" };

	public static final String berv = "../brev/brev";
	//public static final String[] argBerv = { "-e", "s", "score.txt", "00_delta0_base.txt", "interface.txt" };
        public static final String[] argBerv = { "-e", "s", "score.txt", "00_delta0_base.txt", "interfacefx.txt" };
        
	/*public static final String berv2 = "../brev/brev";
	//public static final String[] argBerv = { "-e", "s", "score.txt", "00_delta0_base.txt", "interface.txt" };
        public static final String[] argBerv2 = { "-e", "s", "score.txt", "00_delta0_base.txt", "interfacefx.txt" };        */

	public static final String translator = "../translator/_build/default/src/main.exe";
	public static final String[] argTrans = { "--solve", "../sdata/00_axioms_0.txt", "--limit","1","--states","1" };
        
        
	public static final String inference = "../inference/inference";
	public static final String[] argInfe = { "01_ini_state.txt"};        
        
	public static final String revision = "../revision/revision";
	public static final String[] argRevision = { "01_ini_state.txt"};             
        

	public static final String test = "md";
	public static final String[] argTest = { "testDir" };
        
        
        public static String finalAction = "";
        

	public static void deleteDirectory(String current) {
		File path = new File(current);
		if (path.exists()) {
			File[] files = path.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (files[i].isDirectory()) {
					deleteDirectory(path + "\\" + files[i]);
				}
				if (!files[i].getName().equals(logFile))
					files[i].delete();
				else {
					try {
						files[i].delete();
						files[i].createNewFile();
					} catch (Exception e) {
						System.out.println("Clear the " + logFile + " issue.");
					}
				}
			}
			System.out.println("Log File cleared.");
		} else {
			System.out.println("Path doesn't exist.");
		}
	}

	public static ArrayList<Card> turtleCourse(Board b) {
		ArrayList<Card> out = new ArrayList<>();
		Card current = null;
		boolean course = true;
		Card first = null;
		int x = 0, y = 0;
		int dirX = 1, dirY = 0;
		do {
			Card c = b.getCard(new Position(x, y));
			int dirXTemp = dirX;
			int dirYTemp = dirY;
			if (c == null) {
				if (first != null) {
					dirX = (Math.abs(dirXTemp) == 1) ? 0 : ((dirYTemp == 1) ? -1 : 1);
					dirY = (Math.abs(dirYTemp) == 1) ? 0 : ((dirXTemp == 1) ? 1 : -1);
				}
			} else {
				if (first == null) {
					first = c;
					out.add(c);
					dirX = 0;
					dirY = -1;
				} else if (current != null && c.equals(first)) {
					course = false;
				} else {
					dirX = (Math.abs(dirXTemp) == 1) ? 0 : ((dirYTemp == 1) ? 1 : -1);
					dirY = (Math.abs(dirYTemp) == 1) ? 0 : ((dirXTemp == 1) ? -1 : 1);
					if (!out.contains(c)) {
						out.add(c);
					}
					current = c;
				}
			}
			x += dirX;
			y += dirY;
			if (x == b.LENGTH) {
				x = 0;
				y += 1;
			}
		} while (course && (x < b.LENGTH && y < b.LENGTH));
		return out;
	}

	private static StringBuffer cardNeigh(Board b) {
		StringBuffer neigh = new StringBuffer();
                StringBuffer perim = new StringBuffer();
                int number = 1;
                perim.append("$GRIDOK = [");
		for (Card c : b.getCardsByNum()) {
			Position pos = c.getPos();
			int x = pos.getX();
			int y = pos.getY();
			Position[] neighbor = { new Position(x - 1, y), new Position(x + 1, y), new Position(x, y + 1),
					new Position(x, y - 1) };
			neigh.append("$NEIG(p_"+x+"_"+y+") = [");
                        
			boolean first = true;
			for (int i =0; i<4; i++) {
				if (b.isValidPos(neighbor[i]) && b.getCard(neighbor[i]) == null) {
					if (!first) neigh.append(", ");
                                        if (number != 1) perim.append(",");
                                        number++;
					first = false;
					neigh.append("p_"+neighbor[i].getX()+"_"+neighbor[i].getY());
                                        perim.append("p_"+neighbor[i].getX()+"_"+neighbor[i].getY());
				}
			}
                        if (first)
                            // JFD : 03/03/2022
                            //neigh.append("0");
                            neigh.append("x");
			neigh.append("]\n");
		}
                perim.append("]\n");
		return neigh;
	}
        


        
        
        /*
	private static StringBuffer gridPositionok(Board b) {
		ArrayList<Card> perimeter = turtleCourse(b);
		StringBuffer perim = new StringBuffer();
		int number = 1;
		perim.append("$GRID = [");
		for (Card c : perimeter) {
			if (number != 1)
				perim.append(",");
			perim.append("p_" + c.getPos().getX() + "_" + c.getPos().getY());
			number++;
		}
		perim.append("]\n");
		return perim;
	} 
        */
        
        
        
        
        
        
        
        
	private static StringBuffer cardNeighbor(Board b) {
		StringBuffer neigh = new StringBuffer();

		for (Card c : b.getCardsByNum()) {
			Position pos = c.getPos();
			int x = pos.getX();
			int y = pos.getY();
			Position[] neighbor = { new Position(x - 1, y), new Position(x + 1, y), new Position(x, y + 1),
					new Position(x, y - 1) };
			neigh.append("$NEIGBOR(p_"+x+"_"+y+") = [");
			boolean first = true;
			for (int i =0; i<4; i++) {
				/*if (b.isValidPos(neighbor[i]) && b.getCard(neighbor[i]) == null) {*/
					if (!first) neigh.append(", ");
					first = false;
					neigh.append("p_"+neighbor[i].getX()+"_"+neighbor[i].getY());
				/*}*/
			}
                        /*if (first)
                            neigh.append("0");*/
			neigh.append("]\n");
		}
		return neigh;
	}        
        

	private static StringBuffer cardPosition(Board b, boolean occ) {
		StringBuffer i = new StringBuffer();
		StringBuffer posIni = new StringBuffer();
		StringBuffer occupied = new StringBuffer();
		occupied.append("$OPOS($now) = [");
		i.append("$I = [");
		boolean afterI = false, afterO = false;
		for (Card c : b.getCardsByNum()) {
			if (afterI) {
				i.append(", ");
			}
			if (afterO) {
				occupied.append(", ");
			}
			afterI = true;
			int num = c.getNumCard();
			int x = c.getPos().getX();
			int y = c.getPos().getY();
			i.append("pos_" + num + "_p_" + x + "_" + y);
			posIni.append("$POSINI(" + num + ") = [p_" + x + "_" + y + "]\n");
                        //posIni.append("$POSINI(" + num + ") = p_" + x + "_" + y + "\n");
//			if (c.isHinted()) {
				afterO = true;
				occupied.append("p_" + x + "_" + y);
//			}
		}
		i.append("]\n");
		occupied.append("]\n");
		i.append(posIni);

		return (occ) ? occupied : i;
	}

	private static StringBuffer hintPosition(Board b) {
		StringBuffer hints = new StringBuffer();
		hints.append("$HINTS = [");
		ArrayList<HintCard> hintList = b.getAllHints();
		StringBuffer availableHints = new StringBuffer();
		StringBuffer activatedHints = new StringBuffer();
		StringBuffer hintColor = new StringBuffer();
                StringBuffer hintColorLine = new StringBuffer();
                StringBuffer hintColorImplies = new StringBuffer();
                
                
                
		availableHints.append("$AVHINTS = [");
		activatedHints.append("$ACHINTS = [");
		boolean oneAvailable = false;
		boolean oneActivated = false;
		for (HintCard h : hintList) {
			if (h.getNumOfTheCard() != 1)
				hints.append(", ");
			hints.append(h.getNumOfTheCard());

			if (h.getVisible() && h.getPlayed()) {
				if (oneActivated)
					activatedHints.append(", ");
				oneActivated = true;
				activatedHints.append(h.getNumOfTheCard());
			} else if (h.getVisible()) {
				if (oneAvailable)
					availableHints.append(", ");
				oneAvailable = true;
				availableHints.append(h.getNumOfTheCard());
			}
			if (h instanceof PriHint) {
				ColorEnum c = ((PriHint) h).getColor();
				String color = c.toString(false);
				hintColor.append("$HINT_COLOR(" + h.getNumOfTheCard() + ") = [" + color + "]\n");
                                hintColor.append("$HINT_COLORSS(" + h.getNumOfTheCard() + ",1) = [" + color + "]\n");
                                hintColorLine.append(color+"\n");
                                for (int i = 1; i <= 16; i++) {
                                    hintColorImplies.append("(mark_"+i+"_" + h.getNumOfTheCard() + "_t0 => col_"+i+"_" + color + "_t0)\n");
                                }  
                                
			} else {
				ColorEnum[] cList = (h instanceof DuoHint) ? ((DuoHint) h).getColors() : ((TrioHint) h).getColors();
				if (h instanceof DuoHint) {
                                    
					hintColor.append("$HINT_COLOR(" + h.getNumOfTheCard() + ") = [" + cList[0].toString(false) + ", "
							+ cList[1].toString(false) + "]\n");
                                        
                                        hintColorLine.append(cList[0].toString(false)+","+cList[1].toString(false)+"\n");
                                        
                                        
                                        
                                        hintColor.append("$HINT_COLORSS(" + h.getNumOfTheCard() + ",1) = [" + cList[0].toString(false) + "]\n");
                                        for (int i = 1; i <= 16; i++) {
                                            hintColorImplies.append("(mark_"+i+"_" + h.getNumOfTheCard() + "_t0 => col_"+i+"_" + cList[0].toString(false) + "_t0)\n");
                                        }                                        
                                        
                                        hintColor.append("$HINT_COLORSS(" + h.getNumOfTheCard() + ",2) = [" + cList[1].toString(false) + "]\n");
                                        for (int i = 1; i <= 16; i++) {
                                            hintColorImplies.append("(mark_"+i+"_" + h.getNumOfTheCard() + "_t0 => col_"+i+"_" + cList[1].toString(false) + "_t0)\n");
                                        }                                                                                
                                        
                                        
                                } else {
					hintColor.append("$HINT_COLOR(" + h.getNumOfTheCard() + ") = [" + cList[0].toString(false) + ", "
							+ cList[1].toString(false) + ", " + cList[2].toString(false) + "]\n");
					hintColorLine.append(cList[0].toString(false)+","+cList[1].toString(false)+","+ cList[2].toString(false)+"\n");                                        
                                        
                                        
                                        
                                        hintColor.append("$HINT_COLORSS(" + h.getNumOfTheCard() + ",1) = [" + cList[0].toString(false) + "]\n");
                                        for (int i = 1; i <= 16; i++) {
                                            hintColorImplies.append("(mark_"+i+"_" + h.getNumOfTheCard() + "_t0 => col_"+i+"_" + cList[0].toString(false) + "_t0)\n");
                                        }                                        
                                        
                                        hintColor.append("$HINT_COLORSS(" + h.getNumOfTheCard() + ",2) = [" + cList[1].toString(false) + "]\n");
                                        for (int i = 1; i <= 16; i++) {
                                            hintColorImplies.append("(mark_"+i+"_" + h.getNumOfTheCard() + "_t0 => col_"+i+"_" + cList[1].toString(false) + "_t0)\n");
                                        }                                                                                
                                        
                                        hintColor.append("$HINT_COLORSS(" + h.getNumOfTheCard() + ",3) = [" + cList[2].toString(false) + "]\n");
                                        for (int i = 1; i <= 16; i++) {
                                            hintColorImplies.append("(mark_"+i+"_" + h.getNumOfTheCard() + "_t0 => col_"+i+"_" + cList[2].toString(false) + "_t0)\n");
                                            
                                        }
                                }
			}
		}
                if (!oneAvailable)
                    availableHints.append("0");
                if (!oneActivated)
                    activatedHints.append("0");
		hints.append("]\n");
		availableHints.append("]\n");
		activatedHints.append("]\n");

		hints.append(availableHints);
		hints.append(activatedHints);
		hints.append(hintColor);
                
            try {
                BufferedWriter bwr = new BufferedWriter(new FileWriter(new File("../sdata/00_mark_implies.txt")));
                bwr.write(hintColorImplies.toString());
                bwr.flush();
                bwr.close();                
            } catch (IOException ex) {
                Logger.getLogger(Translator.class.getName()).log(Level.SEVERE, null, ex);
            }

            
            
            try {
                BufferedWriter bwr = new BufferedWriter(new FileWriter(new File("../sdata/00_hint_color.txt")));
                bwr.write(hintColorLine.toString());
                bwr.flush();
                bwr.close();                
            } catch (IOException ex) {
                Logger.getLogger(Translator.class.getName()).log(Level.SEVERE, null, ex);
            }
            
                


                FileReader file = null;
            try {
                file = new FileReader("../sdata/99_clock.txt");
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Translator.class.getName()).log(Level.SEVERE, null, ex);
            }
                BufferedReader buffer = new BufferedReader(file);
                //read the 1st line
              String line = null;
            try {
                line = buffer.readLine();
            } catch (IOException ex) {
                Logger.getLogger(Translator.class.getName()).log(Level.SEVERE, null, ex);
            }
                //Load the implies into the 00_delta0_base.txt
               if (line.equals("0")) {
                    try {                
                        Runtime.getRuntime().exec("./ini_yokai2.sh");
                    } catch (IOException ex) {
                        Logger.getLogger(Translator.class.getName()).log(Level.SEVERE, null, ex);
                    }
               }                
                
                
                
                
		return hints;
	}

        /*
	private static StringBuffer perimeterPosition(Board b) {
		ArrayList<Card> perimeter = turtleCourse(b);
		StringBuffer perim = new StringBuffer();
		int number = 1;
		perim.append("$PERIM = [");
		for (Card c : perimeter) {
			if (number != 1)
				perim.append(",");
			perim.append("p_" + c.getPos().getX() + "_" + c.getPos().getY());
			number++;
		}
		perim.append("]\n");
		return perim;
	}
        */
        

	private static StringBuffer perimeterPosition(Board b) {
		//StringBuffer neigh = new StringBuffer();
                StringBuffer perim = new StringBuffer();
                int number = 1;
                perim.append("$PERIM = [");
		for (Card c : b.getCardsByNum()) {
			Position pos = c.getPos();
			int x = pos.getX();
			int y = pos.getY();
			Position[] neighbor = { new Position(x - 1, y), new Position(x + 1, y), new Position(x, y + 1),
					new Position(x, y - 1) };
			//neigh.append("$NEIG(p_"+x+"_"+y+") = [");
                        
			//boolean first = true;
			for (int i =0; i<4; i++) {
				if (b.isValidPos(neighbor[i]) && b.getCard(neighbor[i]) == null) {
					//if (!first) neigh.append(", ");
                                        if (number != 1) perim.append(",");
                                        number++;
					//first = false;
					//neigh.append("p_"+neighbor[i].getX()+"_"+neighbor[i].getY());
                                        perim.append("p_"+neighbor[i].getX()+"_"+neighbor[i].getY());
				}
			}
                        //if (first)
                        //    neigh.append("0");
			// neigh.append("]\n");
		}
                perim.append("]\n");
		return perim;
	}        
        
        
        
        
        
        
        
        

	private static StringBuffer gridPosition(Board b) {
		ArrayList<Card> perimeter = turtleCourse(b);
		StringBuffer perim = new StringBuffer();
		int number = 1;
		perim.append("$GRID = [");
		for (Card c : perimeter) {
			if (number != 1)
				perim.append(",");
			perim.append("p_" + c.getPos().getX() + "_" + c.getPos().getY());
			number++;
		}
		perim.append("]\n");
		return perim;
	}
        

	private static StringBuffer createColorsFile(Board b) {
		StringBuffer colors = new StringBuffer();
		colors.append("$COLORS = [");
		boolean first = true;
		for (Card c : b.getCardsByNum()) {
			if (!first) {
				colors.append(", ");
			} else
				first = false;
			colors.append(c.getColor().toString(false));
		}
		colors.append("]\n");
		return colors;
	}

	public static void createCurrentGameState(Board b, int turn, int act, String name, boolean debug,
			boolean withColorFile) {
		int action = turn * 4 + act;
                String markcards = null;
                String mkcards,  mkcards_colors, hkcards;
		StringBuffer out = new StringBuffer();
		StringBuffer colors = new StringBuffer();

		colors = createColorsFile(b);
		out.append("$now = " + action + "\n");
		if (action < 56)
			out.append("$length = ($now + 1)\n");
		else
			out.append("$length = ($now + 0)\n");
		out.append(cardPosition(b, false));
		out.append(cardNeigh(b));
                out.append(cardNeighbor(b));
		out.append(hintPosition(b));
		out.append("$COLORS = [R,G,B,Y]\n");
                out.append("$ILEGALMOV = [x]\n");
                
                try {
                    //Read the 1th line of 00_sets_mark_cards.txt and check if there is more than one card,
                    // if so then : out.append("$MARKCARDS = [1,2,3]\n", siempre debe ir este SET pues sera llamada por el GOAL file !!;
                    markcards = Files.lines(Paths.get("../sdata/00_sets_mark_cards.txt")).skip(1 - 1).findFirst().get();
                    if (markcards.length()>0) 
                        out.append("$MARKCARDS = ["+markcards.substring(0,markcards.length() - 1)+"]\n");
                    else
                        out.append("$MARKCARDS = [99]\n");
                        out.append("$BORDERCARDS = [99]\n");
                        
                        
                        
                } catch (IOException ex) {
                    Logger.getLogger(Translator.class.getName()).log(Level.SEVERE, null, ex);
                }
                //out.append("$MARKCARDS = ["+markcards+"]\n");
                
                
                // 
		out.append(cardPosition(b, true));
		out.append(perimeterPosition(b));
                out.append(gridPosition(b));
                //out.append(gridPositionok(b));
                //out.append("$CARDS = [2,3,6,7,11,13]\n");
                out.append("$CARDS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]\n");
                
            try {                
                mkcards = Files.lines(Paths.get("../sdata/00_mk_cards.txt")).skip(1 - 1).findFirst().get();
                hkcards = Files.lines(Paths.get("../sdata/00_hk_cards.txt")).skip(1 - 1).findFirst().get();
                
                if (mkcards.length()>0)
                    //out.append(mkcards.substring(0,mkcards.length() - 1)+"]\n");
                    out.append(mkcards+"\n");
                if (hkcards.length()>0)
                    out.append(hkcards.substring(0,hkcards.length() - 1)+"]\n");
                
                
                
                /*File newFile = new File("../sdata/00_mk_cards_colors.txt");
                if (newFile.length() != 0) {
                    mkcards_colors = Files.lines(Paths.get("../sdata/00_mk_cards_colors.txt")).skip(1 - 1).findFirst().get();
                    if (mkcards_colors.length()>0)
                        out.append(mkcards_colors.substring(0,mkcards_colors.length() - 1)+"]\n");
                }*/
                

                FileInputStream fis=new FileInputStream("../sdata/00_mk_cards_colors.txt");       
                Scanner sc=new Scanner(fis);    //file to be scanned  
                //returns true if there is another line to read  
                while(sc.hasNextLine())                  
                {  
                    //System.out.println(sc.nextLine());      //returns the line that was skipped  
                    out.append(sc.nextLine()+"\n");
                }  
                
                
                
                
            } catch (IOException ex) {
                Logger.getLogger(Translator.class.getName()).log(Level.SEVERE, null, ex);
            }
                
            
            

            String typeOfPlayer = (b.getCurrentPlayer() instanceof Computer) ? "m" : "h";
            if (debug)
                    writeTheLogFile(out, debugPath + name, false);
            else
                    writeTheLogFile(out, path + name, false);
            Player currentPlayer = b.isP1Turn() ? b.getPlayer1() : b.getPlayer2();
            if (!(currentPlayer instanceof Computer) && withColorFile)
                    writeColorsLogFile(colors, debug);
	}

	public static void writeTheLogFile(StringBuffer s, String path, boolean append) {
		try {
			File file = new File(path);
			// Create the file if doesn't exist
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile(), append);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(s.toString());
			bw.close();
			fw.close();
//			System.out.println("Log File Updated");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void writeColorsLogFile(StringBuffer colors, boolean debug) {
		try {
			File file;
			if (debug)
				file = new File(debugPath + realColorFile);
			else
				file = new File(path + realColorFile);
			// Create the file if doesn't exist
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(colors.toString());
			bw.close();
			fw.close();
                        
                        // JFD : 2022/03/22
                        StringBuffer out = new StringBuffer();
                        StringBuffer outand = new StringBuffer();
                        StringBuffer outcol = new StringBuffer();
                        //String[] real_colors_list =colors.toString().split(";");
                        //StringBuffer colors = new StringBuffer();
                        //colors = createColorsFile(b);
                        List<String> items = Arrays.asList(colors.toString().substring(11,57).split("\\s*,\\s*"));

                        for (int i = 0; i < 16; i++) {
                                out.append("not tm_col_" + (i+1) + "_"+items.get(i)+"_t0\n");  
                        }
                        
                        /*for (int i = 0; i < 16; i++) {
                                out.append("not th_col_" + (i+1) + "_"+items.get(i)+"_t0\n");  
                        }*/
                        
                        for (int i = 0; i < 16; i++) {
                                out.append("not th_col_"+(i+1)+"_B_t0 and not th_col_"+(i+1)+"_G_t0 and not th_col_"+(i+1)+"_R_t0 and not th_col_"+(i+1)+"_Y_t0\n");  
                        }
                        
                        //
                        for (int i = 0; i < 16; i++) {
                                outand.append("not tm_col_" + (i+1) + "_"+items.get(i)+"_t0 and\n");  
                        }
                        
                        /*for (int i = 0; i < 16; i++) {
                                outand.append("not th_col_" + (i+1) + "_"+items.get(i)+"_t0 and\n");  
                        }*/

                        for (int i = 0; i < 16; i++) {
                                outand.append("not th_col_"+(i+1)+"_B_t0 and not th_col_"+(i+1)+"_G_t0 and not th_col_"+(i+1)+"_R_t0 and not th_col_"+(i+1)+"_Y_t0 and\n");  
                        }                        
                        
                        
                        for (int i = 0; i < 16; i++) {
                                outcol.append("col_" + (i+1) + "_"+items.get(i)+"_t\n");  
                        }                                                
                        
                        
                        
                        writeTheLogFile(out, path + "00_real_colors_delta0.txt", true);
                        writeTheLogFile(outand, path + "00_real_colors_delta0_and.txt", true);
                        writeTheLogFile(outcol, path + "02_actions_col_bk.txt", true);
                        
                        //02_actions_col_bk.txt
                        
                        // Clean the db files 
                        Runtime.getRuntime().exec("./ini_yokai3.sh");
                        
                        // ---        
                        
                        
//			System.out.println("Color file created");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void readTheLogFile(int turn) {
		File path = new File(Translator.path);
		File goodOne = null;
		if (path.exists()) {
			File[] files = path.listFiles();
			for (int i = 0; i < files.length && goodOne == null; i++) {
				String name = files[i].getName();
				// String[] splitted = name.split("_");
				// if (splitted[2].equals(String.valueOf(turn))) {
				if (name.equals("formula_example.txt")) {
					goodOne = files[i];
				}
			}
			if (goodOne == null) {
				System.out.println("File for the " + turn + "'th turn not found");
			} else {
				try {
					BufferedReader br = new BufferedReader(new FileReader(goodOne));
					String st;
					StringBuffer findLine = new StringBuffer();
					boolean find = false;
					int lineNumber = 1;
					while ((st = br.readLine()) != null) {
						st = st.replaceAll("\\(", " ");
						st = st.replaceAll("\\)", " ");
						st = st.replaceAll("=", " ");
						st = st.replaceAll("<", " ");
						st = st.replaceAll(">", " ");
						st = st.replaceAll("  ", " ");
						String[] split = st.split(" ");
						for (String s : split) {
							if (find)
								findLine.append(" " + s);
							if (s.equals("plusa") || s.equals(" plusa") || s.equals(" plusa ") || s.equals("plusa "))
								find = true;
						}
						find = false;
						lineNumber++;
					}
					br.close();
//					System.out.println("The line I've found\n" + findLine.toString());

				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("Error read log file for the turn " + turn);
				}
			}
		} else {
			System.out.println("Path doesn't exist.");
		}
	}

	public static void writeActionPerformed(Board b, int turn, int action, ArrayList<Object> list) {
		StringBuffer s = new StringBuffer();
                StringBuffer sfx = new StringBuffer();
                String actionfx = "(";
                
                
		SetOfActions kindOfAction = (SetOfActions) list.get(0);
		s.append((b.getCurrentPlayer() instanceof Computer) ? "m:" : "h:");
                sfx.append((b.getCurrentPlayer() instanceof Computer) ? "m:" : "h:");    
                
		s.append(kindOfAction.toString());
		s.append("_");
		s.append(String.valueOf((int) list.get(1)));
		s.append("_");
                
		if (kindOfAction == SetOfActions.COL) {
                        
                        String[] colArray = new String[]{ "R","G","Y","B"}; 
                        int i;
                        for (i = 0; i < colArray.length; i++) {
                        //actionfx = "th_col_"+String.valueOf((int) list.get(1))+"_"+colArray[i]+"_t" + (turn * 4 + action);
                        if (i == 3) {
                            actionfx = actionfx + "th_col_"+String.valueOf((int) list.get(1))+"_"+colArray[i]+"_t" + (turn * 4 + action)+"):1\n";
                            
                        } else {    actionfx = actionfx + "th_col_"+String.valueOf((int) list.get(1))+"_"+colArray[i]+"_t" + (turn * 4 + action)+ " or ";
                                    }
                        }
                        
                        sfx.append(actionfx);
                        // JFD: Aca graba la accion del Human - 27/02/2022
                        writeTheLogFile(sfx, path + logFilefx, true);
                        //sfx.delete(2, 7);
                        
                        
                        s.append((String) list.get(2) + "_");
                        s.append("t" + (turn * 4 + action) + ":1\n");                        
                        writeTheLogFile(s, path + logFile, true);                   
                        callModuleWithThread(berv, argBerv);                                                
                        
		} else if (kindOfAction == SetOfActions.POS) {
			int x = ((Position) list.get(2)).getX();
			int y = ((Position) list.get(2)).getY();
			s.append("p_" + x + "_" + y + "_");
                        s.append("t" + (turn * 4 + action) + " and ");
                        
                        s.append("tm_"+kindOfAction.toString());
                        s.append("_");
                        s.append(String.valueOf((int) list.get(1)));
                        s.append("_");                        
                        s.append("p_" + x + "_" + y + "_");
                        s.append("t" + (turn * 4 + action) + " and ");
                        
                        s.append("th_"+kindOfAction.toString());
                        s.append("_");
                        s.append(String.valueOf((int) list.get(1)));
                        s.append("_");                        
                        s.append("p_" + x + "_" + y + "_");
                        s.append("t" + (turn * 4 + action) + ":1\n");
                        
                        writeTheLogFile(s, path + logFile, true);
                        writeTheLogFile(s, path + logFilefx, true);
                        
                        //m:pos_3_p_11_12_t3 and tm_pos_3_p_11_12_t3 and th_pos_3_p_11_12_t3:0
                        //argTransr[0] =  "-e";
                        //argTransr[1] =  "s";  
                        Translator.callThisModule(4, action, Translator.revision, argTrans);
                        
                        //callModuleWithThread(berv, argBerv);
                        
                        
		} else if (kindOfAction == SetOfActions.MARK) {
			s.append(String.valueOf((int) list.get(2)) + "_");
                        s.append("t" + (turn * 4 + action) + " and ");
                        
                        s.append("tm_"+kindOfAction.toString());
                        s.append("_");
                        s.append(String.valueOf((int) list.get(1)));
                        s.append("_");
                        s.append(String.valueOf((int) list.get(2)));                        
                        s.append("_");
                        s.append("t" + (turn * 4 + action) + " and ");
                        
                        s.append("th_"+kindOfAction.toString());
                        s.append("_");
                        s.append(String.valueOf((int) list.get(1)));
                        s.append("_");
                        s.append(String.valueOf((int) list.get(2)));
                        s.append("_");
                        s.append("t" + (turn * 4 + action) + ":1\n");
                        
                        finalAction = s.toString();
                        
                        writeTheLogFile(s, path + logFile, true);
                        writeTheLogFile(s, path + logFilefx, true);
                        callModuleWithThread(berv, argBerv);                                                
		} else if (kindOfAction == SetOfActions.ACT) {
			//s.append(String.valueOf((int) list.get(1)) + "_");
                        s.append("t" + (turn * 4 + action) + " and ");
                        
                        s.append("tm_"+kindOfAction.toString());
                        s.append("_");
                        s.append(String.valueOf((int) list.get(1)));                       
                        s.append("_");
                        s.append("t" + (turn * 4 + action) + " and ");
                        
                        s.append("th_"+kindOfAction.toString());
                        s.append("_");
                        s.append(String.valueOf((int) list.get(1)));
                        s.append("_");
                        s.append("t" + (turn * 4 + action) + ":1\n");
                        
                        
                        writeTheLogFile(s, path + logFile, true);
                        writeTheLogFile(s, path + logFilefx, true);
                        callModuleWithThread(berv, argBerv);                        
		}
                
		//s.append("t" + (turn * 4 + action) + ":1\n");
		//writeTheLogFile(s, path + logFile, true);
                
                
                
                
		
                
                
                
                
	}

	public static ArrayList<String> readMachineActions() {
		File path = new File(Translator.path + Translator.logFile);
		ArrayList<String> actionPerformed = new ArrayList<>();
		if (path.exists()) {
			try {
				BufferedReader br = new BufferedReader(new FileReader(path));
				String st = "";
				while ((st = br.readLine()) != null) {
					String[] split = st.split(":");
					if (split[2].equals("1")) {
						String toAdd = split[0] + ":" + split[1];
						actionPerformed.add(toAdd);
					}
				}
				br.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("read log file error");
			}
		} else {
			System.out.println("Path doesn't exist.");
		}
		return actionPerformed;
	}

	public static void makeThisChecked(int time) {
		File path = new File(Translator.path + Translator.logFile);
		StringBuffer toReplace = new StringBuffer();
		if (path.exists()) {
			try {
				BufferedReader br = new BufferedReader(new FileReader(path));
				String st = "";
				while ((st = br.readLine()) != null) {
					String[] firstSplit = st.split(":");
					String[] split = firstSplit[1].split("_");
					if ((split[(split.length - 1)].split("t"))[1].equals(String.valueOf(time))) {
						toReplace.append(firstSplit[0] + ":" + firstSplit[1] + ":0\n");
					} else {
						toReplace.append(st + "\n");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("Path doesn't exist.");
		}
		writeTheLogFile(toReplace, Translator.path + logFile, false);
	}

	public static void callModuleWithThread(String what, String... args) {
		Thread t = new Thread(new Runnable() {
			public void run() {
				callThisModule(1, 1, what, args);
			}
		});
        		t.start();
	}

	public static int callThisModule(int turn, int action, String what, String... args) {
                int exitStatus = 0;
		try {
			List<String> command = new ArrayList<>();
			// TEST
			if (path.equals("./src/log/")) {
				command.add("java");
				command.add("-jar");
				command.add("test.jar");
				String[] split = argTrans[1].split("_");
				String toAdd = "";
				for (int i = 0; i < split.length - 1; i++)
					toAdd += split[i] + "_";
				toAdd = toAdd + (action + ".txt");
				command.add(toAdd);
			}
			// END OF TEST
			else {
				command.add(what);
				if (what.equals(translator)) {
					command.add(argTrans[0]);
					//command.add("../sdata/00_axioms" + (turn * 4 + action + 1) + ".touist");
                                        command.add("../sdata/00_axioms.touist");
                                        command.add(argTrans[2]);                   // --limit (accion)
                                        command.add(""+(turn * 4 + action + 1));    // nro_action
                                        command.add(argTrans[4]);                   // --states (goal)
                                        command.add(args[5]);                       // nro_meta    
                                        //command.add(argTrans[5]);
				}
				// { "01_ini_state.txt", "02_actions.txt", "03_goal.txt" };
				else if (what.equals(touist)) {
					//command.add(argTouist[0]);
					command.add(args[0]);
					command.add(argTouist[0]);
				}  
				else if (what.equals(gensets)) {
					//command.add(argTouist[0]);
					command.add(args[0]);
                                        command.add(args[1]);
					command.add(args[2]);
				} 
				else if (what.equals(berv)) {
					//command.add(argTouist[0]);
					command.add(args[0]);
                                        command.add(args[1]);
					command.add(argBerv[2]);
                                        command.add(argBerv[3]);
                                        command.add(argBerv[4]);
				}                                  
                                
				else if (what.equals(inference)) {
					//command.add(argTouist[0]);
                                        
                                        BufferedReader input = new BufferedReader(new FileReader("../sdata/interface.txt"));
                                        String lastLine, sCurrentLine = "";
                                        
                                        while ((sCurrentLine = input.readLine()) != null) 
                                        {
                                            System.out.println(sCurrentLine);
                                            //lastLine = sCurrentLine;
                                            finalAction = sCurrentLine;
                                        }                                        
                                        
					command.add(argInfe[0]);
                                        
                                        finalAction = finalAction.substring(finalAction.indexOf(":") + 1);
                                        finalAction = finalAction.substring(0, finalAction.indexOf(":"));
                                        command.add(finalAction);
				}                                  
                                //20/04/2022
                                
				else if (what.equals(revision)) {
					//command.add(argTouist[0]);
                                        
                                        BufferedReader input = new BufferedReader(new FileReader("../sdata/interface.txt"));
                                        String lastLine, sCurrentLine = "";
                                        
                                        while ((sCurrentLine = input.readLine()) != null) 
                                        {
                                            System.out.println(sCurrentLine);
                                            //lastLine = sCurrentLine;
                                            finalAction = sCurrentLine;
                                        }                                        
                                        
					command.add(argInfe[0]);
                                        
                                        finalAction = finalAction.substring(finalAction.indexOf(":") + 1);
                                        finalAction = finalAction.substring(0, finalAction.indexOf(":"));
                                        command.add(finalAction);
				}                                    
                                
                                
                                
                                
				else if (what.equals(planner)) {
					command.add(argPlan[0]);
					command.add("02_actions_t" + (turn * 4 + action + 1) + ".txt");
                                     // Aca puedo leer un txt file y ver que goal emplee en el plan anterior
					command.add(argPlan[2]);
                                        // Aca grabar en un file tmp la prioridad del Goal usado, entonces la prox vez se sabra cual es la
                                        // siguiente y se tiene que grabar luego, asi ya no se tiene que modificar NADA de este metodo
				} else {
					for (String s : args)
						command.add(s);
				}
			}

			Runtime runTime = Runtime.getRuntime();
			System.out.println("I'm calling : " + what);
			ProcessBuilder pb = new ProcessBuilder(command);
			String basePath = new File("").getAbsolutePath();
//            int lastIndxDot = basePath.lastIndexOf('/');
//            String basePath0 = basePath.substring(0, lastIndxDot);
			System.out.println("Current directory : " + basePath);
//            System.out.println("Parent directory : "+ basePath0);
			// pb.directory(new File(pathForModule));
			pb.directory(new File(basePath));
			pb.redirectErrorStream(true);
			pb.inheritIO();
			Process process = pb.start();
			try {
				BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				String line = "";
				try {
					while ((line = reader.readLine()) != null) {
						System.err.println("La ligne : " + line);
					}
				} finally {
					reader.close();
				}
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
			//process.waitFor(120000, TimeUnit.MILLISECONDS);
                        process.waitFor(1000000, TimeUnit.MILLISECONDS);
                        //process.waitFor();
                        exitStatus = process.exitValue();
			System.out.println("[" + what + "] has ended its computation.");
		} catch (Exception e) {
			e.printStackTrace();
		}
                
                return exitStatus;
	}
        
       
}
