//home//jorge//sw//code//planer//planer -e s 01_model.txt 01_actions.txt 01_goal.txt
