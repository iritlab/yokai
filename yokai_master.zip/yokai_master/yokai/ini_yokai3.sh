sed -i 1,32d ../sdata/00_delta0_base.txt
sed -i 1,32d ../sdata/00_delta0_base_and.txt
cat ../sdata/00_real_colors_delta0.txt ../sdata/00_delta0_base.txt >> tmp && mv tmp ../sdata/00_delta0_base.txt
cat ../sdata/00_real_colors_delta0_and.txt ../sdata/00_delta0_base_and.txt >> tmp && mv tmp ../sdata/00_delta0_base_and.txt
