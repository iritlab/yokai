java -jar yokaiGame.jar
