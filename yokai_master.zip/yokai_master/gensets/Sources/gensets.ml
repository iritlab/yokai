open Printf
open Seq


class t  (setssamecolor:string) (encoding : int) =
object (self)


method search = (* notimed_search *)

let command cmd =
  Sys.command cmd
in


let filesetssamecolor = "../sdata/"^setssamecolor in
let filesetssamecolorvar = "../sdata/"^setssamecolor^".var" in
let filesetssamecolormix = "../sdata/"^setssamecolor in
let filesetssamecolormixfiltered = "../sdata/"^setssamecolor^".filter" in
let filesetssamecolortotal = "../sdata/"^setssamecolor^".total" in
let filesetssamecolorfull = "../sdata/"^setssamecolor^".full" in
(*let filesetssamecolorout = "../sdata/"^setssamecolor^".out" in*)
let filesetssamecolorout = "../sdata/"^setssamecolor^".out" in
(* Comment for prepare expo - 2121/11/24 *)
(*let filesetssamecolorhint = "../sdata/"^setssamecolor^"hint.txt" in*)
(* 20/02/2022 *)
let filesetssamecolorhint = "../sdata/00_sets_same_colorhint.txt" in

(*00_sets_same_colorhint.txt*)


let replace input output =
  Str.global_replace (Str.regexp_string input) output in  


Printf.printf "FILEMODEL ==> %s \n" filesetssamecolor;

flush stdout; flush stderr;
Utils.print "Select TouIST\n";
flush stdout; flush stderr;
let returncode = (command "./main.exe --version") in
Utils.print "\n";

flush stdout; flush stderr;
if returncode == 0 then Utils.print ""
else begin Utils.eprint "[Error %d] please install TouIST with : brew install touist\n" returncode; exit returncode; end;



let rec extract k list =
  if k <= 0 then [ [] ]
  else match list with
       | [] -> []
       | h :: tl ->
          let with_h = List.map (fun l -> h :: l) (extract (k-1) tl) in
          let without_h = extract k tl in
          with_h @ without_h in



(** START SATPLAN-SOLVE - JFDX 20200408 **)
if (encoding = 1) then  (* option : s *)
begin
Printf.printf "ENCODING == 1 \n";

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in


let rec append l1 l2 =
    match l1 with
    | h :: t -> h :: append t l2
    | [] -> l2     in
  


let rec insert_at_end l i =
    match l with
      [] -> [i]
    | h :: t -> h :: (insert_at_end t i) in


let flatten l =
  let rec loop res = function
    | [] -> List.rev res
    | h::t -> loop (List.rev_append h res) t
  in
    loop [] l in   


(* Ini - Algoritmo para hayar permutaciones *)
let rec insert x lst =
  match lst with
  | [] -> [[x]]
  | h::t -> 
    (x::lst) :: (List.map (fun el -> h::el) (insert x t)) in




let rec extract k list =
      if k <= 0 then [ [] ]
      else match list with
          | [] -> []
          | h :: tl ->
              let with_h = List.map (fun l -> h :: l) (extract (k-1) tl) in
              let without_h = extract k tl in
              with_h @ without_h in

let rec perm lst =
  match lst with
  | [] -> [lst]
  | h::t -> 
    List.flatten (List.map (insert h) (perm t)) in
(* Fin - Algoritmo para hayar permutaciones *)

let plan() = 


let get_action_obs() =
  let l = (lines_from_files filesetssamecolor) in
    List.iter (printf "ACA ESTAN LOS SETS $$$ : %s \n") l;
    in
    get_action_obs();
       



(*** JFD: 02/03/2022 - Add for generate the set of actions for movement (../gensets/genactions/gen_act_3.txt) ***************)
let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "cat %s > %s" filesetssamecolor filesetssamecolorvar)   in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();  


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/^\s*.//g' -e 's/|/\\$CARDSONE = [/g' -e 's/.$//' -e 's/;/,/g'  -e 's/$/]/' %s" filesetssamecolorvar) in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();  

let string_of_command4 () =
        Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
        let tmp_file = "planerdata/99_tmp.txt" in
        let _ = Sys.command (Printf.sprintf "cat %s %s %s > %s" "../sdata/01_ini_set.txt" filesetssamecolorvar "../gensets/genactions/gen_act_3.txt" "../sdata/02_gen_actions.txt")   in
        let chan = open_in tmp_file in
                    close_in chan
            in
            string_of_command4();        

let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "./touist.exe ../sdata/02_gen_actions.txt --show > ../sdata/02_gen_actions.txt.show")   in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/⋀ /\n/g' -e 's/))))))/)/g' -e 's/))/)/g' -e 's/(((/(/g' -e 's/((/(/g' -e 's/(pos/pos/g' -e 's/))/)/g' -e 's/,/_/g' %s" "../sdata/02_gen_actions.txt.show") in*)
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/))))))/)/g' -e 's/))/)/g' -e 's/(((/(/g' -e 's/((/(/g' -e 's/(pos/pos/g' -e 's/))/)/g' -e 's/,/_/g' %s" "../sdata/02_gen_actions.txt.show") in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();  


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/⋀ /\\n/g' %s" "../sdata/02_gen_actions.txt.show") in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();       


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/_/_t/4' -e 's/ //g' -e 's/(/\_/g' -e 's/)//g' ../sdata/02_gen_actions.txt.show") in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();   
      
      
(* Read the file: 99_clock.txt get the time and add 1*)

let clock = List.nth (lines_from_files "../sdata/99_clock.txt") 0 in
let clock2 = ref 0 in
clock2 := (int_of_string clock) + 1;

let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "cat %s > ../sdata/02_actions_t%i.txt" "../sdata/02_gen_actions.txt.show" !clock2) in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();         

(*
let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/ //g' -e 's/(/\_/g' -e 's/)//g' ../sdata/02_gen_actions.txt.show") in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();             
*)


  (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/\_/\_t/4' -e 's/ //g' -e 's/(/\_/g' -e 's/)//g'' ../sdata/02_gen_actions.txt.show") in*)      


(*
touistcode2 := (command (Printf.sprintf "./touist.exe ../sdata/02_gen_actions.txt --show > ../sdata/02_gen_actions.txt.show");
*)


(******************)




let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/|/ /g' -e 's/.$//' %s" filesetssamecolor)   in
  let chan = open_in tmp_file in
             close_in chan
      in
      string_of_command4();     

(* Aca comienza a procesar los sets filtrados empezando por el que tiene mas cards y genera las permutaciones *)      
let get_action_obs_filter() =
  let a = ref 0 in 
  let l2 = (lines_from_files filesetssamecolor) in

    List.iter (printf "ACA ESTAN LOS SETS FILTERED $$$ : %s \n") l2;



    while (!a <  List.length l2 ) do
      Printf.printf "INDEXXXXXXXXXXXXXXXXXXX = %i  \n" !a;
        let b = ref 0 in 
        let size = String.length(List.nth l2 !a) in
            
        (*if (size = 4) then begin*)
        let color =   String.sub  (List.nth l2 !a) 0 1 in
        (* Extract the string with the cards*)
        let set_single =   String.sub  (List.nth l2 !a) 2 (size-2) in
        (* Load the string into an array *)
        let nro_cars = (Str.split (Str.regexp "[^0-9]+") set_single) in
        Printf.printf "NUMERO DE CARTAS = %i  \n" (List.length nro_cars);



        (* Si el numero de cards en el set = 4 *)
        if ((List.length nro_cars) = 4) then
        begin
            Printf.printf "SETS 444444444444444444444444444 = %s  \n" set_single;
            (* Using the function : perm *)
            let sets_full = flatten (perm (List.map int_of_string (Str.split (Str.regexp "[^0-9]+") set_single))) in
              let _ = Sys.command (Printf.sprintf "touch ../sdata/generated_sets4_%i_plus.sets" !a)   in
              while (!b < List.length sets_full ) do
                let string_of_command5 () =
                let tmp_file = filesetssamecolor in
                let _ = Sys.command (Printf.sprintf "echo '%i' >> ../sdata/generated_sets4_%i.sets" (List.nth sets_full !b) !a)   in
                let chan = open_in tmp_file in
                close_in chan
                in
                string_of_command5();  
                b := !b + 1;
              done ;
        
              (* Aca procesar los elementos y armar los sets x color *)      
              (*let l2 = (lines_from_files (Printf.sprintf "generated_sets4_%i.txt" !a)) in  *)
              (*let get_action_obs_filter2() =              *)
              let l2 = (lines_from_files (Printf.sprintf "../sdata/generated_sets4_%i.sets" !a)) in  
              Printf.printf "l2 size = %i : \n" (List.length l2);
              let c = ref 0 in 
              let set =  ref [] in 
              let set4 =  ref [] in
              let set4x =  ref [] in
              while (!c < List.length l2) do   
                  set := insert_at_end  !set (List.nth l2 !c);
                  if ((!c + 1) mod 4 = 2) then begin
                                                  set4 := insert_at_end  !set (List.nth l2 !c);
                                                  set4x := !set4;
                                                end;   
                  if ((!c + 1) mod 4 = 3) then begin
                                                  set4 := insert_at_end  !set4 (List.nth l2 !c);
                                                  set4x := !set4;
                                                end;
                  if ((!c + 1) mod 4) = 0 then
                    begin
                      set4 := insert_at_end  !set4 (List.nth l2 (!c - 1));
                      set4x := insert_at_end !set4x (List.nth l2 (!c - 2));
                      set4 := insert_at_end  !set4 (List.nth l2 !c);
                      set4x := insert_at_end  !set4x (List.nth l2 !c);
                      Printf.printf "O(%s,4,%i) = %s \n" color ((!c + 1) / 4) (String.concat ";" !set);
                      Printf.printf "X(%s,4,%i) = %s \n" color ((!c + 1) / 4) (String.concat ";" !set4);
                      Printf.printf "X(%s,4,%i) = %s \n" color (((!c + 2) / 4) + 24) (String.concat ";" !set4x);
                      (*List.iter (printf "FINALES === : %s \n") !set;*)
                      let tmp_file = filesetssamecolor in
                      let _ = Sys.command (Printf.sprintf "echo '$X(%s,4,%i) = %s' >> ../sdata/generated_sets4_%i_final.sets" color ((!c + 1) / 4) (String.concat ";" !set4) !a)   in
                      let _ = Sys.command (Printf.sprintf "echo '$X(%s,4,%i) = %s' >> ../sdata/generated_sets4_%i_plus.sets" color (((!c + 2) / 4) + 24) (String.concat ";" !set4x) !a)   in
                      let chan = open_in tmp_file in
                      close_in chan;

                      set := [];
                      set4 := []
                    end;
                c := !c + 1;
              done;  
              
              (* Aca debo de hacer los reemplazos para darles el formato $X(G,4,1) = [[2,3],[3,9],[9,5]] a los sets definidos en el archivo anterior *)
              let string_of_command4 () =
                let tmp_file = "planerdata/99_tmp.txt" in
                let _ = Sys.command (Printf.sprintf "sed -i -e 's/;/],[/2' -e 's/;/],[/3' -e 's/= /= [[/g' -e 's/$/]]/g' -e 's/;/,/g' ../sdata/generated_sets4_%i_final.sets" !a)   in
                let _ = Sys.command (Printf.sprintf "sed -i -e 's/;/],[/2' -e 's/;/],[/3' -e 's/= /= [[/g' -e 's/$/]]/g' -e 's/;/,/g' ../sdata/generated_sets4_%i_plus.sets" !a)   in
                let chan = open_in tmp_file in
                           close_in chan
                in
                string_of_command4(); 

              (* Aca debo generar los sets $X(G,2,1) = [[2,3], [5,9]] solo haciendo un reemplazo en el archivo anterior *)
              let string_of_command4 () =
                let tmp_file = "planerdata/99_tmp.txt" in
                let _ = Sys.command (Printf.sprintf "sed -e 's/\],\[.*\],\[/],[/g' -e 's/X(G,4,/X(G,2,/g' -e 's/X(Y,4,/X(Y,2,/g' -e 's/X(B,4,/X(B,2,/g' -e 's/X(R,4,/X(R,2,/g' ../sdata/generated_sets4_%i_final.sets > ../sdata/generated_sets2_%i_final.sets" !a !a)   in
                let chan = open_in tmp_file in
                           close_in chan
                in
                string_of_command4();                     


              let string_of_command4 () =
                let tmp_file = "planerdata/99_tmp.txt" in
                let _ = Sys.command (Printf.sprintf "cat ../sdata/generated_sets4_%i_plus.sets >> ../sdata/generated_sets4_%i_final.sets" !a !a)   in
                let chan = open_in tmp_file in
                            close_in chan
                in
                string_of_command4(); 





              (* Aca debo generar los sets $X(G,3,1) - Generar los Set3 *)
              (* Using the function : extract *)
              let reslst2 = (extract 3 nro_cars) in
              
              let d = ref 0 in 
              let set3 =  ref [] in
              while (!d < List.length reslst2) do   
                let set3b  = flatten (perm (List.nth reslst2 !d)) in
                set3 :=  (append !set3 set3b);
                d := !d + 1;
              done;     
              List.iter (printf "FINALES SET 3 - === : %s \n") (!set3);           
            
              let e = ref 0 in
              while (!e < List.length !set3) do             
                let string_of_command5 () =
                let tmp_file = filesetssamecolor in
                let _ = Sys.command (Printf.sprintf "echo '%s' >> ../sdata/generated_sets3_%i.sets" (List.nth (!set3) !e) !a) in
                let chan = open_in tmp_file in
                close_in chan
                in
                string_of_command5();  
                e := !e + 1;
              done;


              (* Aca procesar los elementos y armar los sets 3cards x color *)      
              let l2b = (lines_from_files (Printf.sprintf "../sdata/generated_sets3_%i.sets" !a)) in  
              Printf.printf "l2b size = %i : \n" (List.length l2b);
              let c = ref 0 in 
              let set =  ref [] in 
              let set3 =  ref [] in
              while (!c < List.length l2b) do   
                  (*set := insert_at_end  !set (List.nth l2b !c);*)
                  if ((!c + 1) mod 3 = 1) then set3 := insert_at_end  !set (List.nth l2b !c);
                  if ((!c + 1) mod 3 = 2) then set3 := insert_at_end  !set3 (List.nth l2b !c);
                  if ((!c + 1) mod 3) = 0 then
                    begin
                      set3 := insert_at_end  !set3 (List.nth l2b (!c - 1));
                      set3 := insert_at_end  !set3 (List.nth l2b !c);
                      Printf.printf "X(%s,3,%i) = %s \n" color ((!c + 1) / 3) (String.concat ";" !set);
                      Printf.printf "X(%s,3,%i) = %s \n" color ((!c + 1) / 3) (String.concat ";" !set3);
                      let tmp_file = filesetssamecolor in
                      let _ = Sys.command (Printf.sprintf "echo '$X(%s,3,%i) = %s' >> ../sdata/generated_sets3_%i_final.sets" color ((!c + 1) / 3) (String.concat ";" !set3) !a)   in
                      let chan = open_in tmp_file in
                      close_in chan;

                      set := [];
                      set3 := []
                    end;
                c := !c + 1;
              done;  


              (* Aca debo de hacer los reemplazos para darles el formato $X(G,3,1) = [[2,3],[3,9],[9,5]] a los sets definidos en el archivo anterior *)
              let string_of_command4 () =
              let tmp_file = "planerdata/99_tmp.txt" in
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/;/],[/2' -e 's/= /= [[/g' -e 's/$/]]/g' -e 's/;/,/g' ../sdata/generated_sets3_%i_final.sets" !a)   in
              let chan = open_in tmp_file in
                         close_in chan
              in
                  string_of_command4(); 



              (* Joining all the sets (4,2,3) togheter in one single final file = ../sdata/g4Cards_Sets.sets *)
              let string_of_command4 () =
              let tmp_file = "planerdata/99_tmp.txt" in
              let _ = Sys.command (Printf.sprintf "cat ../sdata/generated_sets4_%i_final.sets  ../sdata/generated_sets3_%i_final.sets ../sdata/generated_sets2_%i_final.sets > %s" !a !a !a "../sdata/g4Cards_Sets.sets."^color)   in
              let chan = open_in tmp_file in
                          close_in chan
              in
                  string_of_command4();                   









                  
              Printf.printf "Single Action - Planer BEFORE INSERTING = %s  \n" set_single;
              let string_of_command5 () =
              let tmp_file = filesetssamecolor in
              let _ = Sys.command (Printf.sprintf "echo '$G4CARDS = [%s]' >> ../sdata/g4Cards_Sets.sets.%s" set_single color)   in
              let chan = open_in tmp_file in
              close_in chan
              in
                    string_of_command5();       
                    
                    
              let string_of_command5 () =
                let tmp_file = filesetssamecolor in
                let _ = Sys.command (Printf.sprintf "echo '$G4COLOR = %s' >> ../sdata/g4Cards_Sets.sets.%s" color color)   in
                let chan = open_in tmp_file in
                close_in chan
                in
                      string_of_command5();   








              let string_of_command4 () =
              Printf.printf "\n DENTRO DEL reemplazo ; x , : \n";
              let tmp_file = filesetssamecolor in
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/;/,/g' %s" "../sdata/g4Cards_Sets.sets."^color)   in
              let chan = open_in tmp_file in
                    close_in chan
              in
                    string_of_command4(); 


              let string_of_command4 () =
              Printf.printf "\n DENTRO DEL reemplazo = [0] x = [x] : \n";
              let tmp_file = filesetssamecolor in
              (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/) = \[0]/) = \[x]/g' %s" "../sdata/01_ini_set.txt")   in*)
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/) = \\[0]/) = \\[x]/g' %s" "../sdata/01_ini_set.txt")   in
              let chan = open_in tmp_file in
                      close_in chan
              in
                      string_of_command4(); 

                       
        end;


        (* Si el numero de cards en el set = 4 *)
        if ((List.length nro_cars) = 3) then
        begin
          Printf.printf "SETS 33333333333333333333333 = %s  \n" set_single;
          (* Using the function : perm *)
          let sets_full = flatten (perm (List.map int_of_string (Str.split (Str.regexp "[^0-9]+") set_single))) in
            while (!b < List.length sets_full ) do
              let string_of_command5 () =
              let tmp_file = filesetssamecolor in
              let _ = Sys.command (Printf.sprintf "echo '%i' >> ../sdata/generated_sets3_%i.sets" (List.nth sets_full !b) !a)   in
              let chan = open_in tmp_file in
              close_in chan
              in
              string_of_command5();  
              b := !b + 1;
            done ;
      
            (* Aca procesar los elementos y armar los sets x color *)      
            (*let l2 = (lines_from_files (Printf.sprintf "generated_sets4_%i.txt" !a)) in  *)
            (*let get_action_obs_filter2() =              *)
            let l2 = (lines_from_files (Printf.sprintf "../sdata/generated_sets3_%i.sets" !a)) in  
            Printf.printf "l2 size = %i : \n" (List.length l2);
            let c = ref 0 in 
            let set =  ref [] in 
            let set4 =  ref [] in
            while (!c < List.length l2) do   
                set := insert_at_end  !set (List.nth l2 !c);
                if ((!c + 1) mod 3 = 2) then set4 := insert_at_end  !set (List.nth l2 !c);
                (*if ((!c + 1) mod 3 = 2) then set4 := insert_at_end  !set4 (List.nth l2 !c);*)
                if ((!c + 1) mod 3) = 0 then
                  begin
                    (*set4 := insert_at_end  !set4 (List.nth l2 (!c - 1));*)
                    set4 := insert_at_end  !set4 (List.nth l2 !c);
                    Printf.printf "X(%s,3,%i) = %s \n" color ((!c + 1) / 3) (String.concat ";" !set);
                    Printf.printf "X(%s,3,%i) = %s \n" color ((!c + 1) / 3) (String.concat ";" !set4);
                    (*List.iter (printf "FINALES === : %s \n") !set;*)
                    let tmp_file = filesetssamecolor in
                    let _ = Sys.command (Printf.sprintf "echo '$X(%s,3,%i) = %s' >> ../sdata/generated_sets3_%i_final.sets" color ((!c + 1) / 3) (String.concat ";" !set4) !a)   in
                    let chan = open_in tmp_file in
                    close_in chan;

                    set := [];
                    set4 := []
                  end;
              c := !c + 1;
            done;  
            
            (* $X(Color,3,1)  *)
            (* Aca debo de hacer los reemplazos para darles el formato $X(G,3,1) = [[2,3],[3,9],[9,5]] a los sets definidos en el archivo anterior *)
            let string_of_command4 () =
              let tmp_file = "planerdata/99_tmp.txt" in
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/;/],[/2' -e 's/;/],[/3' -e 's/= /= [[/g' -e 's/$/]]/g' -e 's/;/,/g' ../sdata/generated_sets3_%i_final.sets" !a)   in
              let chan = open_in tmp_file in
                          close_in chan
              in
              string_of_command4(); 


            (* $X(Color,2,1)  *)
            (* Aca debo generar los sets $X(G,2,1) - Generar los Set3 *)
            (* Using the function : extract *)
              (* Aca debo generar los sets $X(G,3,1) - Generar los Set3 *)
              (* Using the function : extract *)
              let reslst2 = (extract 2 nro_cars) in
              
              let d = ref 0 in 
              let set3 =  ref [] in
              while (!d < List.length reslst2) do   
                let set3b  = flatten (perm (List.nth reslst2 !d)) in
                set3 :=  (append !set3 set3b);
                d := !d + 1;
              done;     
              List.iter (printf "FINALES SET 2222222222222222222 - === : %s \n") (!set3);           
            
              let e = ref 0 in
              while (!e < List.length !set3) do             
                let string_of_command5 () =
                let tmp_file = filesetssamecolor in
                let _ = Sys.command (Printf.sprintf "echo '%s' >> ../sdata/generated_sets2_%i.sets" (List.nth (!set3) !e) !a) in
                let chan = open_in tmp_file in
                close_in chan
                in
                string_of_command5();  
                e := !e + 1;
              done;


              (* Aca procesar los elementos y armar los sets 3cards x color *)      
              let l2b = (lines_from_files (Printf.sprintf "../sdata/generated_sets2_%i.sets" !a)) in  
              Printf.printf "l2b size = %i : \n" (List.length l2b);
              let c = ref 0 in 
              let set =  ref [] in 
              let set3 =  ref [] in
              while (!c < List.length l2b) do   
                  (*set := insert_at_end  !set (List.nth l2b !c);*)
                  if ((!c + 1) mod 2 = 1) then (*set3 := insert_at_end  !set (List.nth l2b !c);*)
                  (*if ((!c + 1) mod 2 = 2) then set3 := insert_at_end  !set3 (List.nth l2b !c);*)
                  (*if ((!c + 1) mod 2) = 0 then*)
                    begin
                      set3 := insert_at_end  !set3 (List.nth l2b !c);
                      set3 := insert_at_end  !set3 (List.nth l2b (!c + 1));
                      Printf.printf "X(%s,2,%i) = %s \n" color (((!c + 1) / 2)+1) (String.concat ";" !set3);
                      (*Printf.printf "X(%s,3,%i) = %s \n" color ((!c + 1) / 2) (String.concat ";" !set3);*)
                      let tmp_file = filesetssamecolor in
                      let _ = Sys.command (Printf.sprintf "echo '$X(%s,2,%i) = %s' >> ../sdata/generated_sets2_%i_final.sets" color (((!c + 1) / 2)+1) (String.concat ";" !set3) !a)   in
                      let chan = open_in tmp_file in
                      close_in chan;

                      set := [];
                      set3 := []
                    end;
                c := !c + 1;
              done;  


              (* Aca debo de hacer los reemplazos para darles el formato $X(G,3,1) = [[2,3],[3,9],[9,5]] a los sets definidos en el archivo anterior *)
              let string_of_command4 () =
              let tmp_file = "planerdata/99_tmp.txt" in
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/;/],[/2' -e 's/= /= [[/g' -e 's/$/]]/g' -e 's/;/,/g' ../sdata/generated_sets2_%i_final.sets" !a)   in
              let chan = open_in tmp_file in
                         close_in chan
              in
                  string_of_command4(); 



              (* Joining all the sets (4,2,3) togheter in one single final file = ../sdata/g4Cards_Sets.sets *)
              let string_of_command4 () =
              let tmp_file = "planerdata/99_tmp.txt" in
              let _ = Sys.command (Printf.sprintf "cat ../sdata/generated_sets3_%i_final.sets ../sdata/generated_sets2_%i_final.sets > %s" !a !a "../sdata/g3Cards_Sets.sets."^color)   in
              let chan = open_in tmp_file in
                          close_in chan
              in
                  string_of_command4();                   

                  
              Printf.printf "Single Action - Planer BEFORE INSERTING = %s  \n" set_single;
              let string_of_command5 () =
              let tmp_file = filesetssamecolor in
              let _ = Sys.command (Printf.sprintf "echo '$G3CARDS = [%s]' >> ../sdata/g3Cards_Sets.sets.%s" set_single color)   in
              let chan = open_in tmp_file in
              close_in chan
              in
                    string_of_command5();         
                    
              let string_of_command5 () =
                let tmp_file = filesetssamecolor in
                let _ = Sys.command (Printf.sprintf "echo '$G3COLOR = %s' >> ../sdata/g3Cards_Sets.sets.%s" color color)   in
                let chan = open_in tmp_file in
                close_in chan
                in
                      string_of_command5();                       

              let string_of_command4 () =
              Printf.printf "\n DENTRO DEL reemplazo ; x , : \n";
              let tmp_file = filesetssamecolor in
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/;/,/g' %s" "../sdata/g3Cards_Sets.sets."^color)   in
              let chan = open_in tmp_file in
                    close_in chan
              in
                    string_of_command4(); 


              let string_of_command4 () =
              Printf.printf "\n DENTRO DEL reemplazo = [0] x = [x] : \n";
              let tmp_file = filesetssamecolor in
              (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/) = \[0]/) = \[x]/g' %s" "../sdata/01_ini_set.txt")   in*)
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/) = \\[0]/) = \\[x]/g' %s" "../sdata/01_ini_set.txt")   in
              let chan = open_in tmp_file in
                      close_in chan
              in
                      string_of_command4(); 

        end;
        





        
        

        









        

      a := !a + 1; 

    done ;    
    
                      
  in
  get_action_obs_filter(); 

in

plan();

end;





(**************************)
(**************************)




if (encoding = 2) then  (* option : m *)
begin
Printf.printf "ENCODING == 2 \n";

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in


let rec append l1 l2 =
    match l1 with
    | h :: t -> h :: append t l2
    | [] -> l2     in
  


let rec insert_at_end l i =
    match l with
      [] -> [i]
    | h :: t -> h :: (insert_at_end t i) in


let flatten l =
  let rec loop res = function
    | [] -> List.rev res
    | h::t -> loop (List.rev_append h res) t
  in
    loop [] l in   


(* Ini - Algoritmo para hayar permutaciones *)
let rec insert x lst =
  match lst with
  | [] -> [[x]]
  | h::t -> 
    (x::lst) :: (List.map (fun el -> h::el) (insert x t)) in




let rec extract k list =
      if k <= 0 then [ [] ]
      else match list with
          | [] -> []
          | h :: tl ->
              let with_h = List.map (fun l -> h :: l) (extract (k-1) tl) in
              let without_h = extract k tl in
              with_h @ without_h in

let rec perm lst =
  match lst with
  | [] -> [lst]
  | h::t -> 
    List.flatten (List.map (insert h) (perm t)) in
(* Fin - Algoritmo para hayar permutaciones *)

let plan() = 


let get_action_obs() =
  let l = (lines_from_files filesetssamecolor) in
    List.iter (printf "ACA ESTAN LOS SETS $$$ : %s \n") l;
    in
    get_action_obs();
       
(* Aca filtra los sets con mas de 2 cards y los ordena de forma descendente*)    
let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_4 del ENCODING == 2: \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "touch ../sdata/00_sets_same_color.txt.out.k")   in
  let _ = Sys.command (Printf.sprintf "grep ';' %s  |  awk '{print gsub(\";\",\";\"), $0}' | sort -rn | cut -d' ' -f2- > %s" filesetssamecolor filesetssamecolorout) in
  let _ = Sys.command (Printf.sprintf "grep ';' %s  |  awk '{print gsub(\";\",\";\"), $0}' | sort -rn | cut -d' ' -f2- > %s" filesetssamecolor filesetssamecolorfull) in
  let chan = open_in tmp_file in
             close_in chan
      in
      string_of_command4();     


(**********  *)

let generate_same_color_full() =
  let a = ref 0 in 
  let l2 = (lines_from_files filesetssamecolorfull) in
  (* Comment for prepare expo - 2121/11/24 *)
  let l2hints = (lines_from_files filesetssamecolorhint) in

    List.iter (printf "ACA $$$ : %s \n") l2;
    while (!a <  List.length l2 ) do
      Printf.printf "INDEXXXXXXXXXXXXXXXXXXX = %i  \n" !a;
        let b = ref 0 in 
        let size = String.length(List.nth l2 !a) in
            
        (*if (size = 4) then begin*)
        let color =   String.sub  (List.nth l2 !a) 0 1 in
        (* Extract the string with the cards*)
        let set_single =   String.sub  (List.nth l2 !a) 2 (size-2) in
        (* Load the string into an array *)
        let listCars = (Str.split (Str.regexp "[^0-9]+") set_single) in

        Printf.printf "NUMERO DE CARTAS dddd = %i  \n" (List.length listCars);

        (* Si el numero de cards en el set = 4 *)
        if ((List.length listCars) = 4) then
          begin
            Printf.printf "NUMERO DE 4444 CARTAS dentro del  * if ((List.length listCars) = 4) then * = %i  \n" (List.length listCars);
            (* generar las combinaciones y enviarlas a otro archivo temporal , al final del proceso juntar todo y volver a ordernar => ese el .out *)
            (* Aca debo generar los sets $X(G,3,1) - Generar los Set3 *)
            (* Using the function : extract *)
            let reslst2 = (extract 3 listCars) in
            
            let d = ref 0 in 
            let set3 =  ref [] in

            while (!d < List.length reslst2) do   
              let set3b  = (List.nth reslst2 !d) in
              (* set3 :=  (append !set3 set3b); *)
              let _ = Sys.command (Printf.sprintf "echo '%s|%s;' >> ../sdata/00_sets_same_color.txt.out.k" color (String.concat ";" set3b)) in
              d := !d + 1;
            done;     
            List.iter (printf "FINALES SET 3 - === : %s \n") (!set3);           

            
            (* Este codigo SI VALE, solo comentado temporalmente por pruebas 18/09/2021 *)
            let reslst2 = (extract 2 listCars) in
            
            let d = ref 0 in 
            while (!d < List.length reslst2) do   
              let set2b  = (List.nth reslst2 !d) in
              let _ = Sys.command (Printf.sprintf "echo '%s|%s;' >> ../sdata/00_sets_same_color.txt.out.k" color (String.concat ";" set2b)) in
              d := !d + 1;
            done;     
            List.iter (printf "FINALES SET 2 - === : %s \n") (!set3);    
          end;



        (* Si el numero de cards en el set < 4 *)
        (* Comment for prepare expo - 2121/11/24 *)
        
        if ((List.length listCars) = 3) then
          begin
            Printf.printf "NUMERO DE 3333 CARTAS dentro del  * if ((List.length listCars) = 4) then * = %i  \n" (List.length listCars);
            (* generar las combinaciones y enviarlas a otro archivo temporal , al final del proceso juntar todo y volver a ordernar => ese el .out *)
            (* Aca debo generar los sets $X(G,3,1) - Generar los Set3 *)
            (* Este codigo SI VALE, solo comentado temporalmente por pruebas 18/09/2021 *)
            let reslst2 = (extract 2 listCars) in
            
            let d = ref 0 in 
            let set3 =  ref [] in  

            while (!d < List.length reslst2) do   
              let set2b  = (List.nth reslst2 !d) in
              let _ = Sys.command (Printf.sprintf "echo '%s|%s;' >> ../sdata/00_sets_same_color.txt.out.k" color (String.concat ";" set2b)) in
              d := !d + 1;
            done;     
            List.iter (printf "FINALES SET 2 - === : %s \n") (!set3);         

            
          end;   
              


        a := !a + 1; 
    done; in
    generate_same_color_full();
    
(********** *)


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "cat ../sdata/00_sets_same_color.txt.out.k %s > %s"  filesetssamecolorfull filesetssamecolortotal)   in
  let _ = Sys.command (Printf.sprintf "grep ';' %s  |  awk '{print gsub(\";\",\";\"), $0}' | sort -rn | cut -d' ' -f2- > %s" filesetssamecolortotal filesetssamecolorout) in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/;/ /g' %s" filesetssamecolorout)   in
  let _ = Sys.command (Printf.sprintf "awk '{print NF,$0}' %s | sort -nr | cut -d' ' -f 2- > %s" filesetssamecolorout "../sdata/00_sets_same_color.txt.out")   in
  let chan = open_in tmp_file in
             close_in chan
      in
      string_of_command4();  



let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/$/;/' %s" "../sdata/00_sets_same_color.txt.out") in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/ ;/;/g' -e 's/ /;/g' %s" "../sdata/00_sets_same_color.txt.out")   in
  (* let _ = Sys.command (Printf.sprintf "sed -i '$!N; /^\\(.*\\)\\n\\1$/!P; D' %s" filesetssamecolorout) in *)

  let chan = open_in tmp_file in
             close_in chan
      in
      string_of_command4();  






in

plan();

end;






(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* @@@ *)

if (encoding = 3) then  (* option : j *)
begin
Printf.printf "ENCODING == 3 \n";

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in


let rec append l1 l2 =
    match l1 with
    | h :: t -> h :: append t l2
    | [] -> l2     in
  


let rec insert_at_end l i =
    match l with
      [] -> [i]
    | h :: t -> h :: (insert_at_end t i) in


let flatten l =
  let rec loop res = function
    | [] -> List.rev res
    | h::t -> loop (List.rev_append h res) t
  in
    loop [] l in   


(* Ini - Algoritmo para hayar permutaciones *)
let rec insert x lst =
  match lst with
  | [] -> [[x]]
  | h::t -> 
    (x::lst) :: (List.map (fun el -> h::el) (insert x t)) in




let rec extract k list =
      if k <= 0 then [ [] ]
      else match list with
          | [] -> []
          | h :: tl ->
              let with_h = List.map (fun l -> h :: l) (extract (k-1) tl) in
              let without_h = extract k tl in
              with_h @ without_h in

let rec perm lst =
  match lst with
  | [] -> [lst]
  | h::t -> 
    List.flatten (List.map (insert h) (perm t)) in
(* Fin - Algoritmo para hayar permutaciones *)

let plan() = 


let get_action_obs() =
  let l = (lines_from_files filesetssamecolor) in
    List.iter (printf "ACA ESTAN LOS SETS $$$ : %s \n") l;
    in
    get_action_obs();
       
(* Aca filtra los sets con mas de 2 cards y los ordena de forma descendente en 00_sets_same_color.txt.full*)   
(* 
G|1;2;7;11;
*) 

(*
let filesetssamecolor = "../sdata/"^setssamecolor in
let filesetssamecolormix = "../sdata/"^setssamecolor in
let filesetssamecolormixfiltered = "../sdata/"^setssamecolor^".filter" in
let filesetssamecolortotal = "../sdata/"^setssamecolor^".total" in
let filesetssamecolorfull = "../sdata/"^setssamecolor^".full" in
(*let filesetssamecolorout = "../sdata/"^setssamecolor^".out" in*)
let filesetssamecolorout = "../sdata/"^setssamecolor^".out" in
*)


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "touch ../sdata/00_sets_same_color.txt.out.k")   in
  let _ = Sys.command (Printf.sprintf "grep ';' %s  |  awk '{print gsub(\";\",\";\"), $0}' | sort -rn | cut -d' ' -f2- > %s" filesetssamecolormix filesetssamecolormixfiltered) in
  (*let _ = Sys.command (Printf.sprintf "grep ';' %s  |  awk '{print gsub(\";\",\";\"), $0}' | sort -rn | cut -d' ' -f2- > %s" filesetssamecolor filesetssamecolorfull) in*)
  let chan = open_in tmp_file in
             close_in chan
      in
      string_of_command4();     


(**********  *)

let generate_same_color_full() =
  let a = ref 0 in 
  (* let l2 = (lines_from_files filesetssamecolorfull) in *)
  let l2 = (lines_from_files filesetssamecolormixfiltered) in
    List.iter (printf "ACA ESTAN LOS SETS filesetssamecolormixfiltered *******************  $$$ : %s \n") l2;
    while (!a <  List.length l2 ) do
      Printf.printf "INDEXXXXXXXXXXXXXXXXXXX = %i  \n" !a;
        let b = ref 0 in 



        let size = String.length(List.nth l2 !a) in

            
        (*if (size = 4) then begin*)
        let color =   String.sub  (List.nth l2 !a) 0 1 in
        (* Extract the string with the cards*)
        let set_single =   String.sub  (List.nth l2 !a) 2 (size-2) in
        (* Load the string into an array *)
        let listCars = (Str.split (Str.regexp "[^0-9]+") set_single) in

        

        Printf.printf "NUMERO DE CARTAS dddd = %i  \n" (List.length listCars);

        (* Si el numero de cards en el set = 4 *)
        if ((List.length listCars) = 4) then
          begin
            Printf.printf "NUMERO DE 4444 CARTAS dentro del  * if ((List.length listCars) = 4) then * = %i  \n" (List.length listCars);
            (* generar las combinaciones y enviarlas a otro archivo temporal , al final del proceso juntar todo y volver a ordernar => ese el .out *)
            (* Aca debo generar los sets $X(G,3,1) - Generar los Set3 *)
            (* Using the function : extract *)
            let reslst2 = (extract 3 listCars) in
            
            let d = ref 0 in 
            let set3 =  ref [] in
            while (!d < List.length reslst2) do   
              let set3b  = (List.nth reslst2 !d) in
              (* set3 :=  (append !set3 set3b); *)
              let _ = Sys.command (Printf.sprintf "echo '%s|%s;' >> ../sdata/00_sets_same_color.txt.out.k" color (String.concat ";" set3b)) in
              d := !d + 1;
            done;     
            List.iter (printf "FINALES SET 3 - === : %s \n") (!set3);           

            
            (* Este codigo SI VALE, solo comentado temporalmente por pruebas 18/09/2021 
            let reslst2 = (extract 2 listCars) in
            
            let d = ref 0 in 
            while (!d < List.length reslst2) do   
              let set2b  = (List.nth reslst2 !d) in
              let _ = Sys.command (Printf.sprintf "echo '%s|%s;' >> ../sdata/00_sets_same_color.txt.out.k" color (String.concat ";" set2b)) in
              d := !d + 1;
            done;     
            List.iter (printf "FINALES SET 2 - === : %s \n") (!set3);     *)     
          end;



        (* Si el numero de cards en el set = 4 *)
        (* Comment for prepare expo - 2121/11/24 *)
        (*
        if ((List.length listCars) < 4) then
          begin
            Printf.printf "MENOS DE 4 CARTAS dentro del  * if ((List.length listCars) < 4) then * = %i  \n" (List.length listCars);
            (* generar las combinaciones y enviarlas a otro archivo temporal , al final del proceso juntar todo y volver a ordernar => ese el .out *)
            (* Aca debo generar los sets $X(G,3,1) - Generar los Set3 *)
            (* Using the function : extract *)
            let differ = 4 -  (List.length listCars) in


            if differ <= (List.length l2hints) then
            let reslst2 = (extract 3 listCars) in
            
            let d = ref 0 in 
            let set3 =  ref [] in
            while (!d < List.length reslst2) do   
              let set3b  = (List.nth reslst2 !d) in
              (* set3 :=  (append !set3 set3b); *)
              let _ = Sys.command (Printf.sprintf "echo '%s|%s;' >> ../sdata/00_sets_same_color.txt.out.k" color (String.concat ";" set3b)) in
              d := !d + 1;
            done;     
            List.iter (printf "FINALES SET 3 - === : %s \n") (!set3);           
            
          end;   
          *)       


        a := !a + 1; 
    done; in
    generate_same_color_full();
    
(********** *)


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "cat ../sdata/00_sets_same_color.txt.out.k %s > %s"  filesetssamecolorfull filesetssamecolortotal)   in
  let _ = Sys.command (Printf.sprintf "grep ';' %s  |  awk '{print gsub(\";\",\";\"), $0}' | sort -rn | cut -d' ' -f2- > %s" filesetssamecolortotal filesetssamecolorout) in
  let chan = open_in tmp_file in
             close_in chan
      in
      string_of_command4();  




in

plan();

end;














(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* @@@ *)

if (encoding = 4) then  (* option : a - 2.3 - F2 Yokai *)
begin
Printf.printf "ENCODING == 4 \n";

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in


let rec append l1 l2 =
    match l1 with
    | h :: t -> h :: append t l2
    | [] -> l2     in
  


let rec insert_at_end l i =
    match l with
      [] -> [i]
    | h :: t -> h :: (insert_at_end t i) in


let flatten l =
  let rec loop res = function
    | [] -> List.rev res
    | h::t -> loop (List.rev_append h res) t
  in
    loop [] l in   


(* Ini - Algoritmo para hayar permutaciones *)
let rec insert x lst =
  match lst with
  | [] -> [[x]]
  | h::t -> 
    (x::lst) :: (List.map (fun el -> h::el) (insert x t)) in




let rec extract k list =
      if k <= 0 then [ [] ]
      else match list with
          | [] -> []
          | h :: tl ->
              let with_h = List.map (fun l -> h :: l) (extract (k-1) tl) in
              let without_h = extract k tl in
              with_h @ without_h in

let rec perm lst =
  match lst with
  | [] -> [lst]
  | h::t -> 
    List.flatten (List.map (insert h) (perm t)) in
(* Fin - Algoritmo para hayar permutaciones *)

let plan() = 


let get_action_obs() =
  let l = (lines_from_files filesetssamecolor) in
    List.iter (printf "ACA ESTAN LOS SETS $$$ : %s \n") l;
    in
    get_action_obs();
       
(* Aca filtra los sets con mas de 2 cards y los ordena de forma descendente en 00_sets_same_color.txt.full*)   
(* 
G|1;2;7;11;
*) 

(*
let filesetssamecolor = "../sdata/"^setssamecolor in
let filesetssamecolormix = "../sdata/"^setssamecolor in
let filesetssamecolormixfiltered = "../sdata/"^setssamecolor^".filter" in
let filesetssamecolortotal = "../sdata/"^setssamecolor^".total" in
let filesetssamecolorfull = "../sdata/"^setssamecolor^".full" in
(*let filesetssamecolorout = "../sdata/"^setssamecolor^".out" in*)
let filesetssamecolorout = "../sdata/"^setssamecolor^".out" in
*)


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "touch ../sdata/00_sets_same_color.txt.out.k")   in
  let _ = Sys.command (Printf.sprintf "grep ';' %s  |  awk '{print gsub(\";\",\";\"), $0}' | sort -rn | cut -d' ' -f2- > %s" filesetssamecolormix filesetssamecolormixfiltered) in
  (*let _ = Sys.command (Printf.sprintf "grep ';' %s  |  awk '{print gsub(\";\",\";\"), $0}' | sort -rn | cut -d' ' -f2- > %s" filesetssamecolor filesetssamecolorfull) in*)
  let chan = open_in tmp_file in
             close_in chan
      in
      string_of_command4();     


(**********  *)

let generate_same_color_full() =
  let a = ref 0 in 
  (* let l2 = (lines_from_files filesetssamecolorfull) in *)
  let l2 = (lines_from_files filesetssamecolormixfiltered) in
    List.iter (printf "ACA ESTAN LOS SETS filesetssamecolormixfiltered *******************  $$$ : %s \n") l2;
    while (!a <  List.length l2 ) do
      Printf.printf "INDEXXXXXXXXXXXXXXXXXXX = %i  \n" !a;
        let b = ref 0 in 



        let size = String.length(List.nth l2 !a) in

            
        (*if (size = 4) then begin*)
        let color =   String.sub  (List.nth l2 !a) 0 1 in
        (* Extract the string with the cards*)
        let set_single =   String.sub  (List.nth l2 !a) 2 (size-2) in
        (* Load the string into an array *)
        let listCars = (Str.split (Str.regexp "[^0-9]+") set_single) in

        

        Printf.printf "NUMERO DE CARTAS dddd = %i  \n" (List.length listCars);

        (* Si el numero de cards en el set = 4 *)
        if ((List.length listCars) = 4) then
          begin
            Printf.printf "NUMERO DE 4444 CARTAS dentro del  * if ((List.length listCars) = 4) then * = %i  \n" (List.length listCars);
            (* generar las combinaciones y enviarlas a otro archivo temporal , al final del proceso juntar todo y volver a ordernar => ese el .out *)
            (* Aca debo generar los sets $X(G,3,1) - Generar los Set3 *)
            (* Using the function : extract *)
            let reslst2 = (extract 3 listCars) in
            
            let d = ref 0 in 
            let set3 =  ref [] in
            while (!d < List.length reslst2) do   
              let set3b  = (List.nth reslst2 !d) in
              (* set3 :=  (append !set3 set3b); *)
              let _ = Sys.command (Printf.sprintf "echo '%s|%s;' >> ../sdata/00_sets_same_color.txt.out.k" color (String.concat ";" set3b)) in
              d := !d + 1;
            done;     
            List.iter (printf "FINALES SET 3 - === : %s \n") (!set3);           

            
            (* Este codigo SI VALE, solo comentado temporalmente por pruebas 18/09/2021 
            let reslst2 = (extract 2 listCars) in
            
            let d = ref 0 in 
            while (!d < List.length reslst2) do   
              let set2b  = (List.nth reslst2 !d) in
              let _ = Sys.command (Printf.sprintf "echo '%s|%s;' >> ../sdata/00_sets_same_color.txt.out.k" color (String.concat ";" set2b)) in
              d := !d + 1;
            done;     
            List.iter (printf "FINALES SET 2 - === : %s \n") (!set3);     *)     
          end;



        (* Si el numero de cards en el set = 4 *)
        (* Comment for prepare expo - 2121/11/24 *)
        (*
        if ((List.length listCars) < 4) then
          begin
            Printf.printf "MENOS DE 4 CARTAS dentro del  * if ((List.length listCars) < 4) then * = %i  \n" (List.length listCars);
            (* generar las combinaciones y enviarlas a otro archivo temporal , al final del proceso juntar todo y volver a ordernar => ese el .out *)
            (* Aca debo generar los sets $X(G,3,1) - Generar los Set3 *)
            (* Using the function : extract *)
            let differ = 4 -  (List.length listCars) in


            if differ <= (List.length l2hints) then
            let reslst2 = (extract 3 listCars) in
            
            let d = ref 0 in 
            let set3 =  ref [] in
            while (!d < List.length reslst2) do   
              let set3b  = (List.nth reslst2 !d) in
              (* set3 :=  (append !set3 set3b); *)
              let _ = Sys.command (Printf.sprintf "echo '%s|%s;' >> ../sdata/00_sets_same_color.txt.out.k" color (String.concat ";" set3b)) in
              d := !d + 1;
            done;     
            List.iter (printf "FINALES SET 3 - === : %s \n") (!set3);           
            
          end;   
          *)       


        a := !a + 1; 
    done; in
    generate_same_color_full();
    
(********** *)


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "cat ../sdata/00_sets_same_color.txt.out.k %s > %s"  filesetssamecolorfull filesetssamecolortotal)   in
  let _ = Sys.command (Printf.sprintf "grep ';' %s  |  awk '{print gsub(\";\",\";\"), $0}' | sort -rn | cut -d' ' -f2- > %s" filesetssamecolortotal filesetssamecolorout) in
  let chan = open_in tmp_file in
             close_in chan
      in
      string_of_command4();  




in

plan();

end;



















(* 5 *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* @@@ *)

(* -d *)
if (encoding = 5) then  (* Generate default movements - ramdom :  1-Generate var $CARDSK = [] /2-call /gensets/genactions/gen_act_30.txt *)

begin
Printf.printf "ENCODING == 5 \n";

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in


let plan() = 

let get_action_obs() =
  let l = (lines_from_files filesetssamecolor) in
    List.iter (printf "ACA ESTAN LOS SETS $$$ : %s \n") l;
    in
    get_action_obs();
       

(*** JFD: 02/03/2022 - from 00_sets_same_color.txt generates file 00_sets_same_color.txt.tmp con el contenido del primero*)

let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "cat %s > %s" filesetssamecolor "../sdata/00_sets_same_color.txt.tmp")   in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();  


(* JFD-03/03/2022 : from 00_sets_same_color.txt.tmp generates file 00_sets_same_color.txt.km para indicar las cartas conocidas x la M *)    
let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/^\s*.//g' -e 's/|/\\$$CARDSK = [/g' -e 's/.$//' -e 's/;/,/g'  -e 's/$/]/' %s" "../sdata/00_sets_same_color.txt.km") in*)
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/^.\{,2\}//' -e '/^$/d' %s" "../sdata/00_sets_same_color.txt.tmp") in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();  

let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/^\s*.//g' -e 's/|/\\$$CARDSK = [/g' -e 's/.$//' -e 's/;/,/g'  -e 's/$/]/' %s" "../sdata/00_sets_same_color.txt.km") in*)
  let _ = Sys.command (Printf.sprintf "tr -d '\n' < %s > %s" "../sdata/00_sets_same_color.txt.tmp" "../sdata/00_sets_same_color.txt.km") in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();  




let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/^/\\$CARDSK = [/' -e 's/.$//' -e 's/;/,/g'  -e 's/$/]/' %s" "../sdata/00_sets_same_color.txt.km") in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();        
      
     
let string_of_command4 () =
        Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
        let tmp_file = "planerdata/99_tmp.txt" in
        let _ = Sys.command (Printf.sprintf "cat %s %s %s > %s" "../sdata/01_ini_set.txt" "../sdata/00_sets_same_color.txt.km" "../gensets/genactions/gen_act_30.txt" "../sdata/02_gen_actions.txt")   in
        let chan = open_in tmp_file in
                    close_in chan
            in
            string_of_command4();        

let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "./touist.exe ../sdata/02_gen_actions.txt --show > ../sdata/02_gen_actions.txt.show")   in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/⋀ /\n/g' -e 's/))))))/)/g' -e 's/))/)/g' -e 's/(((/(/g' -e 's/((/(/g' -e 's/(pos/pos/g' -e 's/))/)/g' -e 's/,/_/g' %s" "../sdata/02_gen_actions.txt.show") in*)
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/))))))/)/g' -e 's/))/)/g' -e 's/(((/(/g' -e 's/((/(/g' -e 's/(pos/pos/g' -e 's/))/)/g' -e 's/,/_/g' %s" "../sdata/02_gen_actions.txt.show") in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();  


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/⋀ /\\n/g' %s" "../sdata/02_gen_actions.txt.show") in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();       


let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/_/_t/4' -e 's/ //g' -e 's/(/\_/g' -e 's/)//g' ../sdata/02_gen_actions.txt.show") in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();   
      
      


let clock = List.nth (lines_from_files "../sdata/99_clock.txt") 0 in
let clock2 = ref 0 in
clock2 := (int_of_string clock) + 1;

let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "cat %s > ../sdata/02_actions_t%i.txt" "../sdata/02_gen_actions.txt.show" !clock2) in
  let chan = open_in tmp_file in
              close_in chan
      in
      string_of_command4();         



(*
let string_of_command4 () =
  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
  let tmp_file = "planerdata/99_tmp.txt" in
  let _ = Sys.command (Printf.sprintf "sed -i -e 's/|/ /g' -e 's/.$//' %s" filesetssamecolor)   in
  let chan = open_in tmp_file in
             close_in chan
      in
      string_of_command4();     
*)





in

plan();

end;











(* 6 *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* @@@ *)

if (encoding = 6) then  (* Graba en el file los sets de cartas agrupadas del mismo color *)
(*
//Aca tambien debo de grabar en 00_sets_same_color_4g.txt or 00_sets_same_color_3g.txt
*)

begin
Printf.printf "ENCODING == 6 \n";
let parameter = (replace  "../sdata/" "" filesetssamecolor) in
Printf.printf "Contenido de parameter = %s  \n" parameter;

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in


let plan() = 

let get_action_obs() =
  let l = (lines_from_files filesetssamecolor) in
    List.iter (printf "ACA ESTAN LOS SETS $$$ : %s \n") l;
(*** JFD: 02/03/2022 - from 00_sets_same_color.txt generates file 00_sets_same_color.txt.tmp con el contenido del primero*)
  let action = List.nth (lines_from_files "../sdata/00_sets_same_color.txt.uno") 0 in
                                          Printf.printf "Contenido de  file uno = %s  \n" action;
                                    let words = String.split_on_char ' ' action in
                                    (*let size = String.length(List.nth words 0) in*)
                                    let action_single =   (List.nth words 0) in (* Get the color of the cards*)
                                        
                                          begin

                                            let cards_grouped_line =   (List.nth words 1) in  
                                            let cards_grouped = String.split_on_char ';' cards_grouped_line in

                                            if (List.length cards_grouped == 4) then
                                              begin
                                                (*
                                                1. Delete all lines starting with action_single from: 00_sets_same_color_4g.txt
                                                2. Insert the line action into the file: 00_sets_same_color_4g.txt
                                                *)
                                                let string_of_command4 () =
                                                  Printf.printf "4 Cards grouped in .uno =  %s \n" cards_grouped_line;
                                                  let tmp_file = "../sdata/00_tempo.txt" in
                                                let _ = Sys.command (Printf.sprintf "sed -i '/^%s/d' %s" action_single "../sdata/00_sets_same_color_4g.txt") in 
                                                (*let _ = Sys.command (Printf.sprintf "cat %s >> %s" action "../sdata/00_sets_same_color_4g.txt") in  *)
                                                let _ = Sys.command (Printf.sprintf "echo '%s' >> ../sdata/00_sets_same_color_4g.txt" (action_single^"|"^cards_grouped_line^";"))   in
                                                let chan = open_in tmp_file in
                                                        close_in chan in
                                                        string_of_command4 ();
                                                
                                              end;

                                            if (List.length cards_grouped == 3) then
                                            begin
                                              (*
                                              1. Delete all lines starting with action_single from: 00_sets_same_color_4g.txt
                                              2. Insert the line action into the file: 00_sets_same_color_4g.txt
                                              *)
                                              let string_of_command4 () =
                                                Printf.printf "3 Cards grouped in .uno =  %s \n" cards_grouped_line;
                                                let tmp_file = "../sdata/00_tempo.txt" in
                                              let _ = Sys.command (Printf.sprintf "sed -i '/^%s/d' %s" action_single "../sdata/00_sets_same_color_3g.txt") in 
                                              (* let _ = Sys.command (Printf.sprintf "cat %s >> %s" action "../sdata/00_sets_same_color_4g.txt") in *)
                                              (*let _ = Sys.command (Printf.sprintf "cat %s >> %s" action "../sdata/00_sets_same_color_3g.txt") in *)
                                              let _ = Sys.command (Printf.sprintf "echo '%s' >> ../sdata/00_sets_same_color_3g.txt" (action_single^"|"^cards_grouped_line^";"))   in
                                              let chan = open_in tmp_file in
                                                      close_in chan in
                                                      string_of_command4 ();
                                              
                                            end;


(* 
!a <  List.length l2
*)

                                            let string_of_command4 () =
                                              Printf.printf "Single Action = *%s* + %s \n" action_single (List.nth words 1);
                                              let tmp_file = "../sdata/00_tempo.txt" in
                                              (*let _ = Sys.command (Printf.sprintf "sed -i -e '/%s/s/$/%s|/' %s" (List.nth words 2) (List.nth words 1) filesetssamecolor)   in*)
                                              let _ = Sys.command (Printf.sprintf "cat %s > %s" "../sdata/00_sets_same_color.txt.uno" "../sdata/00_sets_same_color.txt.uno.tmp")   in                                                      
                                                let chan = open_in tmp_file in
                                                        close_in chan in
                                                        string_of_command4 ();  
                                                      
                                                      
                                            let string_of_command4 () =
                                              Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
                                              let tmp_file = "planerdata/99_tmp.txt" in
                                              (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/ /|/g' -e 's/$/;/g' ../sdata/00_sets_same_color.txt.uno.tmp") in*)
                                              let _ = Sys.command (Printf.sprintf "sed -i -e 's/ /|/g' -e 's/$/;/g' ../sdata/00_sets_same_color.txt.uno.tmp") in
                                              let chan = open_in tmp_file in
                                                          close_in chan
                                                  in
                                                  string_of_command4();                                                         

(*
                                            let string_of_command4 () =
                                              Printf.printf "\n break Line : \n";
                                              let tmp_file = "planerdata/99_tmp.txt" in
                                              (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/ /|/g' -e 's/$/;/g' ../sdata/00_sets_same_color.txt.uno.tmp") in*)
                                              let _ = Sys.command (Printf.sprintf "sed -i -e '$a\\' ../sdata/00_sets_same_color.txt.uno.tmp") in
                                              let chan = open_in tmp_file in
                                                          close_in chan
                                                  in
                                                  string_of_command4();       
*)                                                  
                                                  
                                                  let string_of_command4 () =
                                                    Printf.printf "\n break Line : \n";
                                                    let tmp_file = "planerdata/99_tmp.txt" in
                                                    (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/ /|/g' -e 's/$/;/g' ../sdata/00_sets_same_color.txt.uno.tmp") in*)
                                                    let _ = Sys.command (Printf.sprintf "sed -i -e '$a\\' ../sdata/00_sets_same_color.txt.uno.tmp") in
                                                    let chan = open_in tmp_file in
                                                                close_in chan
                                                        in
                                                        string_of_command4();                                                    
                                                        




                                            let string_of_command4 () =
                                            Printf.printf "Single Action = *%s* + %s \n" action_single (List.nth words 1);
                                            let tmp_file = "../sdata/00_tempo.txt" in
                                            (*let _ = Sys.command (Printf.sprintf "sed -i -e '/%s/s/$/%s|/' %s" (List.nth words 2) (List.nth words 1) filesetssamecolor)   in*)
                                              let _ = Sys.command (Printf.sprintf "sed -i -e '/^%s/d' %s" action_single "../sdata/00_sets_same_color_grouped.txt")   in
                                              let chan = open_in tmp_file in
                                                      close_in chan in
                                                      string_of_command4 ();    

                                                      

                                            
                                            let string_of_command4 () =                                                      
                                            Printf.printf "CARDS = :: \n";
                                            let tmp_file = "../sdata/00_tempo.txt" in
                                              let _ = Sys.command (Printf.sprintf "cat %s >> %s" "../sdata/00_sets_same_color.txt.uno.tmp" "../sdata/00_sets_same_color_grouped.txt")   in
                                              (*let _ = Sys.command (Printf.sprintf "cat %s | tee -a %s" "../sdata/00_sets_same_color.txt.uno.tmp" "../sdata/00_sets_same_color_grouped.txt")   in*)
                                              let chan = open_in tmp_file in
                                                      close_in chan in
                                                      string_of_command4 ();     


                                            (*let string_of_command4 () =
                                              Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
                                              let tmp_file = "planerdata/99_tmp.txt" in
                                              let _ = Sys.command (Printf.sprintf "sed -i -e 's/_/|/g' ../sdata/00_sets_same_color_grouped.txt") in
                                              let chan = open_in tmp_file in
                                                          close_in chan
                                                  in
                                                  string_of_command4();*)

                                                      

                                                      
                                            (* Aca filtra los sets con mas de 2 cards y los ordena de forma descendente*)    
                                            let string_of_command4 () =
                                              Printf.printf "\n DENTRO DEL COMMAND_4 del ENCODING == 2: \n";
                                              let tmp_file = "planerdata/99_tmp.txt" in
                                              let _ = Sys.command (Printf.sprintf "grep ';' %s  |  awk '{print gsub(\";\",\";\"), $0}' | sort -rn | cut -d' ' -f2- > %s" "../sdata/00_sets_same_color_grouped.txt" "../sdata/00_sets_same_color_grouped.order") in
                                              let chan = open_in tmp_file in
                                                        close_in chan
                                                  in
                                                  string_of_command4();    




    
                                          end
                                         in
    
   get_action_obs();

in
plan();

end;




















(* 7 *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* @@@ *)

if (encoding = 7) then  (* Graba en el file los sets de cartas agrupadas del mismo color *)




  
(*
  file_name := (replace2  "solvedatacp/" "" input);
  file_name_qbf := (replace2  "solvedatacp/" "" input);
  file_axioms := input;
*)



begin
Printf.printf "ENCODING == 7 \n";

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in

let rec length l =
  match l with
  | [] -> 0
  | _ :: t -> 1 + length t in      


let plan() = 

  let parameter = (replace  "../sdata/" "" filesetssamecolor) in
  let linenum = int_of_string(parameter) in

  printf "linenum : %i \n" linenum;
  if linenum >= 1 then



    (* let clock = List.nth (lines_from_files "../sdata/99_clock.txt") 0 in *)

  (*let l = List.nth (lines_from_files "../sdata/00_sets_same_color_grouped.order")  linenum in
   printf "ACA ESTAN LOS SETS $$$ : %s \n" l;*)
  (*** JFD: 02/03/2022 - from 00_sets_same_color.txt generates file 00_sets_same_color.txt.tmp con el contenido del primero*)
  (*Aca tiene que recorrer todas las lineas del file .order una x una y luego llamar al touist en c/interaccion para asegurarse que hay acciones disponibles *)
  (* Printf.printf "\n length l: %i \n" (length l); *)
  (* if (List.length l > 0) then *)

    (* Generate the real color file vertical - sets *)
    let string_of_command4 () =
      Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
      let tmp_file = "planerdata/99_tmp.txt" in
      (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/^../$CARDS_G = [/' -e 's/.$//g' -e 's/.*/&]/' ../sdata/00_sets_same_color_grouped.order > ../sdata/00_sets_same_color_grouped.order.tmp") in*)
      let _ = Sys.command (Printf.sprintf "sed -e 's/^...........//' -e 's/.$//g' -e 's/, /\\n/g' ../sdata/real_colors.txt > ../sdata/real_colors.txt.tmp") in
      let chan = open_in tmp_file in
                  close_in chan
          in
          string_of_command4();


    let string_of_command4 () =
      Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
      let tmp_file = "planerdata/99_tmp.txt" in
      (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/^../$CARDS_G = [/' -e 's/.$//g' -e 's/.*/&]/' ../sdata/00_sets_same_color_grouped.order > ../sdata/00_sets_same_color_grouped.order.tmp") in*)
      let _ = Sys.command (Printf.sprintf "sed '/./=' ../sdata/real_colors.txt.tmp | sed '/./N; s/\\n/ /' > ../sdata/real_colors.txt.tmp.ok") in
      let chan = open_in tmp_file in
                  close_in chan
          in
          string_of_command4();     
          
          
    let string_of_command4 () =
      Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
      let tmp_file = "planerdata/99_tmp.txt" in
      (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/^../$CARDS_G = [/' -e 's/.$//g' -e 's/.*/&]/' ../sdata/00_sets_same_color_grouped.order > ../sdata/00_sets_same_color_grouped.order.tmp") in*)
      let _ = Sys.command (Printf.sprintf "sed -i -e 's/^/$COLOR(/' -e 's/ /) = \[/g' -e 's/$/]/' ../sdata/real_colors.txt.tmp.ok") in
      let chan = open_in tmp_file in
                  close_in chan
          in
          string_of_command4();             

      (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/⋀ /\\n/g' %s" "../sdata/02_gen_actions.txt.show") in          *)



    let string_of_command4 () =
      Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
      let tmp_file = "planerdata/99_tmp.txt" in
      (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/^../$CARDS_G = [/' -e 's/.$//g' -e 's/.*/&]/' ../sdata/00_sets_same_color_grouped.order > ../sdata/00_sets_same_color_grouped.order.tmp") in*)
      let _ = Sys.command (Printf.sprintf "sed -e '%iq;d' %s > %s" linenum "../sdata/00_sets_same_color_grouped.order"  "../sdata/00_sets_same_color_grouped.order.one") in
      let chan = open_in tmp_file in
                  close_in chan
          in
          string_of_command4();       




    let string_of_command4 () =
      Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
      let tmp_file = "planerdata/99_tmp.txt" in
      (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/^../$CARDS_G = [/' -e 's/.$//g' -e 's/.*/&]/' ../sdata/00_sets_same_color_grouped.order > ../sdata/00_sets_same_color_grouped.order.tmp") in*)
      let _ = Sys.command (Printf.sprintf "sed -e 's/^../$CARDS_G = [/' -e 's/.$//g' -e 's/.*/&]/' -e 's/;/,/g' ../sdata/00_sets_same_color_grouped.order.one > ../sdata/00_sets_same_color_grouped.order.tmp") in
      let chan = open_in tmp_file in
                  close_in chan
          in
          string_of_command4();      

    let size = ref 0 in



    (* while (!size < List.length l) do *)
      
        let action = List.nth (lines_from_files "../sdata/00_sets_same_color_grouped.order.tmp") (!size) in
                (* Printf.printf "Cards = %s + %s \n" (List.nth cards 0) (List.nth cards 1); *)
                printf "CARDS line == %s \n" action;
                let _ = Sys.command (Printf.sprintf "echo '%s' > ../sdata/sets_cardsg.sets" action)   in
                (* O lo mejor sera reemplazar los 2 primeros chars de c/linea - Antes de entrar al WHILE -y luego recorrer linea x linea y generar el goal file para observacion y llamar al touist y luego procesar la salida y generar el 01_actions_t1 *)                                              

                let string_of_command4 () =
                  Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
                  let tmp_file = "planerdata/99_tmp.txt" in
                  let _ = Sys.command (Printf.sprintf "cat %s %s %s %s > %s" "../sdata/01_ini_set.txt" "../sdata/sets_cardsg.sets" "../sdata/real_colors.txt.tmp.ok" "../sdata/goals/Goal_11b.txt" "../sdata/02_gen_actions_col.txt")   in
                  let chan = open_in tmp_file in
                              close_in chan
                      in
                      string_of_command4();      
                      
                                     
                let touistcode = (command (Printf.sprintf "./touist.exe ../sdata/02_gen_actions_col.txt --solve")) in 
                  
                if (touistcode == 0) then 

                  
                begin 
                    let string_of_command4 () =
                      Printf.printf "\n DENTRO DEL COMMAND_4 : \n";
                      let tmp_file = "planerdata/99_tmp.txt" in
                      let _ = Sys.command (Printf.sprintf "./touist.exe ../sdata/02_gen_actions_col.txt --show > ../sdata/02_gen_actions_col.txt.show")   in
                      let chan = open_in tmp_file in
                                  close_in chan
                          in
                          string_of_command4();    

                          
                    let string_of_command4 () =      
                    Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
                    let tmp_file = "planerdata/99_tmp.txt" in
                    let _ = Sys.command (Printf.sprintf "sed -i -e 's/(col/col/g'  -e 's/))))))//g' -e 's/,/_/g'  -e 's/⋀ /\\n/g' -e 's/ //g' ../sdata/02_gen_actions_col.txt.show") in
                    let chan = open_in tmp_file in
                                close_in chan
                        in
                        string_of_command4();                                                         


                    let string_of_command4 () =      
                      Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
                      let tmp_file = "planerdata/99_tmp.txt" in
                      let _ = Sys.command (Printf.sprintf "sed -i -e 's/(col/col/g'  -e 's/))))))//g' -e 's/,/_/g'  -e 's/⋀ /\\n/g' -e 's/ //g' ../sdata/02_gen_actions_col.txt.show") in
                      let chan = open_in tmp_file in
                                  close_in chan
                          in
                          string_of_command4();   

                    let string_of_command4 () =      
                      Printf.printf "\n DENTRO DEL COMMAND_FINAL_FINAL : \n";
                      let tmp_file = "planerdata/99_tmp.txt" in
                      let _ = Sys.command (Printf.sprintf "sed -i -e 's/_/_t/2' ../sdata/02_gen_actions_col.txt.show") in
                      let chan = open_in tmp_file in
                                  close_in chan
                          in
                          string_of_command4();


                    (* Read the file: 99_clock.txt get the time and add 1*)

                    let clock = List.nth (lines_from_files "../sdata/99_clock.txt") 0 in
                    let clock2 = ref 0 in
                    clock2 := (int_of_string clock) + 1;

                    let string_of_command4 () =
                      Printf.printf "\n DENTRO DEL COMMAND_5x : \n";
                      let tmp_file = "planerdata/99_tmp.txt" in
                      let _ = Sys.command (Printf.sprintf "cat %s > ../sdata/02_actions_t%i.txt" "../sdata/02_gen_actions_col.txt.show" !clock2) in
                      let chan = open_in tmp_file in
                                  close_in chan
                          in
                          string_of_command4();         



                    let string_of_command4 () =      
                      Printf.printf "\n DENTRO DEL COMMAND_FINAL_FINAL : \n";
                      let tmp_file = "planerdata/99_tmp.txt" in
                      let _ = Sys.command (Printf.sprintf "sed -i -e 's/.$//' -e 's/(/_/g' -e 's/))//g' -e 's/)//g' ../sdata/02_actions_t%i.txt" !clock2) in
                      let chan = open_in tmp_file in
                                  close_in chan
                          in
                          string_of_command4();



                    exit 0;

                end;
    
else
  begin                            
    (* Genera acciones x defector porque no hay lineas en el archivo .order*)                               
    let clock = List.nth (lines_from_files "../sdata/99_clock.txt") 0 in
    let clock2 = ref 0 in
    clock2 := (int_of_string clock) + 1;

    let string_of_command4 () =
      Printf.printf "\n DENTRO DEL ELSE ELSE : \n";
      let tmp_file = "planerdata/99_tmp.txt" in
      let _ = Sys.command (Printf.sprintf "cat ../sdata/02_actions_col_bk.txt > ../sdata/02_actions_t%i.txt"  !clock2) in
      let chan = open_in tmp_file in
                  close_in chan
          in
          string_of_command4();   


    let string_of_command4 () =      
      Printf.printf "\n DENTRO DEL COMMAND_FINAL_FINAL : \n";
      let tmp_file = "planerdata/99_tmp.txt" in
      let _ = Sys.command (Printf.sprintf "sed -i -e 's/$/%i/' ../sdata/02_actions_t%i.txt" !clock2 !clock2) in
      let chan = open_in tmp_file in
                  close_in chan
          in
          string_of_command4();




  end;

                      
in
plan();

end;
























(* 8 *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* ************************************************************ *)
(* @@@ *)

if (encoding = 8) then  (* Graba en el file los sets de cartas agrupadas del mismo color *)


let rec func x lst c = match lst with
    | [] -> -1
    | hd::tl -> if ((String.sub hd 0 1) =x) then c else func x tl (c+1) in

let find x lst = func x lst 0 in 


begin
Printf.printf "ENCODING == 8 \n";

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
  let rec lines_from_files_aux i acc = match (read_line i) with 
    | None -> List.rev acc
    | Some s -> lines_from_files_aux i (s :: acc) in 
  lines_from_files_aux (open_in filename) [] in

let rec length l =
  match l with
  | [] -> 0
  | _ :: t -> 1 + length t in      


let plan() = 


    let a = ref 0 in 
    let l2 = (lines_from_files "../sdata/00_sets_same_color.txt") in
    let lsch = (lines_from_files "../sdata/00_sets_same_colorhint.txt") in
    List.iter (printf "ACA ESTAN Las lineas del file: ../sdata/00_sets_same_color.txt : %s \n") l2;



    let string_of_command4 () =
      Printf.printf "\n Ini file .mix : \n";
      let tmp_file = "planerdata/99_tmp.txt" in
      let _ = Sys.command (Printf.sprintf "cat ../sdata/00_empty_file.txt > ../sdata/00_sets_same_color.mix") in
      let chan = open_in tmp_file in
                  close_in chan
          in
          string_of_command4();  
          
          


  
      while (!a <  List.length l2 ) do
          Printf.printf "INDEXXXXXXXXXXXXXXXXXXX = %i  \n" !a;
          let line_samecolor = List.nth l2 !a in
          let size = String.length(line_samecolor) in
              
          (*if (size = 4) then begin*)
          let color =   String.sub  (List.nth l2 !a) 0 1 in
          (* Extract the string with the cards*)

          let set_samecolor =   String.sub  (List.nth l2 !a) 2 (size-2) in
          (* Load the string into an array *)
          let cars_samecolor = (Str.split (Str.regexp "[^0-9]+") set_samecolor) in
          Printf.printf "Linea :  %i - Cartas : %s \n" (List.length cars_samecolor) set_samecolor;

          let size_samecolor = List.length cars_samecolor in
          if (size_samecolor < 4) then
            begin
                (* Extract la linea que empieza con ese color y hacer un split sobre las cartas y luego ver si el numero de cartas es >*)
                (* Que la diferencia de 4 - numero_cartas_samecolor, si es asi entonces generar combinaciones *)
                (* Sino entonces agregar todas estas cartas deducidas con las same_color en el file .mix*)
                Printf.printf "Linea :  %i - Cartas : %s \n" (List.length cars_samecolor) set_samecolor;

                let line_samecolorhint = find color lsch in
                let size_samecolorhint = String.length(List.nth lsch line_samecolorhint) in
                  Printf.printf "Linea line_samecolorhint :  %i \n" line_samecolorhint;
                  (*if size_sch > 2 then*)
                  let set_samecolorhint =   String.sub  (List.nth lsch line_samecolorhint) 2 (size_samecolorhint - 2) in
                  Printf.printf "Set samecolorhint:  %s \n" set_samecolorhint;
                  let cars_samecolorhint = (Str.split (Str.regexp "[^0-9]+") set_samecolorhint) in
                  let resto = (4 - List.length cars_samecolor) in

                  if (List.length cars_samecolorhint > resto) then
                    (* Formar combinatios from elements of "cars_samecolorhint" de tamanio "resto" *)
                    (* let reslst = flatten (extract resto cars_samecolorhint) in *)

                    let reslst = (extract resto cars_samecolorhint) in
                    let b = ref 0 in 

                    while (!b < List.length reslst ) do
                      (* let line_samecolormix = line_samecolor ^ ";" ^ (List.nth reslst !b) in *)
                      let combi = (List.nth reslst !b) in
                      let line_samecolormix = line_samecolor ^ (String.concat ";" combi) in
                      Printf.printf "line_samecolormix 1:  %s \n" line_samecolormix;  
                      let _ = Sys.command (Printf.sprintf "echo '%s' >> ../sdata/00_sets_same_color.mix" line_samecolormix)   in


                      b := !b + 1; 
                    done;  
                  else
                    let line_samecolormix = line_samecolor ^ (String.concat ";" cars_samecolorhint) in
                    let _ = Sys.command (Printf.sprintf "echo '%s' >> ../sdata/00_sets_same_color.mix" line_samecolormix)   in
                    Printf.printf "line_samecolormix 2:  %s \n" line_samecolormix;  
                    
            end
          else
            begin
            let line_samecolormix = line_samecolor in          
            let _ = Sys.command (Printf.sprintf "echo '%s' >> ../sdata/00_sets_same_color.mix" (String.sub line_samecolormix 0 (size - 1)))   in
            Printf.printf "line_samecolor 2:  %s \n" line_samecolormix;      
            end;
            (* String.sub  (List.nth l2 !a) 2 (size-2) *)

          a := !a + 1;  
      done;



                      
in
plan();

end;







end